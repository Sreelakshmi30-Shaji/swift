//
//  ProductCollectionViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 19/07/23.
//

import UIKit
import CoreData

class ProductCollectionViewController: UIViewController{
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var ProductCollectionView: UICollectionView!
    @IBOutlet weak var cartButton: UIBarButtonItem!
    @IBOutlet weak var searchBar: UISearchBar!

    let viewModel = Screen1ViewModel()
    var products: [Product] = []
    var cartItems: [Product] = []
    var originalProducts: [Product] = []
    var isProductFound = false

    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.delegate = self
                                
        navigationItem.title = "Screen PLP"
        ProductCollectionView.delegate = self
        ProductCollectionView.dataSource = self
        
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.minimumInteritemSpacing = 10
        flowLayout.minimumLineSpacing = 10
        flowLayout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        flowLayout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        ProductCollectionView.collectionViewLayout = flowLayout

        let nib = UINib(nibName: "ProductCollectionViewCell", bundle: nil)
        ProductCollectionView.register(nib, forCellWithReuseIdentifier: "ProductCollectionViewCellIdentifier")
        
        updateCartBadge()
        
        activityIndicator.startAnimating()
        viewModel.fetchApi { (fetchedProducts, error) in
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.activityIndicator.isHidden = true
            }
            if let error = error {

            } else if let fetchedProducts = fetchedProducts {
                self.products = fetchedProducts
                self.originalProducts = fetchedProducts
                DispatchQueue.main.async {
                    self.ProductCollectionView.reloadData()
                }
            }
        }
    }

    @IBAction func cartButtonAction(_ sender: Any) {
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
         let productTableVC = storyboard.instantiateViewController(withIdentifier: "ProductTableViewController") as! ViewController
         navigationController?.pushViewController(productTableVC, animated: true)
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Search Results", message: message, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func updateCartBadge() {
        
        let badgeCount = cartItems.reduce(0) { (result, product) in
               if let count = product.count {
                   print("Adding \(count) for product: \(product.title ?? "")")
                   return result + Int(count)
               } else {
                   print("Skipping product with missing count: \(product.title ?? "")")
                   return result
               }
           }

        if let image = UIImage(named: "cart") {
            let buttonSize = CGSize(width: 60, height: 60)

            let customButton = UIButton(type: .custom)
            customButton.setImage(image, for: .normal)
            customButton.frame = CGRect(origin: .zero, size: buttonSize)
            customButton.addTarget(self, action: #selector(cartButtonAction), for: .touchUpInside)

            let customBarButtonItem = UIBarButtonItem(customView: customButton)
            navigationItem.rightBarButtonItem = customBarButtonItem

            let badgeLabel = UILabel()
            badgeLabel.backgroundColor = .red
            badgeLabel.textColor = .white
            badgeLabel.font = UIFont.boldSystemFont(ofSize: 12)
            badgeLabel.textAlignment = .center
            badgeLabel.layer.cornerRadius = badgeLabel.bounds.size.height / 2
            badgeLabel.layer.masksToBounds = true
            badgeLabel.translatesAutoresizingMaskIntoConstraints = false
            badgeLabel.text = "\(badgeCount)"
            badgeLabel.isHidden = badgeCount == 0
            customButton.addSubview(badgeLabel)

            NSLayoutConstraint.activate([
                badgeLabel.trailingAnchor.constraint(equalTo: customButton.trailingAnchor, constant: -4),
                badgeLabel.topAnchor.constraint(equalTo: customButton.topAnchor, constant: 4),
                badgeLabel.widthAnchor.constraint(equalToConstant: 15),
                badgeLabel.heightAnchor.constraint(equalToConstant: 15)
            ])
            NSLayoutConstraint.activate([
                       customButton.widthAnchor.constraint(equalToConstant: buttonSize.width),
                       customButton.heightAnchor.constraint(equalToConstant: buttonSize.height)
            ])
        }
    }
}

extension ProductCollectionViewController : UICollectionViewDataSource{
    
     func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCollectionViewCellIdentifier", for: indexPath) as! ProductCollectionViewCell
        
        let product = products[indexPath.item]
        cell.productTitleLabel.text = product.title
        cell.productTitleLabel.numberOfLines = 0
        cell.productPriceLabel.text = "Rs.\(product.price ?? "")"
        
        if let imageURL = product.image {
            if let url = URL(string: imageURL) {
                DispatchQueue.global().async {
                    if let data = try? Data(contentsOf: url) {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.productImageView.image = image
                        }
                    }
                }
            }
        } else {
            cell.productImageView.image = nil
        }
        return cell
    }
}

extension ProductCollectionViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedProduct = products[indexPath.item]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let productDetailsVC = storyboard.instantiateViewController(withIdentifier: "ProductDetailViewController") as? ProductDetailViewController {
            productDetailsVC.productTitle = selectedProduct.title
            productDetailsVC.product = selectedProduct
            productDetailsVC.cartItems = self.cartItems
            navigationController?.pushViewController(productDetailsVC, animated: true)
        }
    }
}
    
extension ProductCollectionViewController: UISearchBarDelegate{
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if let searchText = searchBar.text, !searchText.isEmpty {
            let filteredProducts = originalProducts.filter { product in
                let titleMatches = product.title?.lowercased().contains(searchText.lowercased()) ?? false
                if let price = product.price {
                    let priceMatches = price.lowercased().contains(searchText.lowercased())
                    return titleMatches || priceMatches
                }
                return titleMatches
            }
            self.products = filteredProducts
            self.ProductCollectionView.reloadData()

            isProductFound = !filteredProducts.isEmpty
            
            if isProductFound {
                showAlert(message: "Product found with details.")
            }
            else {
                showAlert(message: "No results found.")
            }
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        self.products = originalProducts
        self.ProductCollectionView.reloadData()
    }
}




