//
//  ProductCollectionViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 19/07/23.
//

import UIKit

class ProductCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var productTitleLabel: UILabel!
    @IBOutlet weak var productPriceLabel: UILabel!
    
    var product: Product? 
    
    override func prepareForReuse() {
            super.prepareForReuse()
        // Reset cell content to default state
            productImageView.image = nil
            productTitleLabel.text = nil
            productPriceLabel.text = nil
        }
}
