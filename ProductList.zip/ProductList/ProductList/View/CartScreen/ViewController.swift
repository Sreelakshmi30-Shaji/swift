//
//  ViewContoller.swift
//  ProductList
//
//  Created by Sreelakshmi on 07/07/23.
//

import UIKit
import CoreData

protocol CartViewControllerDelegate: AnyObject {
    func didSelectProductImages(_ images: [UIImage])
}

class ViewController: UIViewController {
    
    @IBOutlet weak var productTableView: UITableView!
    @IBOutlet weak var totalCountButton: UIButton!
    weak var delegate: CartViewControllerDelegate?
    var productDetailVc = ProductDetailViewController()
    var productImage: [UIImage] = []
    
    var product: Product?
    var cartItems: [Product] = []
    var savedForLaterItems: [Product] = []
    var viewModel = Screen2ViewModel()
    var viewModel2 = Screen3ViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        totalCountButton.layer.cornerRadius = 20
        productTableView.register(UINib(nibName: "ProductTableViewCell", bundle: nil), forCellReuseIdentifier: "productCellIdentifier")
        productTableView.sectionHeaderTopPadding = 0
        refreshData()
    }
    
    @IBAction func totalPriceButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let productListVC = storyboard.instantiateViewController(withIdentifier: "ShippingScreenViewController") as! ShippingScreenViewController
        productListVC.delegate = self
        productListVC.productImages = productImage
        productListVC.cartItems = cartItems
        navigationController?.pushViewController(productListVC, animated: true)
    }
    
    func refreshData() {
            viewModel.retrieveData { items, error in
                if let error = error {
                    print("Error retrieving data: \(error)")
                    return
                }
                guard let items = items else {
                    return
                }
                self.cartItems.removeAll()
                self.savedForLaterItems.removeAll()
                for item in items {
                    if item.saveForLater! {
                        self.savedForLaterItems.append(item)
                    } else {
                        self.cartItems.append(item)
                        self.viewModel.loadProductImages(for: self.cartItems) {
                                       self.updateTotalPriceLabel()
                                       self.productDetailVc.updateCartBadge()
                                       self.productTableView.reloadData()
                                   }
                    }
                }
                self.updateTotalPriceLabel()
                self.productDetailVc.updateCartBadge()
                self.productTableView.reloadData()
            }
        }
    
    func updateTotalPriceLabel() {
        let totalPrice = viewModel2.calculateTotalPrice(for: cartItems)
        if cartItems.isEmpty {
            totalCountButton.isHidden = true
        } else {
            totalCountButton.isHidden = false
            totalCountButton.setTitle("Total Price in Cart : Rs.\(totalPrice)", for: .normal)
//            totalCountButton.layer.cornerRadius = 20
        }
        productTableView.reloadData()
    }

    func updateButtonTitle(for cell: ProductTableViewCell, at indexPath: IndexPath) {
        let section = indexPath.section
        if section == 0 {
            cell.saveForLaterButton.setTitle("Save for Later", for: .normal)
            cell.saveForLaterButton.backgroundColor = UIColor.systemCyan
        } else if section == 1 {
            cell.saveForLaterButton.setTitle("Move to Cart", for: .normal)
            cell.saveForLaterButton.backgroundColor = UIColor.systemMint
        }
    }
    
    func incrementProductCount(at indexPath: IndexPath) {
          let product = viewModel.cartItem[indexPath.row]
          
          if let currentCount = product.count {
              if currentCount >= 10 {
                  let toastView = ToastView(frame: CGRect(x: 110, y: 10, width: 200, height: 50))
                  toastView.translatesAutoresizingMaskIntoConstraints = false
                  view.addSubview(toastView)
                  toastView.show(message: "Limit Exceeded")
              } else {
                  viewModel.cartItem[indexPath.row].count = currentCount + 1
                  viewModel2.incrementProductCount(for: product)
              }
          } else {
              viewModel.cartItem[indexPath.row].count = 1
              viewModel2.incrementProductCount(for: product)
          }
         productTableView.reloadData()
      }

    func decrementProductCount(at indexPath: IndexPath) {
          let product = viewModel.cartItem[indexPath.row]
          if let currentCount = product.count, currentCount > 1 {
              viewModel.cartItem[indexPath.row].count = currentCount - 1
          } else {
              viewModel.cartItem[indexPath.row].count = 1
          }
           viewModel2.decrementProductCount(for: product)
//           productTableView.reloadData()
      }
      
    func saveProductForLater(at indexPath: IndexPath) {
        guard indexPath.row < cartItems.count else {
            print("Invalid index path.")
            return
        }
        var product = cartItems[indexPath.row]
        product.saveForLater = true
        viewModel2.moveItemToSavedForLater(itemData: product) { [weak self] success in
            if success {
                print("Item moved to 'Saved for Later'")
                self?.cartItems.remove(at: indexPath.row)
                self?.savedForLaterItems.append(product)
                self?.updateTotalPriceLabel()
                self?.productDetailVc.updateCartBadge()

//                self?.productTableView.reloadData()
            } else {
                print("Failed to move item to 'Saved for Later'")
            }
        }
    }

    func moveToCart(at indexPath: IndexPath) {
        var product = savedForLaterItems[indexPath.row]
        product.saveForLater = false
        cartItems.append(product)
        savedForLaterItems.remove(at: indexPath.row)
        updateTotalPriceLabel()
        productDetailVc.updateCartBadge()

//        productTableView.reloadData()
        viewModel2.moveItemToCart(itemData: product) { success in
            if success {
                print("Item moved to cart in Core Data")
            } else {
                print("Failed to move item to cart in Core Data")
            }
        }
    }

    func convertDateToDisplayFormat(dateString: String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        if let date = dateFormatter.date(from: dateString) {
            dateFormatter.timeZone = TimeZone.current
            dateFormatter.dateFormat = "dd/MM/yyyy"
            return dateFormatter.string(from: date)
        }
        return nil
    }
    
    func deleteCartItem(at indexPath: IndexPath) {
            let product = cartItems[indexPath.row]
            viewModel2.deleteCartItem(product: product) { success in
                if success {
                    self.cartItems.remove(at: indexPath.row)
                    self.productTableView.deleteRows(at: [indexPath], with: .fade)
                    self.updateTotalPriceLabel()
                    self.productDetailVc.updateCartBadge()
                } else {
                    print("Failed to delete cart item.")
                }
            }
        }

        func deleteSavedItem(at indexPath: IndexPath) {
            let product = savedForLaterItems[indexPath.row]
            viewModel2.deleteSavedItem(product: product) { success in
                if success {
                    self.savedForLaterItems.remove(at: indexPath.row)
                    self.productTableView.deleteRows(at: [indexPath], with: .fade)
                } else {
                    print("Failed to delete saved item.")
                }
            }
        }
    }

extension ViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return cartItems.count
        } else if section == 1 {
            return savedForLaterItems.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                let cell = tableView.dequeueReusableCell(withIdentifier: "productCellIdentifier", for: indexPath) as! ProductTableViewCell
                var product: Product
                if indexPath.section == 0 {
                    product = cartItems[indexPath.row]
                } else {
                    product = savedForLaterItems[indexPath.row]
                }

                cell.product = product
                cell.productTitleLabel.text = product.title
                cell.productPriceLabel.text = "Rs.\(product.price ?? "")"
                cell.countLabel.text = indexPath.section == 0 ? "\(product.count ?? 1)" : nil
                cell.incrementButton.isHidden = indexPath.section == 0 ? false : true
                cell.decrementButton.isHidden = indexPath.section == 0 ? false : true
                cell.decrementButton.isEnabled = (product.count ?? 1) > 1
    
                if let dateString = product.date {
                    if let localDateString = convertDateToDisplayFormat(dateString: dateString) {
                        cell.dateLabel.text = localDateString
                    } else {
                        cell.dateLabel.text = ""
                    }
                } else {
                    cell.dateLabel.text = ""
                }

                if let imageURL = product.image {
                    if let url = URL(string: imageURL) {
                        DispatchQueue.global().async {
                            if let data = try? Data(contentsOf: url) {
                                let image = UIImage(data: data)
                                DispatchQueue.main.async {
                                    cell.productImageView.image = image
                                }
                            }
                        }
                    }
                } else {
                    cell.productImageView.image = nil
                }
                updateButtonTitle(for: cell, at: indexPath)
    
        cell.incrementAction = { [weak self] in
            self?.viewModel2.incrementProductCount(for: product)
            self?.refreshData()
        }
    
        cell.decrementAction = { [weak self] in
            self?.viewModel2.decrementProductCount(for: product)
            self?.refreshData()
        }
    
     cell.saveForLaterAction = { [weak self] in
        guard let self = self else { return }
        if indexPath.section == 0 {
            self.saveProductForLater(at: indexPath)
        } else if indexPath.section == 1 {
            self.moveToCart(at: indexPath)
        }
        self.refreshData()
    }
     return cell
   }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 && !cartItems.isEmpty || section == 1 && !savedForLaterItems.isEmpty {
            let title = section == 0 ? "Cart" : "Saved for Later"
            let count = section == 0 ? cartItems.reduce(0) { $0 + ($1.count ?? 0) } : savedForLaterItems.reduce(0) { $0 + ($1.count ?? 0) }
            
            let headerHeight: CGFloat = 30
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: headerHeight))
            headerView.backgroundColor = UIColor.systemGray
            
            let titleLabel = UILabel(frame: CGRect(x: 16, y: 0, width: tableView.frame.width - 32, height: headerHeight))
            titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
            titleLabel.textColor = UIColor.white
            titleLabel.text = "\(title) (\(count))"
            headerView.addSubview(titleLabel)
            
            return headerView
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (section == 0 && !cartItems.isEmpty) || (section == 1 && !savedForLaterItems.isEmpty) ? 30 : CGFloat.leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if indexPath.section == 0 {
                deleteCartItem(at: indexPath)
            } else if indexPath.section == 1 {
                deleteSavedItem(at: indexPath)
            }
        }
    }
}

extension ViewController: CartViewControllerDelegate {
    func didSelectProductImages(_ images: [UIImage]) {
        if let shippingVC = navigationController?.viewControllers.first(where: { $0 is ShippingScreenViewController }) as? ShippingScreenViewController {
            shippingVC.productImages = images
            shippingVC.shippingTableView.reloadData()
        }
    }
}



