//
//  ProductTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 07/07/23.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    
    var product: Product?
    var viewModel = Screen3ViewModel()
    
    @IBOutlet weak var productImageView: UIImageView!
    
    @IBOutlet weak var productTitleLabel: UILabel!
    
    @IBOutlet weak var productPriceLabel: UILabel!
    
    @IBOutlet weak var decrementButton: UIButton!
    
    @IBOutlet weak var incrementButton: UIButton!
    
    @IBOutlet weak var countLabel: UILabel!
    
    @IBOutlet weak var saveForLaterButton: UIButton!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    var incrementAction: (() -> Void)?
    var decrementAction: (() -> Void)?
    var saveForLaterAction: (() -> Void)?
    
    @IBAction func incrementButtonAction(_ sender: Any) {
        incrementAction?()
    }
    
    @IBAction func decrementButtonAction(_ sender: Any) {
        decrementAction?()
    }
    
    @IBAction func saveForLaterAction(_ sender: Any) {
        saveForLaterAction?()
    }
    
   
}
