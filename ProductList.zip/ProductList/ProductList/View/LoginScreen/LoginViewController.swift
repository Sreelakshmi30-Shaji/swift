//
//  LoginViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 14/08/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var userNameInputField: InputField!
    
    @IBOutlet weak var passwordInputField: InputField!
    
    @IBOutlet weak var loginButton: UIButton!
    
    var signUpViewModel = SignUpViewModel()
    var toastView = ToastView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameInputField.setViewData(contentLabel: "Username", placeholder: "Enter your username",tag: 0,text: "")
        passwordInputField.setViewData(contentLabel: "Password", placeholder: "Enter your password",tag: 1,text: "")
       
        signUpViewModel.printPersistentStoreInfo()

    }

    @IBAction func loginButtonTapped(_ sender: Any) {
        guard let username = userNameInputField.contentTextField.text,
              let password = passwordInputField.contentTextField.text else {
            return
        }
        
        if let user = signUpViewModel.fetchUser(userName: username),
           user.password == password {
            print("Login successful!")
            
            user.isLogin = true
            signUpViewModel.saveContext()
             
            let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
            toastView.translatesAutoresizingMaskIntoConstraints = false
            self.view.addSubview(toastView)
            toastView.show(message: "Login Successfull")
//            let storyboard = UIStoryboard(name: "Main", bundle: nil) // Use your storyboard name
//            let tabBarController = storyboard.instantiateViewController(withIdentifier: "MyTabBarControllerIdentifier") as! MyTabBarController
//              DispatchQueue.main.async {
//                if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
//                    appDelegate.window?.rootViewController = tabBarController
//                }
//            }

            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let productListVC = storyboard.instantiateViewController(withIdentifier: "ProductCollectionViewController") as! ProductCollectionViewController
            navigationController?.pushViewController(productListVC, animated: true)

            
        } else {
            print("Login failed. Invalid username or password.")
            let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
            toastView.translatesAutoresizingMaskIntoConstraints = false
            self.view.addSubview(toastView)
            toastView.show(message: "Login Failed")
        }
    }
}
