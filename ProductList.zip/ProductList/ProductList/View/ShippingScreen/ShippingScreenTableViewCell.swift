//
//  ShippingScreenTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 20/08/23.
//


import UIKit

protocol ShippingScreenTableViewCellDelegate: AnyObject {
    func addressButtonTapped()
}

class ShippingScreenTableViewCell: UITableViewCell {
    
    weak var delegate: ShippingScreenTableViewCellDelegate?
    var products: [Product] = []
    var deliveryOptions = ["Home", "Office", "Other"]
    
    var productImages: [UIImage] = []
    var showRemainingImages = false
    
    @IBOutlet weak var shippingScreenView: UIView!
    
    @IBOutlet weak var deliveryOptionLabel: UILabel!
    
    @IBOutlet weak var dropDownButton: UIButton!
    
    @IBOutlet weak var addressButton: UIButton!
        
    @IBOutlet weak var loadMoreImagesButton: UIButton!
    
    @IBOutlet weak var shippingCollectionView: UICollectionView!
    
    override func awakeFromNib() {
            super.awakeFromNib()
             shippingCollectionView.delegate = self
             shippingCollectionView.dataSource = self
             let nib = UINib(nibName: "ShippingCollectionViewCell", bundle: nil)
             shippingCollectionView.register(nib, forCellWithReuseIdentifier: "shippingCollectionViewCellIdentifier")
   }
    
    @IBAction func addressButtonAction(_ sender: Any) {
        delegate?.addressButtonTapped()
    }
    
    @IBAction func dropDownButtonAction(_ sender: Any) {
        showDropDownMenu()
    }
    
    @IBAction func loadMoreImagesButtonAction(_ sender: Any) {

    }
 
    func showDropDownMenu() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        for option in deliveryOptions {
            let action = UIAlertAction(title: option, style: .default) { [weak self] _ in
                self?.dropDownButton.setTitle(option, for: .normal)
            }
            alertController.addAction(action)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        let viewController = findViewController()
        viewController?.present(alertController, animated: true, completion: nil)
     }
        
    private func findViewController() -> UIViewController? {
        var responder: UIResponder? = self
        while let nextResponder = responder?.next {
            if let viewController = nextResponder as? UIViewController {
                return viewController
            }
            responder = nextResponder
        }
        return nil
    }
}

extension ShippingScreenTableViewCell: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if showRemainingImages {
               return productImages.count
           } else {
               return min(5, productImages.count)
           }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ShippingCollectionViewCellIdentifier", for: indexPath) as! ShippingCollectionViewCell
        if showRemainingImages {
               cell.configure(with: productImages[indexPath.item])
           } else {
               if indexPath.item < 5 {
                   cell.configure(with: productImages[indexPath.item])
               } else {
                   cell.isHidden = true
               }
           }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
}
