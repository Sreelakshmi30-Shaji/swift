//
//  ShippingCollectionViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 01/09/23.
//

import UIKit

class ShippingCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var shippingImageView: UIImageView!
    
//    func configure(with product: Product) {
//        shippingImageView.image = UIImage(named: product.image ?? "")
//    }
    func configure(with image: UIImage) {
           shippingImageView.image = image
       }
}
