//
//  ShippingScreenViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 20/08/23.
//

import UIKit

class ShippingScreenViewController: UIViewController, ShippingScreenTableViewCellDelegate {
   
    @IBOutlet weak var shippingTableView: UITableView!
    var products: [Product] = []
    weak var delegate: CartViewControllerDelegate?
    var productImages: [UIImage] = []
    var cartItems: [Product] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Shipping Information"
        shippingTableView.delegate =  self
        shippingTableView.dataSource = self
        let nib = UINib(nibName: "ShippingScreenTableViewCell", bundle: nil)
        shippingTableView.register(nib, forCellReuseIdentifier: "ShippingScreenTableViewCellIdentifier")
        
    }
    
    func addressButtonTapped() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let productListVC = storyboard.instantiateViewController(withIdentifier: "AddressListViewController") as! AddressListViewController
            navigationController?.pushViewController(productListVC, animated: true)
        }
}

extension ShippingScreenViewController : UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ShippingScreenTableViewCellIdentifier", for: indexPath) as! ShippingScreenTableViewCell
        cell.delegate = self
        cell.products = products
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}



