//
//  SignUpViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 14/08/23.
//

import UIKit

class SignUpViewController: UIViewController,SignUpCellDelegate{
    
    var signUpViewModel = SignUpViewModel()
    var userRegistration: UserRegistration?
    var toastView = ToastView()

    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var signUpTableView: UITableView!
    @IBOutlet weak var viewProfileButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        signUpTableView.register(UINib(nibName: "SignUpTableViewCell", bundle: nil), forCellReuseIdentifier: "SignUpCell")
        signUpTableView.delegate = self
        signUpTableView.dataSource = self
        userRegistration = UserRegistration()
        signUpViewModel.printPersistentStoreInfo()
       
        updateSignUpButtonState()
        
    }
    
    @IBAction func viewProfileButtonAction(_ sender: Any) {
        let viewProfileVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewProfileViewController") as! ViewProfileViewController
            navigationController?.pushViewController(viewProfileVC, animated: true)
        
    }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        var isValid = true

           for tag in 0..<7 {
               if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
                   let inputText = cell.inputField.contentTextField.text ?? ""
                   signUpViewModel.validateAndShowErrors(for: tag, text: inputText)

                   if !signUpViewModel.isValidationHidden(for: tag) {
                       cell.inputField.validationLabel.text = signUpViewModel.validationErrors[tag]
                       cell.inputField.validationLabel.isHidden = false
                       isValid = false
                   } else {
                       cell.inputField.validationLabel.isHidden = true
                   }
               }
           }
           
           // Check if passwords match
           if let confirmPasswordCell = signUpTableView.cellForRow(at: IndexPath(row: 6, section: 0)) as? SignUpTableViewCell {
               let confirmPasswordText = confirmPasswordCell.inputField.contentTextField.text ?? ""
               if !signUpViewModel.passwordsMatch(password: confirmPasswordText, confirmPassword: userRegistration?.password ?? "") {
                   confirmPasswordCell.inputField.validationLabel.text = "Passwords do not match"
                   confirmPasswordCell.inputField.validationLabel.isHidden = false
                   isValid = false
               }
           }

           if isValid {
               // Perform the sign-up process
               signUpViewModel.addItemToCoreData(itemData: userRegistration!) { success in
                   if success {
                       let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                       toastView.translatesAutoresizingMaskIntoConstraints = false
                       self.view.addSubview(toastView)
                       toastView.show(message: "Registration Successful")
                       self.navigationController?.popViewController(animated: true)
                   } else {
                       let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                       toastView.translatesAutoresizingMaskIntoConstraints = false
                       self.view.addSubview(toastView)
                       toastView.show(message: "Registration Failed")
                   }
               }
           }
    }
    
    func updateSignUpButtonState() {
        let areAllFieldsValid = (0..<7).allSatisfy { tag in
            return signUpViewModel.isValidationHidden(for: tag)
        }
        signUpButton.isEnabled = areAllFieldsValid
        signUpButton.alpha = areAllFieldsValid ? 1.0 : 0.5
    }


    func didEndEditing(tag: Int, text: String) {
        print("Editing ended for tag \(tag) with text: \(text)")
        
        switch tag {
        case 0:
            userRegistration?.firstName = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isNotEmpty, errorMessage: "Please enter your first name")
        case 1:
            userRegistration?.lastName = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isNotEmpty, errorMessage: "Please enter your last name")
        case 2:
            userRegistration?.phoneNumber = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidPhoneNumber, errorMessage: "Invalid phone number")
        case 3:
            userRegistration?.emailAddress = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidEmail, errorMessage: "Invalid email")
        case 4:
            userRegistration?.userName = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidUsername, errorMessage: "Please enter a valid username")
        case 5:
            userRegistration?.password = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidPassword, errorMessage: "Please enter a valid password")
        case 6:
            userRegistration?.confirmPassword = text
            validateAndShowError(for: tag, text: text, validationBlock: { [weak self] confirmPassword in
                guard let password = self?.userRegistration?.password else { return false }
                return self?.signUpViewModel.passwordsMatch(password: confirmPassword, confirmPassword: password) ?? false
            }, errorMessage: "Passwords do not match")
        default:
            break
        }
       
        if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
            if signUpViewModel.isValidationHidden(for: tag) {
                cell.inputField.validationLabel.isHidden = true
            }
        }
        updateSignUpButtonState()
    }

    func validateAndShowError(for tag: Int, text: String, validationBlock: (String) -> Bool, errorMessage: String) {
        let isValid = validationBlock(text)
        if isValid {
            signUpViewModel.hideErrorValidation(tag: tag)
        } else {
            signUpViewModel.showErrorValidation(tag: tag, message: errorMessage)
            
            if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
                cell.inputField.validationLabel.text = errorMessage
                cell.inputField.validationLabel.isHidden = false
            }
        }
    }


}

extension SignUpViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SignUpTableViewCell.cell(for: tableView, at: indexPath)
        cell.delegate = self
        switch indexPath.row {
        case 0:
            cell.setCellData(contentLabel: "First Name", placeholder: "Enter your first name", tag: 0, text: userRegistration?.firstName ?? "")
        case 1:
            cell.setCellData(contentLabel: "Last Name", placeholder: "Enter your last name", tag: 1, text: userRegistration?.lastName ?? "")
        case 2:
            cell.setCellData(contentLabel: "Phone Number", placeholder: "Enter your phone number", tag: 2, text: userRegistration?.phoneNumber ?? "")
        case 3:
            cell.setCellData(contentLabel: "Email Address", placeholder: "Enter your email id", tag: 3, text: userRegistration?.emailAddress ?? "")
        case 4:
            cell.setCellData(contentLabel: "User Name", placeholder: "Enter your user name", tag: 4, text: userRegistration?.userName ?? "")
        case 5:
            cell.setCellData(contentLabel: "Password", placeholder: "Enter your password", tag: 5, text: userRegistration?.password ?? "")
        case 6:
            cell.setCellData(contentLabel: "Confirm Password", placeholder: "Confirm Your Password", tag: 6, text: userRegistration?.confirmPassword ?? "")
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}

