//
//  ViewProfileViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 08/09/23.
//

import UIKit

class ViewProfileViewController: UIViewController {
    
    @IBOutlet weak var viewProfileTableView: UITableView!
    
    var viewProfileData: [UserRegistration] = []
    var signupViewModel = SignUpViewModel()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewProfileTableView.dataSource = self
        viewProfileTableView.delegate = self
        viewProfileTableView.register(UINib(nibName: "SignUpTableViewCell", bundle: nil), forCellReuseIdentifier: "SignUpCell")
        self.title = "My Profile"
        fetchData()
    }
    func fetchData() {
            signupViewModel.retrieveData { [weak self] (userData, error) in
                if let error = error {
                    print("Error retrieving data: \(error)")
                } else if let userData = userData {
                    self?.viewProfileData = userData
                    self?.viewProfileTableView.reloadData()
                    print("Retrieved user data: \(userData)")
                }
            }
        }
}

extension ViewProfileViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewProfileData.count * 6 // 7 fields for each user profile
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SignUpCell", for: indexPath) as! SignUpTableViewCell
        let userProfile = viewProfileData[indexPath.row / 6]
        let fieldIndex = indexPath.row % 6
        let fieldText = getFieldText(userProfile, atIndex: fieldIndex)
        
        // Configure the cell to display the user profile field
        cell.setCellData(
            contentLabel: "",
            placeholder: "", // No need for a placeholder in this case
            tag: indexPath.row,
            text: fieldText
        )
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    private func getFieldText(_ userProfile: UserRegistration, atIndex index: Int) -> String {
        switch index {
        case 0:
            if let firstName = userProfile.firstName {
                return "First Name: \(firstName)"
            }
        case 1:
            if let lastName = userProfile.lastName {
                return "Last Name: \(lastName)"
            }
        case 2:
            if let phoneNumber = userProfile.phoneNumber {
                return "Phone Number: \(phoneNumber)"
            }
        case 3:
            if let emailAddress = userProfile.emailAddress {
                return "Email Address: \(emailAddress)"
            }
        case 4:
            if let userName = userProfile.userName {
                return "User Name: \(userName)"
            }
        case 5:
            if let password = userProfile.password {
                return "Password: \(password)"
            }
        case 6:
            if let confirmPassword = userProfile.confirmPassword {
                return "Confirm Password: \(confirmPassword)"
            }
        default:
            return ""
        }
        return ""
    }
}

