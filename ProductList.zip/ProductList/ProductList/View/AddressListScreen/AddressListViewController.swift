//
//  AddressListViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 20/08/23.
//

import UIKit
import CoreData


class AddressListViewController: UIViewController, AddressListTableViewCellDelegate, AddAddressScreenDelegate {
    
    @IBOutlet weak var addressListTableView: UITableView!
    @IBOutlet weak var addAddressButton: UIButton!
    
    weak var delegate: AddAddressScreenDelegate?
    
    var addresses: [Address] = []
    var addressViewModel = AddressViewModel()
    
    let noAddressLabel: UILabel = {
        let label = UILabel()
        label.text = "No Address Found"
        label.textAlignment = .center
        label.textColor = .gray
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        addAddressButton.layer.cornerRadius = 20
        addressListTableView.dataSource = self
        addressListTableView.delegate = self
        let nib = UINib(nibName: "AddressListTableViewCell", bundle: nil)
        addressListTableView.register(nib, forCellReuseIdentifier: "AddressListTableViewCellIdentifier")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addressViewModel.retrieveData { [weak self] retrievedAddresses, error in
            if let error = error {
                print("Error retrieving addresses: \(error)")
            } else if let addresses = retrievedAddresses {
                self?.addresses = addresses
                self?.addressListTableView.reloadData()
            }
        }
    }
    
    @IBAction func addAddressButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let productListVC = storyboard.instantiateViewController(withIdentifier: "AddAddressScreenViewController") as! AddAddressScreenViewController
        navigationController?.pushViewController(productListVC, animated: true)
    }
    
    func editButtonTapped(cell: AddressListTableViewCell) {
        guard let indexPath = addressListTableView.indexPath(for: cell) else {
            return
        }
        let selectedAddress = addresses[indexPath.row]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let addAddressVC = storyboard.instantiateViewController(withIdentifier: "AddAddressScreenViewController") as! AddAddressScreenViewController
        addAddressVC.addressToUpdate = selectedAddress 
        addAddressVC.isEditingAddress = true
        addAddressVC.delegate = self
        navigationController?.pushViewController(addAddressVC, animated: true)
    }

    func addressUpdated() {
        addressViewModel.retrieveData { [weak self] retrievedAddresses, error in
            if let error = error {
                print("Error retrieving addresses: \(error)")
            } else if let addresses = retrievedAddresses {
                self?.addresses = addresses
                self?.addressListTableView.reloadData()
            }
        }
        
    }

 }

extension AddressListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if addresses.isEmpty {
               tableView.backgroundView = noAddressLabel
               tableView.separatorStyle = .none
               return 0
           } else {
               tableView.backgroundView = nil
               tableView.separatorStyle = .singleLine
               return addresses.count
           }
        }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddressListTableViewCellIdentifier", for: indexPath) as! AddressListTableViewCell
        if addresses.isEmpty {
                noAddressLabel.text = "No Address Found"
                addAddressButton.isHidden = false
            } else {
                let address = addresses[indexPath.row]
                cell.addressListView.contentLabel.numberOfLines = 0
                if let address1 = address.address1,
                    let address2 = address.address2,
                    let state = address.state,
                    let country = address.country,
                    let pincode = address.pincode {
            let addressText = """
                        \(address1)
                        \(address2)
                        \(state)
                        \(country)
                        \(pincode)
                    """
                cell.addressListView.contentLabel.text = addressText
                }
                cell.editButton.setTitle("Edit", for: .normal)
                cell.delegate = self
            }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
