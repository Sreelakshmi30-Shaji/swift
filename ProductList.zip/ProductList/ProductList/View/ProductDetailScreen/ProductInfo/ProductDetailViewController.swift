//
//  ProductDetailViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 19/07/23.
//

import UIKit
import UIKit

class ProductDetailViewController: UIViewController {
    
    var productTitle: String?
    var product: Product?
    let viewModel = Screen2ViewModel()
    var cartItems: [Product] = []
    var savedForLaterItems: [Product] = []

    @IBOutlet weak var productDetailTableView: UITableView!
    @IBOutlet weak var buttonCart: UIBarButtonItem!

    let sampleProducts: [ProductDetails] = [
        ProductDetails(title: "iPhoneX iPhoneX iPhoneX iPhoneX iPhoneX iPhoneX iPhoneX", price: "Rs.10000000000000000000000000000000000000000", rating: "4.555555555555555555555555555555555555555555555555555",image: UIImage(named: "image1")!),
        ProductDetails(title: "Plant Hanger Plant Hanger Plant Hanger Plant Hanger Plant Hanger Plant Hanger Plant Hanger Plant Hanger", price: "Rs.300", rating:"4.222222222222222222222222222222222222222222222222222222222222222222",image: UIImage(named: "image5")!)
      // ProductDetails(title: "Macbook Pro", price: "Rs.1000", rating: "3.8",image: UIImage(named: "image2")!),
      // ProductDetails(title: "Key Holder", price: "Rs.500", rating: "4.2",image: UIImage(named: "image4")!),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        productDetailTableView.register(UINib(nibName: "ProductDetailImageTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductImageCell")
        productDetailTableView.register(UINib(nibName: "ProductDetailLabelsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductInfoCell")
        productDetailTableView.register(UINib(nibName: "ProductDetailViewSellerTableViewCell", bundle: nil), forCellReuseIdentifier: "SellerInfoCell")
        productDetailTableView.register(UINib(nibName: "ProductDetailButtonTableViewCell", bundle: nil), forCellReuseIdentifier: "AddToCartCell")
        productDetailTableView.register(UINib(nibName: "SampleTableViewCell", bundle: nil), forCellReuseIdentifier: "SampleTableViewCellIdentifier")

        productDetailTableView.delegate = self
        productDetailTableView.dataSource = self
        
        title = productTitle
        
        viewModel.printPersistentStoreInfo()
    
        updateCartBadge()
    }
    
    func updateCartBadge() {
        
        let badgeCount = cartItems.reduce(0) { (result, product) in
               if let count = product.count {
                   print("Adding \(count) for product: \(product.title ?? "")")
                   return result + Int(count)
               } else {
                   print("Skipping product with missing count: \(product.title ?? "")")
                   return result
               }
         }
         if let image = UIImage(named: "cart") {
            let buttonSize = CGSize(width: 60, height: 60)

            let customButton = UIButton(type: .custom)
            customButton.setImage(image, for: .normal)
            customButton.frame = CGRect(origin: .zero, size: buttonSize)
            customButton.addTarget(self, action: #selector(buttonCartAction), for: .touchUpInside)

            let customBarButtonItem = UIBarButtonItem(customView: customButton)
            navigationItem.rightBarButtonItem = customBarButtonItem

            let badgeLabel = UILabel()
            badgeLabel.backgroundColor = .red
            badgeLabel.textColor = .white
            badgeLabel.font = UIFont.boldSystemFont(ofSize: 12)
            badgeLabel.textAlignment = .center
            badgeLabel.layer.cornerRadius = badgeLabel.bounds.size.height / 2
            badgeLabel.layer.masksToBounds = true
            badgeLabel.translatesAutoresizingMaskIntoConstraints = false
            badgeLabel.text = "\(badgeCount)"
            badgeLabel.isHidden = badgeCount == 0
            
            customButton.addSubview(badgeLabel)

            NSLayoutConstraint.activate([
                badgeLabel.trailingAnchor.constraint(equalTo: customButton.trailingAnchor, constant: -4),
                badgeLabel.topAnchor.constraint(equalTo: customButton.topAnchor, constant: 4),
                badgeLabel.widthAnchor.constraint(equalToConstant: 15),
                badgeLabel.heightAnchor.constraint(equalToConstant: 15)
            ])
            NSLayoutConstraint.activate([
                       customButton.widthAnchor.constraint(equalToConstant: buttonSize.width),
                       customButton.heightAnchor.constraint(equalToConstant: buttonSize.height)
                   ])
        }
    }

    @IBAction func buttonCartAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let productTableVC = storyboard.instantiateViewController(withIdentifier: "ProductTableViewController") as! ViewController
        navigationController?.pushViewController(productTableVC, animated: true)
    }
}

extension ProductDetailViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return 7
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductImageCell", for: indexPath) as! ProductDetailImageTableViewCell
            if let imageURL = product?.image {
                if let url = URL(string: imageURL) {
                    DispatchQueue.global().async {
                        if let data = try? Data(contentsOf: url) {
                            let image = UIImage(data: data)
                             DispatchQueue.main.async {
                                cell.detailImageView.image = image
                            }
                        }
                    }
                }
            }
            return cell
        } else if indexPath.row == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductInfoCell", for: indexPath) as! ProductDetailLabelsTableViewCell
            if let product = product {
                cell.productLabel.text = product.title
            }
            return cell
        } else if indexPath.row == 2 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductInfoCell", for: indexPath) as! ProductDetailLabelsTableViewCell
            if let product = product {
                cell.productLabel.text = "Rs.\(product.price ?? "")"
            }
            return cell
        } else if indexPath.row == 3 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SellerInfoCell", for: indexPath) as! ProductDetailViewSellerTableViewCell
            cell.viewSellerLabel.text = "View Sellers"
            return cell
        } else if indexPath.row == 4 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddToCartCell", for: indexPath) as! ProductDetailButtonTableViewCell
            cell.product = product
            return cell
        }  else if indexPath.row == 5 {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "SampleTableViewCellIdentifier", for: indexPath) as! SampleTableViewCell
                    let sampleProduct = sampleProducts[indexPath.row - 5] 
                    cell.sampleLabelTitle.text = sampleProduct.title
                    cell.sampleLabelPrice.text = sampleProduct.price
                    cell.sampleLabelRating.text = "Rating: \(sampleProduct.rating)"
                    cell.sampleImageView.image = sampleProduct.image
                    return cell
       } else if indexPath.row == 6 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SampleTableViewCellIdentifier", for: indexPath) as! SampleTableViewCell
            let sampleProduct = sampleProducts[indexPath.row - 5]
            cell.sampleLabelTitle.text = sampleProduct.title
            cell.sampleLabelPrice.text = ""
            cell.sampleLabelPrice.isHidden = true
            cell.sampleLabelRating.text = "Rating: \(sampleProduct.rating)"
            cell.sampleImageView.image = sampleProduct.image
            return cell
        }
         return UITableViewCell()
    }
      
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 300
        } else if indexPath.row == 1 {
            return 80
        } else if indexPath.row == 2 {
            return 40
        } else if indexPath.row == 3 {
            return 40
        } else if indexPath.row == 4 {
            return 60
        }
        else {
            return UITableView.automaticDimension
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            if indexPath.row == 3 {
                guard let selectedProduct = product else {
                    return
                }
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let sellerInfoVC = storyboard.instantiateViewController(withIdentifier: "SellerInfoProductTableViewController") as! SellerInfoViewController
                sellerInfoVC.product = selectedProduct
                navigationController?.pushViewController(sellerInfoVC, animated: true)
            }
        }
    }

