//
//  ProductDetailButtonTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit

class ProductDetailButtonTableViewCell: UITableViewCell {
        
    var viewModel = Screen2ViewModel()
    var product : Product?
    var productDetailVc = ProductDetailViewController()
    var cartItems : [Product] = []


    @IBOutlet weak var addToCartButton: UIButton!
    
    @IBAction func addToCartButtonAction(_ sender: Any) {
        guard let product = product else {
                   print("Product data is missing.")
                   return
               }
        productDetailVc.updateCartBadge()
        viewModel.addItemToCoreData(itemData: product) { success in
                   if success {
                       print("Item added to Core Data")
                   } else {
                       print("Failed to add item to Core Data")
                   }
               }
    }
    
}
