//
//  PaginationTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit

class PaginationTableViewCell: UITableViewCell {

    @IBOutlet weak var loadNextPageButton: UIButton!
    
    var loadNextPageButtonTapped: ((_ contentString: String?) -> Void)?

    @IBAction func loadNextPageButonAction(_ sender: Any) {
        loadNextPageButtonTapped?("sampleproduct")
    }
}
