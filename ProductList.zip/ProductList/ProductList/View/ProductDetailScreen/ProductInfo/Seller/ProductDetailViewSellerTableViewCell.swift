//
//  ProductDetailViewSellerTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit

class ProductDetailViewSellerTableViewCell: UITableViewCell {

    @IBOutlet weak var viewSellerLabel: UILabel!
    
}
