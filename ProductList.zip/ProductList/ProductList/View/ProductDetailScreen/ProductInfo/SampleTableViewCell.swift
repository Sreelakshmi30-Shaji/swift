//
//  SampleTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 04/08/23.
//

import UIKit

class SampleTableViewCell: UITableViewCell {

    @IBOutlet weak var sampleImageView: UIImageView!
    
    @IBOutlet weak var sampleLabelTitle: UILabel!
    
    @IBOutlet weak var sampleLabelPrice: UILabel!
    
    @IBOutlet weak var sampleLabelRating: UILabel!
    
}
