//
//  ProductDetailLabelsTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit

class ProductDetailLabelsTableViewCell: UITableViewCell {

    @IBOutlet weak var productLabel: UILabel!
    
}
