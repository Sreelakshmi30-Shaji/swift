//
//  ProductDetailImageTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit

class ProductDetailImageTableViewCell: UITableViewCell {

   
    @IBOutlet weak var detailImageView: UIImageView!
    
}
