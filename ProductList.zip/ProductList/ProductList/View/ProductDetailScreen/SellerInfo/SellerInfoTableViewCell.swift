//
//  SellerInfoTableViewCell.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit


class SellerInfoTableViewCell: UITableViewCell {
    @IBOutlet weak var sellerInfoLabel: UILabel!
    
}
