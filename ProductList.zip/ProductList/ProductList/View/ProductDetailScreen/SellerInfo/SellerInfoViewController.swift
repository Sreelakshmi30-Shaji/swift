//
//  SellerInfoViewController.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import UIKit

class SellerInfoViewController: UIViewController {
    
    @IBOutlet weak var sellerTableView: UITableView!

    var product: Product?

    override func viewDidLoad() {
        super.viewDidLoad()

        sellerTableView.dataSource = self
        sellerTableView.delegate = self
        sellerTableView.register(UINib(nibName: "SellerInfoTableViewCell", bundle: nil), forCellReuseIdentifier: "SellerInfoIdentifier")
        sellerTableView.register(UINib(nibName: "PaginationTableViewCell", bundle: nil), forCellReuseIdentifier: "PaginationCellIdentifier")

    }
    
    func loadNextPageButtonTapped(){
        print("Tapped")
    }
}

extension SellerInfoViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if section == 0 {
                return min(6, product?.sellers?.count ?? 0)
                
            } else {
                return 1
            }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if indexPath.section == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "SellerInfoIdentifier", for: indexPath) as! SellerInfoTableViewCell
                
                if let seller = product?.sellers?[indexPath.row] {
                    var sellerInfoText = "Seller Information:"
                    if let sellerName = seller.sellerName {
                        sellerInfoText += "\nSeller Name : \(sellerName)"
                    }
                    if let sellerRating = seller.sellerRating {
                        sellerInfoText += "\nRating : \(sellerRating)"
                    }
                    if let sellerLocation = seller.sellerLocation {
                        sellerInfoText += "\nLocation : \(sellerLocation)"
                    }
                    cell.sellerInfoLabel.text = sellerInfoText
                }
                
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "PaginationCellIdentifier", for: indexPath) as! PaginationTableViewCell
                cell.loadNextPageButton.isHidden = false
                cell.loadNextPageButtonTapped = { [weak self] prodstr in
                    guard let self = self else {return}
                    self.loadNextPageButtonTapped()
                }
                return cell
            }
        }
        
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 {
                    return 60 
                } else {
                    return UITableView.automaticDimension
                }
       }
}

