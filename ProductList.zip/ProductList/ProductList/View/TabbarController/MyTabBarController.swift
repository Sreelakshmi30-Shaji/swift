//
//  MyTabBarController.swift
//  ProductList
//
//  Created by Sreelakshmi on 08/09/23.
//

import UIKit

class MyTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
