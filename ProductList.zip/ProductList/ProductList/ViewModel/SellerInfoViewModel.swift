//
//  SellerInfoViewModel.swift
//  ProductList
//
//  Created by Sreelakshmi on 27/07/23.
//

import Foundation

class SellerInfoViewModel {
    var currentPage: Int = 1 
    let sellersPerPage: Int = 6
   var allSellers: [Seller] = []

    func fetchSellersFromAPI(completion: @escaping (Error?) -> Void) {
        let urlString = "https://demo6641443.mockable.io/ProductList?page=\(currentPage)"
        guard let url = URL(string: urlString) else {
            completion(nil) // Invalid URL
            return
        }
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                completion(error)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(nil) // Invalid response
                return
            }
            let statusCode = httpResponse.statusCode
            if (200...299).contains(statusCode), let data = data {
                do {
                    let decoder = JSONDecoder()
                    decoder.keyDecodingStrategy = .convertFromSnakeCase
                    let sellers = try decoder.decode([Seller].self, from: data)
                    if sellers.isEmpty {
                        completion(nil)
                    } else {
                        self?.allSellers.append(contentsOf: sellers)
                        self?.currentPage += 1
                        completion(nil) // Successful response
                    }
                } catch {
                    print("JSON decoding error: \(error)")
                    completion(error) // JSON decoding error
                }
            } else {
                print("Response is a failure. Status code: \(statusCode)")
                completion(nil) // Request failed
            }
        }.resume()
    }

    func getSellers(for page: Int) -> [Seller] {
        let startIndex = (page - 1) * sellersPerPage
        let endIndex = min(startIndex + sellersPerPage, allSellers.count)
        return Array(allSellers[startIndex..<endIndex])
    }
}
