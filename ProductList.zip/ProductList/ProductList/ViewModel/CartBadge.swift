//
//  CartBadge.swift
//  ProductList
//
//  Created by Sreelakshmi on 25/07/23.
//

import UIKit

class CartBadge {
    static let shared = CartBadge()

        var cartItems: [Product] = []
        var savedForLaterItems: [Product] = []
        
        func addToCart(_ product: Product) {
            cartItems.append(product)
        }
        
//        func removeFromCart(_ product: Product) {
//            if let index = cartItems.firstIndex(of: product) {
//                cartItems.remove(at: index)
//            }
//        }
    
}
