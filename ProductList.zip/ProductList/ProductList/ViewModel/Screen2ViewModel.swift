//
//  Screen2ViewModel.swift
//  ProductList
//
//  Created by Sreelakshmi on 20/07/23.
//

import Foundation
import CoreData
import UIKit

class Screen2ViewModel {
    
    var cartItem: [Product] = []
    var view = ToastView()
    var productImages: [UIImage] = []
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "ProductList")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    var persistentStoreURL: URL? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.persistentStoreCoordinator.persistentStores.first?.url
    }
    
    func printPersistentStoreInfo() {
        if let storeURL = persistentStoreURL {
            print("Persistent Store URL: \(storeURL)")
        } else {
            print("No persistent store found.")
        }
        
        //        let cartItemCount = fetchCartItemCount()
        //        print("Number of items in Core Data store: \(cartItemCount)")
    }
    
    func setValues(for cartItemObject: NSManagedObject, with productItem: Product) {
        cartItemObject.setValue(productItem.id, forKey: "id")
        cartItemObject.setValue(productItem.title, forKey: "title")
        cartItemObject.setValue(productItem.image, forKey: "image")
        cartItemObject.setValue(productItem.price, forKey: "price")
        cartItemObject.setValue(1, forKey: "count")
        cartItemObject.setValue(productItem.saveForLater, forKey: "saveForLater")
        cartItemObject.setValue(productItem.date, forKey: "date")
    }
    
    func addItemToCoreData(itemData: Product, completion: @escaping (Bool) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        fetchRequest.predicate = NSPredicate(format: "id == %@", itemData.id)
        do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first as? NSManagedObject {
                let saveForLater = existingCartItem.value(forKey: "saveForLater") as? Bool ?? false ///to determine if the item is already marked as "Save for Later"
                if saveForLater {
                    let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Item is already in 'Save for Later'")
                    completion(false)
                    return
                }
                
                let currentCount = existingCartItem.value(forKey: "count") as? Int ?? 1 ///to retrieve the value of the attribute with the key "count" from the existingCartItem
                
                if currentCount >= 10 {
                    let toastView = ToastView(frame: CGRect(x: 110, y: 10, width: 200, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Limit Exceeded")
                    completion(false)
                    return
                } else {
                    existingCartItem.setValue(currentCount + 1, forKey: "count")/// the "count" attribute of existingCartItem will be updated to the new value, which is the current                                                                                                                                        value of "count" plus 1.
                }
            } else {
                ///no existing Core Data object matching the given criteria and a new managed object is created to represent a new item that will be added to Core Data.
                guard let cartEntity = NSEntityDescription.entity(forEntityName: "CartItem", in: managedObjectContext) else {
                    completion(false)
                    return
                }
                let item = NSManagedObject(entity: cartEntity, insertInto: managedObjectContext)
                setValues(for: item, with: itemData)
                item.setValue(false, forKey: "saveForLater")
            }
            
            let toastView = ToastView(frame: CGRect(x: 90, y: 700, width: 200, height: 50))
            toastView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(toastView)
            toastView.show(message: "Item added to Cart")
            
            try managedObjectContext.save()
            completion(true)
        } catch {
            print("Error saving item to Core Data: \(error)")
            completion(false)
        }
    }
    
    //    func fetchCartItemCount() -> Int {
    //        let fetchRequest: NSFetchRequest<CartItem> = CartItem.fetchRequest()
    //        do {
    //            let itemCount = try managedObjectContext.count(for: fetchRequest) ///to count the number of items in the "CartItem" entity.
    //            return itemCount
    //        } catch {
    //            print("Error fetching cart item count: \(error)")
    //            return 0
    //        }
    //    }
    //
    // Retrieve data from core data
    func retrieveData(completion: @escaping ([Product]?, Error?) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            cartItem = []  ///An empty array of Product objects initialized.
            if let dataObjects = result as? [NSManagedObject], !dataObjects.isEmpty {
                for data in dataObjects {
                    /// Extract attribute values from the NSManagedObject
                    let id = data.value(forKey: "id") as? String ?? ""
                    let title = data.value(forKey: "title") as? String ?? ""
                    let price = data.value(forKey: "price") as? String ?? ""
                    let image = data.value(forKey: "image") as? String ?? ""
                    let count = data.value(forKey: "count") as? Int32 ?? 0
                    let saveForLater = data.value(forKey: "saveForLater") as? Bool ?? false
                    let date = data.value(forKey: "date") as? String ?? ""
                    /// Create a Product object using the extracted attributes
                    let item = Product(id: id, title: title, price: price, image: image, count: count, saveForLater: saveForLater, date: date)
                    cartItem.append(item) /// Append the Product object to the cartItem array
                }
                completion(cartItem, nil)
            } else {
                completion(nil, nil)
            }
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }
    
    func calculateTotalProductCount() -> Int {
        return Int(cartItem.reduce(0) { $0 + ($1.count ?? 0) })
    }
    
    func loadProductImages(for items: [Product], completion: @escaping () -> Void) {
        let dispatchGroup = DispatchGroup()

        for item in items {
            if let imageURL = item.image, let url = URL(string: imageURL) {
                dispatchGroup.enter()

                DispatchQueue.global().async {
                    if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                        self.productImages.append(image)
                    }

                    dispatchGroup.leave()
                }
            }
        }

        dispatchGroup.notify(queue: .main) {
            completion()
        }
    }
}
   
