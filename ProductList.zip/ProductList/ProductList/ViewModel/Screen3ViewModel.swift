//
//  Screen3ViewModel.swift
//  ProductList
//
//  Created by Sreelakshmi on 20/07/23.
//
//
import Foundation
import CoreData
import UIKit

class Screen3ViewModel {
    
    var viewModel = Screen2ViewModel()
    var view = ToastView()
   
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "ProductList")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    func incrementProductCount(for product: Product) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        fetchRequest.predicate = NSPredicate(format: "id == %@", product.id)
         do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first as? NSManagedObject {
                let currentCount = existingCartItem.value(forKey: "count") as? Int ?? 1

                if currentCount >= 10 {
                    let toastView = ToastView(frame: CGRect(x: 110, y: 60, width: 200, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Limit Exceeded")
                    return 
                } else {
                    existingCartItem.setValue(currentCount + 1, forKey: "count")
                }
            } else {
                guard let cartEntity = NSEntityDescription.entity(forEntityName: "CartItem", in: managedObjectContext) else { return }
                let newCartItem = NSManagedObject(entity: cartEntity, insertInto: managedObjectContext)
                newCartItem.setValue(product.id, forKey: "id")
                newCartItem.setValue(1, forKey: "count")
            }
            try managedObjectContext.save()
        } catch {
            print("Error updating item count in Core Data: \(error)")
        }
    }

    func decrementProductCount(for product: Product) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        fetchRequest.predicate = NSPredicate(format: "id == %@", product.id)
        do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first as? NSManagedObject {
                let currentCount = existingCartItem.value(forKey: "count") as? Int ?? 0
                let newCount = max(currentCount - 1, 1)
                existingCartItem.setValue(newCount, forKey: "count")
                try managedObjectContext.save()
            }
        } catch {
            print("Error updating item count in Core Data: \(error)")
        }
    }

    func moveItemToSavedForLater(itemData: Product, completion: @escaping (Bool) -> Void) {
        let fetchRequest = NSFetchRequest<CartItem>(entityName: "CartItem")
        fetchRequest.predicate = NSPredicate(format: "id == %@", itemData.id)
        
        do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                existingCartItem.setValue(true, forKey: "saveForLater")
                try managedObjectContext.save()
                completion(true)
            } else {
                completion(false)
            }
        } catch {
            print("Error moving item to 'Saved for Later': \(error)")
            completion(false)
        }
    }
    
    func moveItemToCart(itemData: Product, completion: @escaping (Bool) -> Void) {
          let fetchRequest = NSFetchRequest<CartItem>(entityName: "CartItem")
          fetchRequest.predicate = NSPredicate(format: "id == %@", itemData.id)

          do {
              if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                  existingCartItem.setValue(false, forKey: "saveForLater")
                  try managedObjectContext.save()
                  completion(true)
              } else {
                  completion(false)
              }
          } catch {
              print("Error moving item to cart: \(error)")
              completion(false)
          }
      }
    
    func calculateTotalPrice(for cartItems: [Product]) -> Double {
           var totalPrice: Double = 0.0
           for product in cartItems {
               if let priceString = product.price,
                  let price = Double(priceString),
                  let count = product.count {
                   let countInt = Int(count)
                   totalPrice += price * Double(countInt)
               }
           }
           return totalPrice
       }
    
    func deleteCartItem(product: Product, completion: @escaping (Bool) -> Void) {
            let fetchRequest = NSFetchRequest<CartItem>(entityName: "CartItem")
            fetchRequest.predicate = NSPredicate(format: "id == %@", product.id)

            do {
                if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                    managedObjectContext.delete(existingCartItem)
                    try managedObjectContext.save()
                    completion(true)
                } else {
                    completion(false)
                }
            } catch {
                print("Error deleting cart item from Core Data: \(error)")
                completion(false)
            }
        }

        func deleteSavedItem(product: Product, completion: @escaping (Bool) -> Void) {
            let fetchRequest = NSFetchRequest<CartItem>(entityName: "CartItem")
            fetchRequest.predicate = NSPredicate(format: "id == %@ AND saveForLater == %@", product.id, NSNumber(value: true))

            do {
                if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                    managedObjectContext.delete(existingCartItem)
                    try managedObjectContext.save()
                    completion(true)
                } else {
                    completion(false)
                }
            } catch {
                print("Error deleting saved item from Core Data: \(error)")
                completion(false)
            }
        }
    }

