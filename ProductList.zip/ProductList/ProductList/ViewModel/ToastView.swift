//
//  ToastView.swift
//  ProductList
//
//  Created by Sreelakshmi on 21/07/23.
//

import Foundation
import UIKit

class ToastView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Configure the appearance of the toast view
        backgroundColor = UIColor.orange.withAlphaComponent(0.6)
        layer.cornerRadius = 10
        clipsToBounds = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show(message: String) {
        // Add the toast view to the view hierarchy
        guard let keyWindow = UIApplication.shared.keyWindow else {
            return
        }
        keyWindow.addSubview(self)
        
        // Add a label to display the message
        let label = UILabel(frame: bounds)
        label.text = message
        label.textColor = .black
        label.textAlignment = .center
        addSubview(label)
        
        // Animate the toast view and remove it from the view hierarchy
        UIView.animate(withDuration: 3.0, animations: {
            self.alpha = 0
        }, completion: { _ in
            self.removeFromSuperview()
        })
    }
    
    
}
