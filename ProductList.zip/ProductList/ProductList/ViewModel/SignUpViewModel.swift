//
//  SignUpViewModel.swift
//  ProductList
//
//  Created by Sreelakshmi on 14/08/23.
//

import Foundation
import UIKit
import CoreData

class SignUpViewModel {
    
    var registration : [UserRegistration] = []
    var validationErrors: [Int: String] = [:]
    var isValid = true
    var userRegistration: UserRegistration?
    var toastView = ToastView()
    var user: [UserRegistration] = []
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "ProductList")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    var persistentStoreURL: URL? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.persistentStoreCoordinator.persistentStores.first?.url
    }
    
    func printPersistentStoreInfo() {
        if let storeURL = persistentStoreURL {
            print("Persistent Store URL: \(storeURL)")
        } else {
            print("No persistent store found.")
        }
    }
    
    func setValues(for userDataObject: NSManagedObject, with userData: UserRegistration) {
        userDataObject.setValue(userData.firstName, forKey: "firstName")
        userDataObject.setValue(userData.lastName, forKey: "lastName")
        userDataObject.setValue(userData.phoneNumber, forKey: "phoneNumber")
        userDataObject.setValue(userData.emailAddress, forKey: "emailAddress")
        userDataObject.setValue(userData.userName, forKey: "userName")
        userDataObject.setValue(userData.password, forKey: "password")
        userDataObject.setValue(userData.confirmPassword, forKey: "confirmPassword")
    }
    
    func saveContext() {
        do {
            try managedObjectContext.save()
            print("Context saved successfully")
        } catch {
            print("Error saving context: \(error)")
        }
    }

    /// Add Item To Core Data
    func addItemToCoreData(itemData: UserRegistration, completion: (Bool) -> Void) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        guard let userEntity = NSEntityDescription.entity(forEntityName: "SignUp", in: managedObjectContext) else {
            completion(false)
            return
        }
        let item = NSManagedObject(entity: userEntity, insertInto: managedObjectContext)
        setValues(for: item, with: itemData)
        do {
            try managedObjectContext.save()
            completion(true)
        } catch {
            print("Error saving item to Core Data: \(error)")
            completion(false)
        }
    }
    
    func fetchUser(userName: String) -> SignUp? {
        let fetchRequest: NSFetchRequest<SignUp> = SignUp.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "userName == %@", userName)

        do {
            let users = try managedObjectContext.fetch(fetchRequest)
            return users.first
        } catch {
            print("Error fetching user: \(error)")
            return nil
        }
    }

    func validateAndShowErrors(for tag: Int, text: String) {
        switch tag {
        case 0, 1:
            hideErrorValidation(tag: tag)
            if !isNotEmpty(text) {
                showErrorValidation(tag: tag, message: "Please enter your \(tag == 0 ? "first" : "last") name")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 2:
            hideErrorValidation(tag: tag)
            if !isValidPhoneNumber(text) {
                showErrorValidation(tag: tag, message: "Invalid phone number")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 3:
            hideErrorValidation(tag: tag)
            if !isValidEmail(text) {
                showErrorValidation(tag: tag, message: "Invalid email")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 4:
            hideErrorValidation(tag: tag)
            if !isValidUsername(text) {
                showErrorValidation(tag: tag, message: "Please enter a valid username")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 5:
            hideErrorValidation(tag: tag)
            if !isValidPassword(text) {
                showErrorValidation(tag: tag, message: "Please enter a valid password")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 6:
            hideErrorValidation(tag: tag)
            if let password = userRegistration?.password, !passwordsMatch(password: text, confirmPassword: password) {
                showErrorValidation(tag: tag, message: "Passwords do not match")
            } else {
                hideErrorValidation(tag: tag)
            }
        default:
            break
        }
    
    }

    
    func showErrorValidation(tag: Int, message: String) {
        validationErrors[tag] = message
    }

    func hideErrorValidation(tag: Int) {
        validationErrors.removeValue(forKey: tag)
    }

    func isValidationHidden(for tag: Int) -> Bool {
        return validationErrors[tag] == nil
    }

    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }

    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        let phoneNumberRegex = "^\\d{10}$" 
        let phoneNumberPredicate = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        return phoneNumberPredicate.evaluate(with: phoneNumber)
    }

    func isNotEmpty(_ text: String?) -> Bool {
        guard let text = text else {
                return false
            }
            
            let characterSet = CharacterSet.letters
            let trimmedText = text.trimmingCharacters(in: .whitespacesAndNewlines)
            
            return !trimmedText.isEmpty && trimmedText.rangeOfCharacter(from: characterSet.inverted) == nil
    }

    func passwordsMatch(password: String, confirmPassword: String) -> Bool {
        return password == confirmPassword
    }

    func isValidUsername(_ username: String) -> Bool {
        return !username.isEmpty
    }

    func isValidPassword(_ password: String) -> Bool {
        let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$])[A-Za-z\\d@#$]{6,}$"
        let passwordPredicate = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
        return passwordPredicate.evaluate(with: password)
    }
    
    func retrieveData(completion: @escaping ([UserRegistration]?, Error?) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SignUp")
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            user = []  ///An empty array of Product objects initialized.
            if let dataObjects = result as? [NSManagedObject], !dataObjects.isEmpty {
                for data in dataObjects {
                    /// Extract attribute values from the NSManagedObject
                    let firstName = data.value(forKey: "firstName") as? String ?? ""
                    let lastName = data.value(forKey: "lastName") as? String ?? ""
                    let phoneNumber = data.value(forKey: "phoneNumber") as? String ?? ""
                    let emailAddress = data.value(forKey: "emailAddress") as? String ?? ""
                    let userName = data.value(forKey: "userName") as? String ?? ""
                    let password = data.value(forKey: "password") as? String ?? ""
                    let confirmPassword = data.value(forKey: "confirmPassword") as? String ?? ""
                    /// Create a Product object using the extracted attributes
                    let item = UserRegistration(firstName: firstName,lastName: lastName,phoneNumber: phoneNumber,emailAddress: emailAddress,userName: userName,password: password,confirmPassword: confirmPassword)
                    user.append(item) /// Append the Product object to the cartItem array
                }
                completion(user, nil)
            } else {
                completion(nil, nil)
            }
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }

}
 
     
