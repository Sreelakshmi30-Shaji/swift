//
//  Address.swift
//  ProductList
//
//  Created by Sreelakshmi on 21/08/23.s
//

import Foundation

struct Address {
    var id : String?
    var address1: String?
    var address2: String?
    var state: String?
    var country: String?
    var pincode: String?
    
    init(id: String = "", address1: String = "", address2: String = "", state: String = "", country: String = "", pincode: String = "") {
        self.id = id
        self.address1 = address1
        self.address2 = address2
        self.state = state
        self.country = country
        self.pincode = pincode
    }
}
