//
//  UserRegistration.swift
//  ProductList
//
//  Created by Sreelakshmi on 14/08/23.
//

import Foundation

struct UserRegistration {
    var firstName: String?
    var lastName: String?
    var phoneNumber: String?
    var emailAddress: String?
    var userName: String?
    var password: String?
    var confirmPassword: String?
    var isLogin: Bool?
    
    init(firstName: String = "", lastName: String = "", phoneNumber: String = "", emailAddress: String = "", userName: String = "", password: String = "", confirmPassword: String = "") {
        self.firstName = firstName
        self.lastName = lastName
        self.phoneNumber = phoneNumber
        self.emailAddress = emailAddress
        self.userName = userName
        self.password = password
        self.confirmPassword = confirmPassword
        self.isLogin = false
    }
}
