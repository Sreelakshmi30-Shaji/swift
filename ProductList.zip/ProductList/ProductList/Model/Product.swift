//
//  Product.swift
//  ProductList
//
//  Created by Sreelakshmi on 07/07/23.
//

import Foundation
import UIKit

struct Product: Decodable {
    var id: String
    var title: String?
    var price: String?
    var image: String?
    var count: Int32?
    var saveForLater: Bool?
    var date: String?
    var sellers: [Seller]?
    var pagination: Pagination?
    var productImage: UIImage?
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case price
        case image
        case count
        case saveForLater = "save_for_later"
        case date
        case sellers = "sellers"
        case pagination
        case productImage
    }
    
    init(id: String, title: String, price: String, image: String, count: Int32, saveForLater: Bool, date: String) {
            self.id = id
            self.title = title
            self.price = price
            self.image = image
            self.count = count
            self.saveForLater = saveForLater
            self.date = date
            self.productImage = nil
        }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(String.self, forKey: .id)
        self.title = try container.decodeIfPresent(String.self, forKey: .title)
        self.price = try container.decodeIfPresent(String.self, forKey: .price)
        self.image = try container.decodeIfPresent(String.self, forKey: .image)
        self.count = try container.decodeIfPresent(Int32.self, forKey: .count)
        self.saveForLater = try container.decodeIfPresent(Bool.self, forKey: .saveForLater)
        self.date = try container.decodeIfPresent(String.self, forKey: .date)
        self.sellers = try container.decodeIfPresent([Seller].self, forKey: .sellers)
        self.pagination = try container.decodeIfPresent(Pagination.self, forKey: .pagination)
        self.productImage = nil

    }
}

struct Seller: Decodable {
    var sellerName: String?
    var sellerRating: String?
    var sellerLocation: String?
    
    enum CodingKeys: String, CodingKey {
        case sellerName = "seller_name"
        case sellerRating = "seller_rating"
        case sellerLocation = "seller_location"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.sellerName = try container.decodeIfPresent(String.self, forKey: .sellerName)
        self.sellerRating = try container.decodeIfPresent(String.self, forKey: .sellerRating)
        self.sellerLocation = try container.decodeIfPresent(String.self, forKey: .sellerLocation)
    }
}
struct Pagination: Decodable {
    var nextPage: String?
    
}

struct ProductDetails {
    let title: String
    let price: String
    let rating: String
    let image: UIImage
}
