//
//  Order.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 27/09/23.
//

import Foundation

struct Order {
    var orderId: String?
    var itemName: String?
    var itemPrice: String?
    var itemImage: String?
    var count: Int32?
    var name: String?
    var emailAddress: String?
    var phoneNumber: String?
    var address: String?
    var userId: String
    
    
    init(orderId: String = "", itemName: String = "", itemPrice: String = "", itemImage: String = "", count: Int32, name: String = "", emailAddress: String = "", phoneNumber: String = "", address: String = "",userId: String = "") {
        self.orderId = orderId
        self.itemName = itemName
        self.itemPrice = itemPrice
        self.itemImage = itemImage
        self.count = count
        self.name = name
        self.emailAddress = emailAddress
        self.phoneNumber = phoneNumber
        self.address = address
        self.userId = userId
    }
}
