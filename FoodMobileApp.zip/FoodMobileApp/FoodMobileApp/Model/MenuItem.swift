//
//  MenuItem.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 15/09/23.
//

import Foundation
import UIKit

struct MenuItem: Decodable {
    var id: String
    var itemName: String?
    var itemDescription: String?
    var itemPrice: String?
    var itemRating: String?
    var itemCategory: String?
    var itemImage: String?
    var isSaveForLater: Bool?
    var count: Int32?
    var userId: String?

    
    enum CodingKeys: String, CodingKey {
        case id
        case itemName
        case itemDescription
        case itemPrice
        case itemRating
        case itemCategory
        case itemImage = "itemImage"
        case isSaveForLater = "isSaveForLater"
        case count
        case userId
    }
    
    init(id: String,itemName: String,itemDescription: String,itemPrice: String,itemRating: String,itemCategory: String,itemImage: String,isSaveForLater: Bool,count: Int32,userId: String){
        self.id = id
        self.itemName = itemName
        self.itemDescription = itemDescription
        self.itemPrice = itemPrice
        self.itemRating = itemRating
        self.itemCategory = itemCategory
        self.itemImage = itemImage
        self.isSaveForLater = isSaveForLater
        self.count = count
        self.userId = userId

    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(String.self, forKey: .id)
        self.itemName = try container.decodeIfPresent(String.self, forKey: .itemName)
        self.itemDescription = try container.decodeIfPresent(String.self, forKey: .itemDescription)
        self.itemPrice = try container.decodeIfPresent(String.self, forKey: .itemPrice)
        self.itemRating = try container.decodeIfPresent(String.self, forKey: .itemRating)
        self.itemCategory = try container.decodeIfPresent(String.self, forKey: .itemCategory)
        self.itemImage = try container.decodeIfPresent(String.self, forKey: .itemImage)
        self.isSaveForLater = try container.decodeIfPresent(Bool.self, forKey: .isSaveForLater)
        self.count = try container.decodeIfPresent(Int32.self, forKey: .count)
        self.userId = try container.decodeIfPresent(String.self, forKey: .userId)

    }
}
