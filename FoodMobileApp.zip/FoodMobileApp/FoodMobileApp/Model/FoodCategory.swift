//
//  FoodCategory.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 19/09/23.
//

import Foundation

struct FoodCategory {
    let itemCategory: String
    let imageName: String
}
