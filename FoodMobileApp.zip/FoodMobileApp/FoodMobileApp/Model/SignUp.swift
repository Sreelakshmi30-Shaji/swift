//
//  SignUp.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 15/09/23.
//

import Foundation

struct SignUp {
    var userId: String
    var firstName: String?
    var lastName: String?
    var phoneNumber: String?
    var emailAddress: String?
    var userName: String?
    var password: String?
    var confirmPassword: String?
    var isLogin: Bool?
    var address: Address
    
    init(userId: String = "",firstName: String = "", lastName: String = "", phoneNumber: String = "", emailAddress: String = "", userName: String = "", password: String = "", confirmPassword: String = "",address: Address = Address()) {
        self.userId = userId
        self.firstName = firstName
        self.lastName = lastName
        self.phoneNumber = phoneNumber
        self.emailAddress = emailAddress
        self.userName = userName
        self.password = password
        self.confirmPassword = confirmPassword
        self.isLogin = false
        self.address = address
    }
}
