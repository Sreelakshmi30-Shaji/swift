//
//  CartViewModel.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 22/09/23.
//

import Foundation
import CoreData
import UIKit

class CartViewModel {
    
    var cartItem: [MenuItem] = []
    var view = ToastView()

    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "FoodMobileApp")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    var persistentStoreURL: URL? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.persistentStoreCoordinator.persistentStores.first?.url
    }
    
    func printPersistentStoreInfo() {
        if let storeURL = persistentStoreURL {
            print("Persistent Store URL: \(storeURL)")
        } else {
            print("No persistent store found.")
        }
    }
    
    func setValues(for cartItemObject: NSManagedObject, with cartItem: MenuItem) {
        cartItemObject.setValue(cartItem.id, forKey: "id")
        cartItemObject.setValue(cartItem.itemName, forKey: "itemName")
        cartItemObject.setValue(cartItem.itemDescription, forKey: "itemDescription")
        cartItemObject.setValue(cartItem.itemPrice, forKey: "itemPrice")
        cartItemObject.setValue(cartItem.itemRating, forKey: "itemRating")
        cartItemObject.setValue(cartItem.itemCategory, forKey: "itemCategory")
        cartItemObject.setValue(cartItem.itemImage, forKey: "itemImage")
        cartItemObject.setValue(cartItem.isSaveForLater, forKey: "isSaveForLater")
        cartItemObject.setValue(1, forKey: "count")
        cartItemObject.setValue(cartItem.userId, forKey: "userId")
    }
    
    //ADD ITEM TO CART
    func addItemToCoreData(itemData: MenuItem,userId: String, completion: @escaping (Bool) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MenuItemsEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %@", itemData.id)
        do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first as? NSManagedObject {
                let saveForLater = existingCartItem.value(forKey: "isSaveForLater") as? Bool ?? false ///to determine if the item is already marked as "Save for Later"
                if saveForLater {
                    let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Item is already in 'Save for Later'")
                    completion(false)
                    return
                }

                let currentCount = existingCartItem.value(forKey: "count") as? Int ?? 1 ///to retrieve the value of the attribute with the key "count" from the existingCartItem

                if currentCount >= 10 {
                    let toastView = ToastView(frame: CGRect(x: 110, y: 10, width: 200, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Limit Exceeded")
                    completion(false)
                    return
                } else {
                    existingCartItem.setValue(currentCount + 1, forKey: "count")/// the "count" attribute of existingCartItem will be updated to the new value, which is the current                                                                                                                                        value of "count" plus 1.
                }
            } else {
                ///no existing Core Data object matching the given criteria and a new managed object is created to represent a new item that will be added to Core Data.
                guard let cartEntity = NSEntityDescription.entity(forEntityName: "MenuItemsEntity", in: managedObjectContext) else {
                    completion(false)
                    return
                }
                let item = NSManagedObject(entity: cartEntity, insertInto: managedObjectContext)
                setValues(for: item, with: itemData)
                item.setValue(userId, forKey: "userId")
                item.setValue(false, forKey: "isSaveForLater")
            }

            let toastView = ToastView(frame: CGRect(x: 90, y: 700, width: 200, height: 50))
            toastView.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(toastView)
            toastView.show(message: "Item added to Cart")

            try managedObjectContext.save()
            completion(true)
        } catch {
            print("Error saving item to Core Data: \(error)")
            completion(false)
        }
    }
    
    //RETRIEVE DATA FROM CART
    func retrieveData(loggedInUserId: String, completion: @escaping ([MenuItem]?, Error?) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MenuItemsEntity")
        fetchRequest.predicate = NSPredicate(format: "userId == %@", loggedInUserId)
        
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            var cartItems: [MenuItem] = []
            
            for data in result as? [NSManagedObject] ?? [] {
                // Extract attribute values from the NSManagedObject
                let id = data.value(forKey: "id") as? String ?? ""
                let itemName = data.value(forKey: "itemName") as? String ?? ""
                let itemDescription = data.value(forKey: "itemDescription") as? String ?? ""
                let itemPrice = data.value(forKey: "itemPrice") as? String ?? ""
                let itemRating = data.value(forKey: "itemRating") as? String ?? ""
                let itemCategory = data.value(forKey: "itemCategory") as? String ?? ""
                let itemImage = data.value(forKey: "itemImage") as? String ?? ""
                let isSaveForLater = data.value(forKey: "isSaveForLater") as? Bool ?? false
                let count = data.value(forKey: "count") as? Int32 ?? 0
                let userId = data.value(forKey: "userId") as? String ?? ""
                
                // Create a MenuItem object using the extracted attributes
                let item = MenuItem(
                    id: id,
                    itemName: itemName,
                    itemDescription: itemDescription,
                    itemPrice: itemPrice,
                    itemRating: itemRating,
                    itemCategory: itemCategory,
                    itemImage: itemImage,
                    isSaveForLater: isSaveForLater,
                    count: count,
                    userId: userId
                )
                cartItems.append(item)
            }
            
            completion(cartItems, nil)
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }


    //INCREMENT PRODUCT COUNT
    func incrementProductCount(for foodItem: MenuItem) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MenuItemsEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %@", foodItem.id)
         do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first as? NSManagedObject {
                let currentCount = existingCartItem.value(forKey: "count") as? Int ?? 1

                if currentCount >= 10 {
                    let toastView = ToastView(frame: CGRect(x: 110, y: 60, width: 200, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Limit Exceeded")
                    return
                } else {
                    existingCartItem.setValue(currentCount + 1, forKey: "count")
                }
            } else {
                guard let cartEntity = NSEntityDescription.entity(forEntityName: "MenuItemsEntity", in: managedObjectContext) else { return }
                let newCartItem = NSManagedObject(entity: cartEntity, insertInto: managedObjectContext)
                newCartItem.setValue(foodItem.id, forKey: "id")
                newCartItem.setValue(1, forKey: "count")
            }
            try managedObjectContext.save()
        } catch {
            print("Error updating item count in Core Data: \(error)")
        }
    }

    // DECREMENT PRODUCT COUNT
    func decrementProductCount(for foodItem: MenuItem) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "MenuItemsEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %@", foodItem.id)
        do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first as? NSManagedObject {
                let currentCount = existingCartItem.value(forKey: "count") as? Int ?? 0
                let newCount = max(currentCount - 1, 1)
                existingCartItem.setValue(newCount, forKey: "count")
                try managedObjectContext.save()
            }
        } catch {
            print("Error updating item count in Core Data: \(error)")
        }
    }
    
    // MOVE PRODUCT FROM CART TO SAVE FOR LATER

    func moveItemToSavedForLater(foodItem: MenuItem, completion: @escaping (Bool) -> Void) {
        let fetchRequest = NSFetchRequest<MenuItemsEntity>(entityName: "MenuItemsEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %@", foodItem.id)
        
        do {
            if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                existingCartItem.setValue(true, forKey: "isSaveForLater")
                try managedObjectContext.save()
                completion(true)
            } else {
                completion(false)
            }
        } catch {
            print("Error moving item to 'Saved for Later': \(error)")
            completion(false)
        }
    }
    
    // MOVE PRODUCT FROM SAVE FOR LATER TO CART
    func moveItemToCart(foodItem: MenuItem, completion: @escaping (Bool) -> Void) {
          let fetchRequest = NSFetchRequest<MenuItemsEntity>(entityName: "MenuItemsEntity")
          fetchRequest.predicate = NSPredicate(format: "id == %@", foodItem.id)

          do {
              if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                  existingCartItem.setValue(false, forKey: "isSaveForLater")
                  try managedObjectContext.save()
                  completion(true)
              } else {
                  completion(false)
              }
          } catch {
              print("Error moving item to cart: \(error)")
              completion(false)
          }
      }
    
    // CALCULATE TOTAL PRICE
    func calculateTotalPrice(for cartItems: [MenuItem]) -> Double {
           var totalPrice: Double = 0.0
           for product in cartItems {
               if let priceString = product.itemPrice,
                  let price = Double(priceString),
                  let count = product.count {
                   let countInt = Int(count)
                   totalPrice += price * Double(countInt)
               }
           }
           return totalPrice
       }
    
    // DELETE CART ITEM
    func deleteCartItem(cartItem: MenuItem, completion: @escaping (Bool) -> Void) {
            let fetchRequest = NSFetchRequest<MenuItemsEntity>(entityName: "MenuItemsEntity")
            fetchRequest.predicate = NSPredicate(format: "id == %@", cartItem.id)

            do {
                if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                    managedObjectContext.delete(existingCartItem)
                    try managedObjectContext.save()
                    completion(true)
                } else {
                    completion(false)
                }
            } catch {
                print("Error deleting cart item from Core Data: \(error)")
                completion(false)
            }
        }

    // DELETE SAVED PRODUCT
        func deleteSavedItem(cartItem: MenuItem, completion: @escaping (Bool) -> Void) {
            let fetchRequest = NSFetchRequest<MenuItemsEntity>(entityName: "MenuItemsEntity")
            fetchRequest.predicate = NSPredicate(format: "id == %@ AND isSaveForLater == %@", cartItem.id, NSNumber(value: true))

            do {
                if let existingCartItem = try managedObjectContext.fetch(fetchRequest).first {
                    managedObjectContext.delete(existingCartItem)
                    try managedObjectContext.save()
                    completion(true)
                } else {
                    completion(false)
                }
            } catch {
                print("Error deleting saved item from Core Data: \(error)")
                completion(false)
            }
        }
}
