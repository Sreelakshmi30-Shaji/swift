//
//  SignUpViewModel.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 18/09/23.
//

import Foundation
import UIKit
import CoreData

class SignUpViewModel {
    
    var userDetails: [SignUp] = []  ///representing user registration details.
    var signUp: SignUp?             ///hold a single user's registration data.
    var validationErrors: [Int: String] = [:]  ///a dictionary that associates validation error messages with UI elements (tag values) in the registration form.
    
    var userName: String?
    var userEmail: String?
    var userPhoneNumber: String?
    var deliveryAddress: String?
    var addressData: Address?

    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "FoodMobileApp")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    var persistentStoreURL: URL? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.persistentStoreCoordinator.persistentStores.first?.url
    }
    
    func printPersistentStoreInfo() {
        if let storeURL = persistentStoreURL {
            print("Persistent Store URL: \(storeURL)")
        } else {
            print("No persistent store found.")
        }
    }
    
    func saveContext() {
        do {
            try managedObjectContext.save()
            print("Context saved successfully")
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    func setValues(for entity: SignUpEntity, with data: SignUp) {
        entity.firstName = data.firstName
        entity.lastName = data.lastName
        entity.phoneNumber = data.phoneNumber
        entity.emailAddress = data.emailAddress
        entity.userName = data.userName
        entity.password = data.password
        entity.confirmPassword = data.confirmPassword
    }
    
     //ADD USER REGISTRATION TO COREDATA
    func addItemToCoreData(itemData: SignUp, completion: @escaping (Bool) -> Void) {
           guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
               completion(false)
               return
           }
           let managedObjectContext = appDelegate.persistentContainer.viewContext
           // Fetch the highest existing ID
           let fetchRequest = NSFetchRequest<SignUpEntity>(entityName: "SignUpEntity")
           fetchRequest.sortDescriptors = [NSSortDescriptor(key: "userId", ascending: false)]
           do {
               if let highestUser = try managedObjectContext.fetch(fetchRequest).first,
                  let highestIDString = highestUser.userId,
                  let highestID = Int(highestIDString) {
                   // Calculate the next ID
                   let nextID = highestID + 1
                   // Create a new managed object
                   if let newUser = NSEntityDescription.insertNewObject(forEntityName: "SignUpEntity", into: managedObjectContext) as? SignUpEntity {
                       newUser.userId = String(nextID)
                       setValues(for: newUser, with: itemData)
                       do {
                           try managedObjectContext.save()
                           print("Item saved to Core Data")
                           completion(true)
                       } catch {
                           print("Error saving item to Core Data: \(error)")
                           completion(false)
                       }
                   } else {
                       completion(false)
                   }
               } else {
                   // No existing items, set ID to 1
                   if let newUser = NSEntityDescription.insertNewObject(forEntityName: "SignUpEntity", into: managedObjectContext) as? SignUpEntity {
                       newUser.userId = "1"
                       setValues(for: newUser, with: itemData)
                       do {
                           try managedObjectContext.save()
                           print("Item saved to Core Data")
                           completion(true)
                       } catch {
                           print("Error saving item to Core Data: \(error)")
                           completion(false)
                       }
                   } else {
                       completion(false)
                   }
               }
           } catch {
               print("Error fetching highest ID: \(error)")
               completion(false)
           }
       }
    
    //RETRIEVE USER REGISTRATION DETAILS FROM COREDATA
    func retrieveData(completion: @escaping ([SignUp]?, Error?) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SignUpEntity")
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            userDetails = []
            if let dataObjects = result as? [NSManagedObject], !dataObjects.isEmpty {
                for data in dataObjects {
                    // Extract attribute values from the NSManagedObject
                    let userId = data.value(forKey: "userId") as? String ?? ""
                    let firstName = data.value(forKey: "firstName") as? String ?? ""
                    let lastName = data.value(forKey: "lastName") as? String ?? ""
                    let phoneNumber = data.value(forKey: "phoneNumber") as? String ?? ""
                    let emailAddress = data.value(forKey: "emailAddress") as? String ?? ""
                    let userName = data.value(forKey: "userName") as? String ?? ""
                    let password = data.value(forKey: "password") as? String ?? ""
                    let confirmPassword = data.value(forKey: "confirmPassword") as? String ?? ""

                    let user = SignUp(userId: userId, firstName: firstName, lastName: lastName, phoneNumber: phoneNumber, emailAddress: emailAddress, userName: userName, password: password, confirmPassword: confirmPassword)
                    userDetails.append(user)
                }
                completion(userDetails, nil)
            } else {
                completion(nil, nil)
            }
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }
    
    //UPDATE USER REGISTRATION DETAILS IN COREDATA
    func updateUser(itemID: String, updatedData: SignUp, completion: @escaping (Bool) -> Void) {
        let fetchRequest = NSFetchRequest<SignUpEntity>(entityName: "SignUpEntity")
        fetchRequest.predicate = NSPredicate(format: "userId == %@", itemID)
        
        do {
            if let existingItem = try managedObjectContext.fetch(fetchRequest).first {
                setValues(for: existingItem, with: updatedData)
                managedObjectContext.refresh(existingItem, mergeChanges: true)
                print("Updated Data: \(updatedData)")
                do {
                    try managedObjectContext.save()
                    completion(true)
                } catch {
                    print("Error updating item in Core Data: \(error)")
                    completion(false)
                }
            } else {
                print("Item with ID \(itemID) not found.")
                completion(false)
            }
        } catch {
            print("Error fetching item with ID \(itemID): \(error)")
            completion(false)
        }
    }
    
    func fetchUser(userName: String) -> SignUpEntity? {
        let fetchRequest: NSFetchRequest<SignUpEntity> = SignUpEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "userName == %@", userName)

        do {
            let users = try managedObjectContext.fetch(fetchRequest)
            return users.first
        } catch {
            print("Error fetching user: \(error)")
            return nil
        }
    }
    
    
    func validateAndShowErrors(for tag: Int, text: String) {
        switch tag {
        case 0, 1:
            hideErrorValidation(tag: tag)
            if !isNotEmpty(text) {
                showErrorValidation(tag: tag, message: "Please enter your \(tag == 0 ? "first" : "last") name")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 2:
            hideErrorValidation(tag: tag)
            if !isValidPhoneNumber(text) {
                showErrorValidation(tag: tag, message: "Please enter your valid phone number")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 3:
            hideErrorValidation(tag: tag)
            if !isValidEmail(text) {
                showErrorValidation(tag: tag, message: "Please enter your valid email")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 4:
            hideErrorValidation(tag: tag)
            if !isValidUsername(text) {
                showErrorValidation(tag: tag, message: "Please enter a valid username")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 5:
            hideErrorValidation(tag: tag)
            if !isValidPassword(text) {
                showErrorValidation(tag: tag, message: "Please enter a valid password")
            } else {
                hideErrorValidation(tag: tag)
            }
        case 6:
            hideErrorValidation(tag: tag)
            if let password = signUp?.password, !passwordsMatch(password: text, confirmPassword: password) {
                showErrorValidation(tag: tag, message: "Passwords do not match")
            } else {
                hideErrorValidation(tag: tag)
            }
        default:
            break
        }
    }
    
    func showErrorValidation(tag: Int, message: String) {
        validationErrors[tag] = message
    }
    
    func hideErrorValidation(tag: Int) {
        validationErrors.removeValue(forKey: tag)
    }
    
    func isValidationHidden(for tag: Int) -> Bool {
        return validationErrors[tag] == nil
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    func isValidPhoneNumber(_ phoneNumber: String) -> Bool {
        let phoneNumberRegex = "^\\d{10}$"
        let phoneNumberPredicate = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
        return phoneNumberPredicate.evaluate(with: phoneNumber)
    }
    
    func isNotEmpty(_ text: String?) -> Bool {
        guard let text = text else {
            return false
        }
        
        let characterSet = CharacterSet.letters
        let trimmedText = text.trimmingCharacters(in: .whitespacesAndNewlines)
        
        return !trimmedText.isEmpty && trimmedText.rangeOfCharacter(from: characterSet.inverted) == nil
    }
    
    func passwordsMatch(password: String, confirmPassword: String) -> Bool {
        return password == confirmPassword
    }
    
    func isValidUsername(_ username: String) -> Bool {
        return !username.isEmpty
    }
    
    func isValidPassword(_ password: String) -> Bool {
        let passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$])[A-Za-z\\d@#$]{6,}$"
        let passwordPredicate = NSPredicate(format: "SELF MATCHES %@", passwordRegex)
        return passwordPredicate.evaluate(with: password)
    }
    
    func convertToSignUp(from signUpEntity: SignUpEntity) -> SignUp {
        var signUp = SignUp()
        signUp.firstName = signUpEntity.firstName
        signUp.lastName = signUpEntity.lastName
        signUp.phoneNumber = signUpEntity.phoneNumber
        signUp.emailAddress = signUpEntity.emailAddress
        signUp.userName = signUpEntity.userName
        return signUp
    }
    
    func fetchUserInformation(using context: NSManagedObjectContext) {
        let userFetchRequest: NSFetchRequest<SignUpEntity> = SignUpEntity.fetchRequest()
        do {
            let users = try context.fetch(userFetchRequest)
            let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername")
            // Find the user with the logged-in username
            if let user = users.first(where: { $0.userName == loggedInUsername }) {
                print("User found in Core Data")
                // Access the associated AddressEntity for this user
                if let address = user.address {
                    // Now you can access the address properties
                    let address1 = address.address1 ?? ""
                    let address2 = address.address2 ?? ""
                    let state = address.state ?? ""
                    let country = address.country ?? ""
                    let pincode = address.pincode ?? ""

                    // Assign the fetched data to your properties
                    self.userName = user.userName ?? ""
                    self.userEmail = user.emailAddress ?? ""
                    self.userPhoneNumber = user.phoneNumber ?? ""
                    self.deliveryAddress = "\(address1), \(address2), \(state), \(country), \(pincode)"

                    print("User Name: \(self.userName ?? "N/A")")
                    print("User Email: \(self.userEmail ?? "N/A")")
                    print("User Phone Number: \(self.userPhoneNumber ?? "N/A")")
                    print("Delivery Address: \(self.deliveryAddress ?? "N/A")")
                } else {
                    print("Address not found for the user")
                }
            } else {
                print("User not found in Core Data")
            }
        } catch {
            print("Error fetching user information: \(error)")
        }
    }
}
