//
//  OrderViewModel.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 27/09/23.
//

import Foundation
import CoreData
import UIKit

class OrderViewModel {
    
    var orderItems: [Order] = []
    var toastView = ToastView()
    var userOrder: [Order] = []
    var signUpViewModel = SignUpViewModel()
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "FoodMobileApp")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    var persistentStoreURL: URL? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.persistentStoreCoordinator.persistentStores.first?.url
    }
    
    func printPersistentStoreInfo() {
        if let storeURL = persistentStoreURL {
            print("Persistent Store URL: \(storeURL)")
        } else {
            print("No persistent store found.")
        }
    }
    
    func setValues(for orderItemObject: NSManagedObject, with orderItems: Order) {
        orderItemObject.setValue(orderItems.orderId, forKey: "orderId")
        orderItemObject.setValue(orderItems.itemName, forKey: "itemName")
        orderItemObject.setValue(orderItems.itemImage, forKey: "itemImage")
        orderItemObject.setValue(orderItems.itemPrice, forKey: "itemPrice")
        orderItemObject.setValue(orderItems.name, forKey: "name")
        orderItemObject.setValue(orderItems.emailAddress, forKey: "emailAddress")
        orderItemObject.setValue(orderItems.phoneNumber, forKey: "phoneNumber")
        orderItemObject.setValue(orderItems.address, forKey: "address")
        orderItemObject.setValue(1, forKey: "count")
        orderItemObject.setValue(orderItems.userId, forKey: "userId")
    }
    
    //GENERATE UNIQUE ORDER ID
    func generateUniqueOrderId() -> String {
        let timestamp = Date().timeIntervalSince1970
        let random = Int(arc4random_uniform(10000))
        let orderId = "\(Int(timestamp))-\(random)"
        return orderId
    }
    
    // ADD ITEM TO ORDER
    func addItemToCoreData(cartItems: [MenuItem],userId: String, user: SignUp, order: Order?, completion: @escaping (Bool) -> Void) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            completion(false)
            return
        }
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        for cartItem in cartItems {
            let orderId = generateUniqueOrderId()
            if let newOrder = NSEntityDescription.insertNewObject(forEntityName: "OrderEntity", into: managedObjectContext) as? OrderEntity {
                newOrder.orderId = orderId
                let itemName = cartItem.itemName ?? ""
                let itemImage = cartItem.itemImage ?? ""
                if let itemPriceString = cartItem.itemPrice, let itemPrice = Double(itemPriceString) {
                    let itemCount = cartItem.count ?? 1
                    newOrder.itemName = itemName
                    newOrder.itemPrice = cartItem.itemPrice
                    newOrder.itemImage = itemImage
                    newOrder.count = cartItem.count ?? 1
                    newOrder.userId = cartItem.userId ?? ""
                    if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
                        print("Logged-in Username: \(loggedInUsername)")
                        if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                            print("User found in Core Data")
                                if let firstName = user.firstName, !firstName.isEmpty {
                                    newOrder.name = "\(firstName) \(user.lastName ?? "")"
                                } else {
                                    newOrder.name = "Guest"
                                }
                            }
                        }
                        newOrder.emailAddress = user.emailAddress
                        newOrder.phoneNumber = user.phoneNumber
                        if let address = order?.address {
                            newOrder.address = address
                        } else {
                            let addressString = "\(user.address.address1 ?? ""), \(user.address.address2 ?? ""), \(user.address.state ?? ""), \(user.address.country ?? ""), \(user.address.pincode ?? "")"
                            newOrder.address = addressString
                        }
                    do {
                        try managedObjectContext.save()
                        print("Order saved to Core Data")
                    } catch {
                        print("Error saving order to Core Data: \(error)")
                        completion(false)
                    }
                }
            }
        }

        completion(true)
    }
    
   //RETRIEVE ORDER FROM COREDATA
    func retrieveData(loggedInUserId: String,completion: @escaping ([Order]?, Error?) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "OrderEntity")
        fetchRequest.predicate = NSPredicate(format: "userId == %@", loggedInUserId)
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            userOrder = []
            if let dataObjects = result as? [NSManagedObject], !dataObjects.isEmpty {
                for data in dataObjects {
                    /// Extract attribute values from the NSManagedObject
                    let orderId = data.value(forKey: "orderId") as? String ?? ""
                    let itemName = data.value(forKey: "itemName") as? String ?? ""
                    let itemPrice = data.value(forKey: "itemPrice") as? String ?? ""
                    let itemImage = data.value(forKey: "itemImage") as? String ?? ""
                    let name = data.value(forKey: "name") as? String ?? ""
                    let emailAddress = data.value(forKey: "emailAddress") as? String ?? ""
                    let phoneNumber = data.value(forKey: "phoneNumber") as? String ?? ""
                    let address = data.value(forKey: "address") as? String ?? ""
                    let count = data.value(forKey: "count") as? Int32 ?? 0
                    let userId = data.value(forKey: "userId") as? String ?? ""
                    
                    let item = Order(orderId: orderId,itemName: itemName, itemPrice: itemPrice, itemImage: itemImage, count: count, name: name,emailAddress:  emailAddress, phoneNumber: phoneNumber,address: address,userId: userId)
                    userOrder.append(item)
                }
                completion(userOrder, nil)
            } else {
                completion(nil, nil)
            }
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }
    
    //FETCH CURRENTLY LOGGED IN USER ADDRESS
    func fetchUserAddress(userId: String) -> String? {
        let fetchRequest = NSFetchRequest<AddressEntity>(entityName: "AddressEntity")
        fetchRequest.predicate = NSPredicate(format: "userId == %@", userId)

        do {
            let addresses = try managedObjectContext.fetch(fetchRequest)
            if let userAddress = addresses.first {
                let fullAddress = "\(userAddress.address1 ?? ""), \(userAddress.address2 ?? ""), \(userAddress.state ?? ""), \(userAddress.country ?? ""), \(userAddress.pincode ?? "")"
                return fullAddress
            }
        } catch {
            print("Error fetching user address: \(error)")
        }

        return nil
    }
}

extension AddressEntity {
    var fullAddress: String {
        return "\(address1 ?? ""), \(address2 ?? ""), \(state ?? ""), \(country ?? "") \(pincode ?? "")"
    }
}
