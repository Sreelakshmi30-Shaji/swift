//
//  FoodListViewModel.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import Foundation

class FoodListViewModel {
    
   //FETCHING FOOD USING API
    func fetchApi(selectedCategory: String?, completion: @escaping ([MenuItem]?, Error?) -> Void) {
        guard let url = URL(string: "https://demo6641443.mockable.io/FoodMobileApp") else {
            completion(nil, nil) // Invalid URL
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error) // Handle network error
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(nil, nil) // Invalid response
                return
            }
            let statusCode = httpResponse.statusCode
            if (200...299).contains(statusCode) {
                print("Response is successful")
            } else {
                print("Response is a failure. Status code: \(statusCode)")
            }
            guard let data = data else {
                completion(nil, nil) // No data available
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let itemsList = try decoder.decode([MenuItem].self, from: data)
                
                if let selectedCategory = selectedCategory {
                    let filteredItems = itemsList.filter { $0.itemCategory == selectedCategory }
                    completion(filteredItems, nil) // Filtered items
                } else {
                    completion(itemsList, nil) // All items
                }
            } catch let error {
                print("JSON decoding error: \(error)")
                completion(nil, error) // JSON decoding error
            }
        }.resume()
    }
}

