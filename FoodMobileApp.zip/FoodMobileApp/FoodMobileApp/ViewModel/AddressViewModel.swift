//
//  AddressViewModel.swift
//  ProductList
//
//  Created by Sreelakshmi on 21/08/23.
//

import Foundation
import CoreData
import UIKit

class AddressViewModel {
    
    var userAddress: [Address] = []

    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "FoodMobileApp")
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("Failed to load persistent store: \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    var persistentStoreURL: URL? {
        return (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.persistentStoreCoordinator.persistentStores.first?.url
    }
    
    func printPersistentStoreInfo() {
        if let storeURL = persistentStoreURL {
            print("Persistent Store URL: \(storeURL)")
        } else {
            print("No persistent store found.")
        }
    }
    
    func saveContext() {
        do {
            try managedObjectContext.save()
            print("Context saved successfully")
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    //ADD ADDRESS TO COREDATA
    func addItemToCoreData(itemData: Address,userId: String, completion: @escaping (Bool) -> Void) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            completion(false)
            return
        }
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        // Fetch the highest existing ID
        let fetchRequest = NSFetchRequest<AddressEntity>(entityName: "AddressEntity")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "id", ascending: false)]
        do {
            if let highestItem = try managedObjectContext.fetch(fetchRequest).first,
               let highestIDString = highestItem.id,
               let highestID = Int(highestIDString) {
                // Calculate the next ID
                let nextID = highestID + 1
                // Create a new managed object
                if let newItem = NSEntityDescription.insertNewObject(forEntityName: "AddressEntity", into: managedObjectContext) as? AddressEntity {
                    newItem.id = String(nextID)
                    newItem.userId = userId
                    setValues(for: newItem, with: itemData)
                    do {
                        try managedObjectContext.save()
                        completion(true)
                    } catch {
                        print("Error saving item to Core Data: \(error)")
                        completion(false)
                    }
                } else {
                    completion(false)
                }
            } else {
                // No existing items, set ID to 1
                if let newItem = NSEntityDescription.insertNewObject(forEntityName: "AddressEntity", into: managedObjectContext) as? AddressEntity {
                    newItem.id = "1"
                    newItem.userId = userId
                    setValues(for: newItem, with: itemData)
                    do {
                        try managedObjectContext.save()
                        completion(true)
                    } catch {
                        print("Error saving item to Core Data: \(error)")
                        completion(false)
                    }
                } else {
                    completion(false)
                }
            }
        } catch {
            print("Error fetching highest ID: \(error)")
            completion(false)
        }
    }

    //RETRIEVE ADDRESS FROM COREDATA
    func retrieveData(loggedInUserId: String,completion: @escaping ([Address]?, Error?) -> Void) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "AddressEntity")
        fetchRequest.predicate = NSPredicate(format: "userId == %@", loggedInUserId)
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            userAddress = []
            if let dataObjects = result as? [NSManagedObject], !dataObjects.isEmpty {
                for data in dataObjects {
                    /// Extract attribute values from the NSManagedObject
                    let id = data.value(forKey: "id") as? String ?? ""
                    let address1 = data.value(forKey: "address1") as? String ?? ""
                    let address2 = data.value(forKey: "address2") as? String ?? ""
                    let state = data.value(forKey: "state") as? String ?? ""
                    let country = data.value(forKey: "country") as? String ?? ""
                    let pincode = data.value(forKey: "pincode") as? String ?? ""
                    let userId = data.value(forKey: "userId") as? String ?? ""

                    let item = Address(id: id,address1: address1, address2: address2, state: state, country: country,pincode:  pincode,userId: userId)
                    userAddress.append(item)
                }
                completion(userAddress, nil)
            } else {
                completion(nil, nil)
            }
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }

    //UPDATE ADDRESS IN COREDATA
    func updateAddress(itemID: String, updatedData: Address, completion: @escaping (Bool) -> Void) {
        let fetchRequest = NSFetchRequest<AddressEntity>(entityName: "AddressEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %@", itemID)
        
        do {
            if let existingItem = try managedObjectContext.fetch(fetchRequest).first {
                setValues(for: existingItem, with: updatedData)
                managedObjectContext.refresh(existingItem, mergeChanges: true)
                print("Updated Address: \(updatedData)")
                do {
                    try managedObjectContext.save()
                    completion(true)
                } catch {
                    print("Error updating item in Core Data: \(error)")
                    completion(false)
                }
            } else {
                print("Item with ID \(itemID) not found.")
                completion(false)
            }
        } catch {
            print("Error fetching item with ID \(itemID): \(error)")
            completion(false)
        }
    }

    func setValues(for entity: AddressEntity, with data: Address) {
        entity.address1 = data.address1
        entity.address2 = data.address2
        entity.state = data.state
        entity.country = data.country
        entity.pincode = data.pincode
    }

    func isValidAddress1(_ address1: String) -> Bool {
        return !address1.isEmpty && address1.count >= 3 && isValidCharacters(address1)
    }

    func isValidAddress2(_ address2: String) -> Bool {
        return !address2.isEmpty && address2.count >= 3 && isValidCharacters(address2)
    }

    func isValidState(_ state: String) -> Bool {
        return state.count >= 2 && isValidCharacters(state)
    }

    func isValidCountry(_ country: String) -> Bool {
        return country.count >= 3 && isValidCharacters(country)
    }

    func isValidCharacters(_ text: String) -> Bool {
        let characterSet = CharacterSet.letters
        return text.rangeOfCharacter(from: characterSet.inverted) == nil
    }

    func isValidPincode(_ pincode: String) -> Bool {
        let pincodeCharacterSet = CharacterSet.decimalDigits
        return pincode.count == 6 && pincode.rangeOfCharacter(from: pincodeCharacterSet.inverted) == nil
    }
    
}
