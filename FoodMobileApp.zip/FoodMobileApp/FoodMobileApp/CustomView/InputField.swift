//
//  InputField.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 15/09/23.
//

import UIKit

class InputField: UIView, UITextFieldDelegate {
    
    lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        addSubview(label)
        return label
    }()
    
    lazy var contentTextField: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.textAlignment = .left
        addSubview(textField)
        return textField
    }()
    
    lazy var validationLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        addSubview(label)
        return label
    }()
    
    
    ///initializer method for creating an instance of the class when it's initialized from a storyboard or a nib file.
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    ///Initializes and returns a newly allocated view object with the specified frame rectangle.
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setupUI()
    }
    
    private func setupUI() {
        NSLayoutConstraint.activate([
            contentLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            contentLabel.topAnchor.constraint(equalTo: topAnchor, constant: 4),
            contentLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
        ])
        
        NSLayoutConstraint.activate([
            contentTextField.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            contentTextField.topAnchor.constraint(equalTo: contentLabel.bottomAnchor, constant: 4),
            contentTextField.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16)
        ])
        
        NSLayoutConstraint.activate([
            validationLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            validationLabel.topAnchor.constraint(equalTo: contentTextField.bottomAnchor, constant: 4),
            validationLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16)
        ])
            validationLabel.textColor = .red
            validationLabel.font = UIFont.systemFont(ofSize: 12)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    ///set the data and properties for the various UI elements in the InputField.
    func setViewData(contentLabel: String,placeholder: String, tag: Int, text: String) {
        self.contentLabel.text = contentLabel
        self.contentTextField.placeholder = placeholder
        self.contentTextField.tag = tag
        self.contentTextField.text = text
        self.contentTextField.delegate = self   ///handle text field delegate methods.
        self.validationLabel.isHidden = true
    }
}
