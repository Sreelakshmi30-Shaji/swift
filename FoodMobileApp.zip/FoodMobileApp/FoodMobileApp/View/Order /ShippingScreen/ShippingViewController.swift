//
//  ShippingViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 27/09/23.
//

import UIKit

class ShippingViewController: UIViewController {
    
    @IBOutlet weak var shippingTableView: UITableView!
    
    var cartItems: [MenuItem] = []
    var totalOrderPrice: Double = 0.0
    var loggedInUserName: String?
    var loggedInUserEmail: String?
    var loggedInUserPhoneNumber: String?
    var loggedInUserAddress: String?
    var orderViewModel = OrderViewModel()
    var signUpViewModel = SignUpViewModel()
    
    var orders: [Order] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib(nibName: "OrderPlacementTableViewCell", bundle: nil)
        shippingTableView.register(nib, forCellReuseIdentifier: "OrderPlacementTableViewCell")
        
        self.title = "My Orders"
        
        shippingTableView.delegate = self
        shippingTableView.dataSource = self
        
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                if let loggedInUserId = user.userId {
                    print("Logged-in User ID: \(loggedInUserId)")
                    orderViewModel.retrieveData(loggedInUserId: loggedInUserId) { [weak self] (orders, error) in
                        if let error = error {
                            print("Error loading ordered items: \(error)")
                        } else if let orders = orders {
                            if let loggedInUser = self?.getLoggedInUser() {
                                self?.orders = orders.filter { order in
                                    return order.emailAddress == loggedInUser.emailAddress
                                }
                                
                                // Reverse the 'orders' array to display the last ordered item first
                                self?.orders = self?.orders.reversed() ?? []
                                
                                self?.totalOrderPrice = self?.orders.reduce(0.0) { total, order in
                                    let itemPrices = self?.cartItems.compactMap { cartItem in
                                        if let itemName = order.itemName, let itemImage = order.itemImage {
                                            if itemName.contains(cartItem.itemName ?? "") {
                                                if let itemPrice = Double(cartItem.itemPrice ?? "") {
                                                    return itemPrice
                                                }
                                            }
                                        }
                                        return 0.0
                                    }
                                    
                                    let totalPriceForOrder = itemPrices?.reduce(total, +) ?? total
                                    return totalPriceForOrder
                                } ?? 0.0
                                
                                DispatchQueue.main.async {
                                    self?.shippingTableView.reloadData()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    private func convertToSignUp(signUpEntity: SignUpEntity) -> SignUp {
        let firstName = signUpEntity.firstName ?? ""
        let lastName = signUpEntity.lastName ?? ""
        let phoneNumber = signUpEntity.phoneNumber ?? ""
        let emailAddress = signUpEntity.emailAddress ?? ""

        return SignUp(
            firstName: firstName,
            lastName: lastName,
            phoneNumber: phoneNumber,
            emailAddress: emailAddress
        )
    }

    func getLoggedInUser() -> SignUp? {
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let signUpEntity = signUpViewModel.fetchUser(userName: loggedInUsername) {
                return convertToSignUp(signUpEntity: signUpEntity)
            }
        }
        return nil
    }

}
extension ShippingViewController : UITableViewDataSource,  UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
          return 1
      }
      
      func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return orders.count
      }
      
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OrderPlacementTableViewCell", for: indexPath) as! OrderPlacementTableViewCell
        let menuItem = orders[indexPath.row]
        
        cell.orderName.text = menuItem.itemName ?? "Item Name Not Available"
        cell.orderQuantity.text = "Quantity: \(menuItem.count ?? 1)"
        
        if let imageURL = menuItem.itemImage, let url = URL(string: imageURL) {
            DispatchQueue.global().async {
                if let data = try? Data(contentsOf: url) {
                    if let image = UIImage(data: data) {
                        DispatchQueue.main.async {
                            cell.OrderedItemImageView.image = image
                        }
                    } else {
                        print("Failed to create UIImage from data")
                    }
                } else {
                    print("Failed to fetch image data from URL")
                }
            }
        } else {
            cell.OrderedItemImageView.image = UIImage(named: "placeholder_image")
        }
        return cell
    }

      func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
          return 120
      }
}
