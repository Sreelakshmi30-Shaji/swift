//
//  UserInfoTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 25/09/23.
//

import UIKit

class UserInfoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var userInfoLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
