//
//  OrderPlacementViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 25/09/23.
//

import UIKit
import CoreData

class OrderPlacementViewController: UIViewController, UITextFieldDelegate {
    
    var cartItems: [MenuItem] = []
    var user: [SignUp] = []
    var totalOrderPrice: Double = 0.0
    var userName: String?
    var userEmail: String?
    var userPhoneNumber: String?
    var deliveryAddress: String?
    var signUpViewModel = SignUpViewModel()
    var loggedInUserName: String?
    var loggedInUserEmail: String?
    var loggedInUserPhoneNumber: String?
    var loggedInUserAddress: String?
    
    var orderPlacementCartItems: [MenuItem] = []
    var orderPlacementTotalOrderPrice: Double = 0.0
    
    var orderViewModel = OrderViewModel()
    var toastView = ToastView()
    var order: Order?
    var cartViewModel = CartViewModel()
    
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        return (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }()
    
    @IBOutlet weak var orderPlacementTableView: UITableView!
    @IBOutlet weak var totalPriceLabel: UILabel!
    @IBOutlet weak var confirmOrderButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        orderViewModel.printPersistentStoreInfo()

        orderPlacementCartItems = cartItems
        orderPlacementTotalOrderPrice = totalOrderPrice
        confirmOrderButton.layer.cornerRadius = 20
        orderPlacementTableView.register(UINib(nibName: "OrderPlacementTableViewCell", bundle: nil), forCellReuseIdentifier: "OrderPlacementTableViewCell")
        orderPlacementTableView.register(UINib(nibName: "UserInfoTableViewCell", bundle: nil), forCellReuseIdentifier: "UserInfoTableViewCell")
        orderPlacementTableView.delegate = self
        orderPlacementTableView.dataSource = self
        totalPriceLabel.text = "Total Price : Rs. \(totalOrderPrice)"

        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            print("Logged-in Username: \(loggedInUsername)")
            if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                print("User found in Core Data")
                self.userName = user.userName
                self.userEmail = user.emailAddress
                self.userPhoneNumber = user.phoneNumber
                // Update loggedInUserAddress here
                self.loggedInUserAddress = "\(user.address?.address1 ?? ""), \(user.address?.address2 ?? ""), \(user.address?.state ?? ""), \(user.address?.country ?? ""), \(user.address?.pincode ?? "")"
                orderPlacementTableView.reloadData()
            } else {
                print("User not found in Core Data")
            }
        } else {
            print("No Logged-in Username")
        }
        signUpViewModel.fetchUserInformation(using: managedObjectContext)
    }

    @IBAction func confirmOrderButtonAction(_ sender: Any) {
        guard let loggedInUserName = UserDefaults.standard.string(forKey: "LoggedInUsername"),
              let loggedInUserEntity = signUpViewModel.fetchUser(userName: loggedInUserName) else {
            print("User not found")
            return
        }
        // Create a SignUp object from the SignUpEntity properties
        let loggedInUser = SignUp(
            phoneNumber: loggedInUserEntity.phoneNumber ?? "",
            emailAddress: loggedInUserEntity.emailAddress ?? ""
            //address: loggedInUserEntity.address // Assuming 'address' is of type 'Address'
        )
        
        // Calculate total price for all cart items
        let totalOrderPrice = cartItems.reduce(0.0) { (result, cartItem) in
            if let itemPriceString = cartItem.itemPrice, let itemPrice = Double(itemPriceString) {
                let itemCount = cartItem.count ?? 1
                return result + (itemPrice * Double(itemCount))
            }
            return result
        }
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                if let loggedInUserId = user.userId {
                    print("Logged-in User ID: \(loggedInUserId)")
                    orderViewModel.addItemToCoreData(cartItems: cartItems, userId: loggedInUserId, user: loggedInUser,order: nil) { success in
                        if success {
                            print("Items added to CoreData")
                            let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                            toastView.translatesAutoresizingMaskIntoConstraints = false
                            self.view.addSubview(toastView)
                            toastView.show(message: "Item Order Successfully!")
                            self.navigationController?.popViewController(animated: true)
                            print(" Item Ordered successfully!")
                        } else {
                            print("Failed to add items to CoreData")
                            let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                            toastView.translatesAutoresizingMaskIntoConstraints = false
                            self.view.addSubview(toastView)
                            toastView.show(message: "Item Order Failed!")
                            self.navigationController?.popViewController(animated: true)
                            print(" Item Ordered Failed!")
                        }
                    }
                }
            }
        }
    }
}
    
extension OrderPlacementViewController : UITableViewDataSource,UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
           return 2
       }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           if section == 0 {
                   return cartItems.count
               } else if section == 1 {
                   return 4
               }
               return 0
    }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "OrderPlacementTableViewCell", for: indexPath) as! OrderPlacementTableViewCell
            let menuItem = cartItems[indexPath.row]
            cell.orderName.text = menuItem.itemName ?? ""
            cell.orderQuantity.text = "Quantity : \(menuItem.count ?? 1)"
            if let imageURL = menuItem.itemImage, let url = URL(string: imageURL) {
                DispatchQueue.global().async {
                    if let data = try? Data(contentsOf: url) {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.OrderedItemImageView.image = image
                        }
                    }
                }
            } else {
                cell.OrderedItemImageView.image = UIImage(named: "placeholder_image")
            }
            
            return cell
        }else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "UserInfoTableViewCell", for: indexPath) as! UserInfoTableViewCell
            switch indexPath.row {
            case 0:
                           cell.userInfoLabel.text = "Name: \(loggedInUserName ?? "")"
                        case 1:
                            cell.userInfoLabel.text = "Email: \(loggedInUserEmail ?? "")"
                        case 2:
                            cell.userInfoLabel.text = "Phone: \(loggedInUserPhoneNumber ?? "")"
                        case 3:
                             if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
                                if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                                   if let loggedInUserId = user.userId {
                                      if let userAddress = orderViewModel.fetchUserAddress(userId: loggedInUserId) {
                                         cell.userInfoLabel.text = "Address: \(userAddress ?? "")"
                            }
                        }
                    }
                }
            default:
                cell.userInfoLabel.text = ""
            }

            return cell
        }

        return UITableViewCell()
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerHeight: CGFloat = 30
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: headerHeight))
        headerView.backgroundColor = UIColor.systemGray

        let titleLabel = UILabel(frame: CGRect(x: 16, y: 0, width: headerView.frame.width - 16, height: headerHeight))
        titleLabel.textColor = UIColor.white
        titleLabel.font = UIFont.boldSystemFont(ofSize: 16)

        if section == 0 {
            titleLabel.text = "Order Info"
        } else if section == 1 {
            titleLabel.text = "User Info"
        }

        headerView.addSubview(titleLabel)
        return headerView
    }
}
