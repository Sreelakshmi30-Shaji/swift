//
//  OrderPlacementTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 25/09/23.
//

import UIKit

class OrderPlacementTableViewCell: UITableViewCell {

    @IBOutlet weak var orderPlacementView: UIView!
    @IBOutlet weak var orderQuantity: UILabel!
    @IBOutlet weak var orderName: UILabel!
    @IBOutlet weak var OrderedItemImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
