//
//  AddAddressScreenViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 20/09/23.
//
import UIKit

protocol AddAddressScreenDelegate: AnyObject {
    func addressUpdated()
}
class AddAddressScreenViewController: UIViewController {
    
    @IBOutlet weak var addAddressTableView: UITableView!
    
    @IBOutlet weak var addressButton: UIButton!
    
    weak var delegate: AddAddressScreenDelegate?
    var editedFields: Set<String> = []
    var addressViewModel = AddressViewModel()
    var addAddress: Address?
    var address: Address = Address()
    var isEditingAddress = false
    var addressToUpdate: Address?
    var addresses: [Address] = []
    var signUpViewModel = SignUpViewModel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addressButton.layer.cornerRadius = 20
        if isEditingAddress {
            title = "Update Address"
            addressButton.setTitle("Update Address", for: .normal)
                    if let addressToUpdate = addressToUpdate {
                        address = addressToUpdate
                    }
                    // address = addressToUpdate ?? Address()
                } else {
                    title = "Add Address"
                    addressButton.setTitle("Add Address", for: .normal)
                }
        
        addAddressTableView.dataSource = self
        addAddressTableView.delegate = self
        let nib = UINib(nibName: "AddAddressTableViewCell", bundle: nil)
        addAddressTableView.register(nib, forCellReuseIdentifier: "AddAddressTableViewCellIdentifier")
        
        updateAddressButtonState()
        addressViewModel.printPersistentStoreInfo()
    }
    
    @IBAction func addressButtonTapped(_ sender: Any) {
        guard isValidAddress() else {
            print("Invalid address data")
            return
        }
        
        if isEditingAddress {
            if var addressToUpdate = addressToUpdate {
                // Modify the properties of addressToUpdate
                addressToUpdate.id = address.id
                addressToUpdate.address1 = address.address1
                addressToUpdate.address2 = address.address2
                addressToUpdate.state = address.state
                addressToUpdate.country = address.country
                addressToUpdate.pincode = address.pincode
                
                // Call the updateAddress function
                addressViewModel.updateAddress(itemID: addressToUpdate.id!, updatedData: addressToUpdate) { success in
                    if success {
                        let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                        toastView.translatesAutoresizingMaskIntoConstraints = false
                        self.view.addSubview(toastView)
                        toastView.show(message: "Address updated Successfully")
                        self.navigationController?.popViewController(animated: true)
                        print("Address updated successfully!")
                    } else {
                        let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                        toastView.translatesAutoresizingMaskIntoConstraints = false
                        self.view.addSubview(toastView)
                        toastView.show(message: "Update Failed")
                        print("Address updation failed")
                    }
                }
            }
        } else {
            if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
                if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                    if let loggedInUserId = user.userId {
                        print("Logged-in User ID: \(loggedInUserId)")
                        addressViewModel.addItemToCoreData(itemData: address,userId: loggedInUserId) { success in
                            if success {
                                let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                                toastView.translatesAutoresizingMaskIntoConstraints = false
                                self.view.addSubview(toastView)
                                toastView.show(message: "Address added Successfully")
                                self.navigationController?.popViewController(animated: true)
                                print("User Address registered successfully!")
                            } else {
                                let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                                toastView.translatesAutoresizingMaskIntoConstraints = false
                                self.view.addSubview(toastView)
                                toastView.show(message: "Failed")
                                print("User Address registration failed")
                            }
                        }
                    }
                }
            }
        }
    }
    func printAddress(_ address: Address) {
        print("ID: \(address.id ?? "")")
        print("Address1: \(address.address1 ?? "")")
        print("Address2: \(address.address2 ?? "")")
        print("State: \(address.state ?? "")")
        print("Country: \(address.country ?? "")")
        print("Pincode: \(address.pincode ?? "")")
    }
    
    func updateAddressButtonState() {
        let isAddressValid = isValidAddress()
        addressButton.isEnabled = isAddressValid
        addressButton.alpha = isAddressValid ? 1.0 : 0.5
    }
    
    func isValidAddress() -> Bool {
        return addressViewModel.isValidAddress1(address.address1 ?? "") &&
        addressViewModel.isValidAddress2(address.address2 ?? "") &&
        addressViewModel.isValidState(address.state ?? "") &&
        addressViewModel.isValidCountry(address.country ?? "") &&
        addressViewModel.isValidPincode(address.pincode ?? "")
    }
    
    
    func didEndEditing(tag: Int, text: String) {
        switch tag {
        case 0:
            address.address1 = text
            validateAndShowError(for: tag, text: text, validationBlock: addressViewModel.isValidAddress1, errorMessage: "Invalid Address 1")
        case 1:
            address.address2 = text
            validateAndShowError(for: tag, text: text, validationBlock: addressViewModel.isValidAddress2, errorMessage: "Invalid Address 2")
        case 2:
            address.state = text
            validateAndShowError(for: tag, text: text, validationBlock: addressViewModel.isValidState, errorMessage: "Invalid State")
        case 3:
            address.country = text
            validateAndShowError(for: tag, text: text, validationBlock: addressViewModel.isValidCountry, errorMessage: "Invalid Country")
        case 4:
            address.pincode = text
            validateAndShowError(for: tag, text: text, validationBlock: addressViewModel.isValidPincode, errorMessage: "Invalid Pincode")
        default:
            break
        }
        if let cell = addAddressTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? AddAddressTableViewCell {
                if let validationBlock = validationBlockForTag(tag) {
                    if validationBlock(text) {
                        cell.addAddressView.validationLabel.isHidden = true
                    }
                }
            }
        addAddress = address
        updateAddressButtonState()
    }
    
    func validateAndShowError(for tag: Int, text: String, validationBlock: (String) -> Bool, errorMessage: String) {
        let isValid = validationBlock(text)
        if isValid {
            if let cell = addAddressTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? AddAddressTableViewCell {
                cell.addAddressView.validationLabel.text = ""
                cell.addAddressView.validationLabel.isHidden = true
            }
        } else {
            if let cell = addAddressTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? AddAddressTableViewCell {
                cell.addAddressView.validationLabel.text = errorMessage
                cell.addAddressView.validationLabel.isHidden = false
            }
        }
    }
    
    func validationBlockForTag(_ tag: Int) -> ((String) -> Bool)? {
        switch tag {
        case 0:
            return addressViewModel.isValidAddress1
        case 1:
            return addressViewModel.isValidAddress2
        case 2:
            return addressViewModel.isValidState
        case 3:
            return addressViewModel.isValidCountry
        case 4:
            return addressViewModel.isValidPincode
        default:
            return nil
        }
    }
}

extension AddAddressScreenViewController: UITableViewDataSource, UITableViewDelegate, SignUpCellDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = AddAddressTableViewCell.cell(for: tableView, at: indexPath)
        cell.delegate = self
        switch indexPath.row {
        case 0:
            cell.setCellData(contentLabel: "Address 1", placeholder: "Enter Address 1", tag: 0, text: address.address1 ?? "")
        case 1:
            cell.setCellData(contentLabel: "Address 2", placeholder: "Enter Address 2", tag: 1, text: address.address2 ?? "")
        case 2:
            cell.setCellData(contentLabel: "State", placeholder: "Enter State", tag: 2, text: address.state ?? "")
        case 3:
            cell.setCellData(contentLabel: "Country", placeholder: "Enter Country", tag: 3, text: address.country ?? "")
        case 4:
            cell.setCellData(contentLabel: "Pincode", placeholder: "Enter Pincode", tag: 4, text: address.pincode ?? "")
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 80
    }
}
