//
//  AddAddressTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 20/09/23.
//

import UIKit



class AddAddressTableViewCell: UITableViewCell, UITextFieldDelegate {

    @IBOutlet weak var addAddressView: InputField!
    var delegate: SignUpCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        addAddressView.contentTextField.delegate = self
    }
    
    static func cell(for tableView: UITableView,
                     at indexPath: IndexPath,
                     withIdentifier identifier: String? = nil) -> AddAddressTableViewCell {
        let dequedCell = tableView.dequeueReusableCell(withIdentifier: "AddAddressTableViewCellIdentifier", for: indexPath)
        guard let cell = dequedCell as? AddAddressTableViewCell else {
            return AddAddressTableViewCell()
        }
        return cell
    }

    func setCellData(contentLabel: String, placeholder: String, tag: Int, text: String) {
            self.addAddressView.setViewData(contentLabel: contentLabel, placeholder: placeholder, tag: tag, text: text)
            self.addAddressView.contentTextField.delegate = self
    }
        
   func textFieldDidEndEditing(_ textField: UITextField) {
     delegate?.didEndEditing(tag: textField.tag, text: textField.text ?? "")
   }

}
