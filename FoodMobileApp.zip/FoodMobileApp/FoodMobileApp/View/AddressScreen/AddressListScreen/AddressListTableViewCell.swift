//
//  AddressListTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 20/09/23.
//

import UIKit

protocol AddressListTableViewCellDelegate: AnyObject {
    func editButtonTapped(cell: AddressListTableViewCell)
}

class AddressListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var addressListView: InputField!
    
    @IBOutlet weak var editButton: UIButton!

    weak var delegate: AddressListTableViewCellDelegate?
    
    @IBAction func editButtonAction(_ sender: Any) {
        delegate?.editButtonTapped(cell: self)
    }
}
