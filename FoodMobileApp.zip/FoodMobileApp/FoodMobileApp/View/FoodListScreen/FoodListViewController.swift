//
//  FoodListViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import UIKit

class FoodListViewController: UIViewController {
    
    @IBOutlet weak var foodListTableView: UITableView!
    @IBOutlet weak var cartNavigationButton: UIButton!
    
    var selectedCategory: String?
    var foods: [MenuItem] = []
    var filteredFoods: [MenuItem] = []
    var foodListViewModel = FoodListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        foodListTableView.dataSource = self
        foodListTableView.delegate = self
        foodListTableView.register(UINib(nibName: "FoodListTableViewCell", bundle: nil), forCellReuseIdentifier: "FoodListTableViewCell")
        print("foods in FoodListViewController: \(foods)")
        filterFoodsByCategory()

        foodListViewModel.fetchApi (selectedCategory: selectedCategory) { [weak self] items, error in
               if let error = error {
                   print("Error fetching data: \(error)")
               } else if let items = items {
                   self?.foods = items
                   self?.filteredFoods = items
                   DispatchQueue.main.async {
                       self?.foodListTableView.reloadData()
                   }
               }
           }
    }
    
    // Helper function to filter foods based on the selected category
    private func filterFoodsByCategory() {
        if let selectedCategory = selectedCategory {
            filteredFoods = foods.filter { $0.itemCategory == selectedCategory }
        } else {
            filteredFoods = foods
        }
    }
    
    @IBAction func cartNavigationButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let cartTableVC = storyboard.instantiateViewController(withIdentifier: "MyCartViewController") as! MyCartViewController
        navigationController?.pushViewController(cartTableVC, animated: true)
    }
}

extension FoodListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredFoods.count 
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FoodListTableViewCell", for: indexPath) as! FoodListTableViewCell
        let food = filteredFoods[indexPath.row]
        cell.foodItemName.text = food.itemName
        cell.foodItemName.numberOfLines = 0
        cell.foodItemPrice.text = "Rs.\(food.itemPrice ?? "")"
        
        if let imageURL = food.itemImage {
            if let url = URL(string: imageURL) {
                DispatchQueue.global().async {
                    if let data = try? Data(contentsOf: url) {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.foodListImageView.image = image
                        }
                    }
                }
            }
        } else {
            cell.foodListImageView.image = nil
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedFood = filteredFoods[indexPath.row]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if let foodDetailVC = storyboard.instantiateViewController(withIdentifier: "FoodDetailViewController") as? FoodDetailViewController {
            foodDetailVC.foodItem = selectedFood
            navigationController?.pushViewController(foodDetailVC, animated: true)
        }
    }
}
