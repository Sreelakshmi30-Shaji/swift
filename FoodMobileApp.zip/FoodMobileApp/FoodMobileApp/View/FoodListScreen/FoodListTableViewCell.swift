//
//  FoodListTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import UIKit

class FoodListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var foodListView: UIView!
    @IBOutlet weak var foodListImageView: UIImageView!
    @IBOutlet weak var foodItemName: UILabel!
    @IBOutlet weak var foodItemPrice: UILabel!    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
   
