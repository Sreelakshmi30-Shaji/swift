//
//  SignInTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 15/09/23.
//

import UIKit

class SignInTableViewCell: UITableViewCell {

    @IBOutlet weak var inuputField: InputField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        inuputField.setViewData(contentLabel: "Username", placeholder: "Enter your username", tag: 0, text: "")
        inuputField.setViewData(contentLabel: "Password", placeholder: "Enter your password", tag: 0, text: "")

    }
}
