//
//  SignInViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 15/09/23.
//

import UIKit

class SignInViewController: UIViewController {
    
    @IBOutlet weak var signInImageView: UIImageView!
    @IBOutlet weak var signInLabel: UILabel!
    @IBOutlet weak var signInTableView: UITableView!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var signInAccountLabel: UILabel!
    @IBOutlet weak var signUpButton: UIButton!
    
    let formFields = ["Username","Password"]
    var signUpViewModel = SignUpViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        signInTableView.dataSource = self
        signInTableView.delegate = self
        signInTableView.register(UINib(nibName: "SignInTableViewCell", bundle: nil), forCellReuseIdentifier: "SignInCell")
        signInButton.layer.cornerRadius = 20
    }
    
    @IBAction func signInButtonAction(_ sender: Any) {
        if let usernameCell = signInTableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? SignInTableViewCell,
           let passwordCell = signInTableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? SignInTableViewCell {
            
            guard let username = usernameCell.inuputField.contentTextField.text,
                  let password = passwordCell.inuputField.contentTextField.text else {
                return
            }
            if let user = signUpViewModel.fetchUser(userName: username),
               user.password == password {
                print("Login successful!")
                
                user.isLogin = true
                signUpViewModel.saveContext()
                
                UserDefaults.standard.set(username, forKey: "LoggedInUsername")
                
                let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                toastView.translatesAutoresizingMaskIntoConstraints = false
                self.view.addSubview(toastView)
                toastView.show(message: "Login Successfull")
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let homeVC = storyboard.instantiateViewController(withIdentifier: "HomeScreenViewController") as! HomeScreenViewController
                navigationController?.pushViewController(homeVC, animated: true)
                
            } else {
                print("Login failed. Invalid username or password.")
                let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                toastView.translatesAutoresizingMaskIntoConstraints = false
                self.view.addSubview(toastView)
                toastView.show(message: "Login Failed")
            }
        }
    }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let signupVC = storyboard.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
        navigationController?.pushViewController(signupVC, animated: true)
    }
}

extension SignInViewController : UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return formFields.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SignInCell", for: indexPath) as! SignInTableViewCell
        cell.inuputField.setViewData(contentLabel: formFields[indexPath.row], placeholder: "Enter your \(formFields[indexPath.row].lowercased())", tag: indexPath.row, text: "")
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
}
