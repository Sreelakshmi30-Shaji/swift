//
//  MyCartViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 19/09/23.
//

import UIKit

class MyCartViewController: UIViewController {
    
    @IBOutlet weak var cartTableView: UITableView!
    @IBOutlet weak var totalPriceButton: UIButton!
    
    var menuItem: MenuItem?
    var menuItems : [MenuItem] = []
    var savedForLaterItems: [MenuItem] = []
    var cartViewModel = CartViewModel()
    var signUpViewModel = SignUpViewModel()
    var shippingViewController =  ShippingViewController()
    var loggedInUsername: String = ""
    var loggedInUserId: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        totalPriceButton.layer.cornerRadius = 20
        cartTableView.dataSource = self
        cartTableView.delegate = self
        cartTableView.register(UINib(nibName: "CartTableViewCell", bundle: nil), forCellReuseIdentifier: "CartTableViewCell")
        refreshData()
    }
    
    @IBAction func totalPriceButtonAction(_ sender: Any) {
        let totalOrderPrice = cartViewModel.calculateTotalPrice(for: menuItems)
        let orderPlacementVC = storyboard?.instantiateViewController(withIdentifier: "OrderPlacementViewController") as! OrderPlacementViewController
        orderPlacementVC.cartItems = menuItems // Pass the ordered items
        orderPlacementVC.totalOrderPrice = totalOrderPrice
        
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
        
                var addressComponents: [String] = []
                
                if let address1 = user.address?.address1, !address1.isEmpty {
                    addressComponents.append(address1)
                }
                if let address2 = user.address?.address2, !address2.isEmpty {
                    addressComponents.append(address2)
                }
                if let state = user.address?.state, !state.isEmpty {
                    addressComponents.append(state)
                }
                if let country = user.address?.country, !country.isEmpty {
                    addressComponents.append(country)
                }
                if let pincode = user.address?.pincode, !pincode.isEmpty {
                    addressComponents.append(pincode)
                }
                let loggedInUserAddress = addressComponents.joined(separator: ", ")
                
                if let firstName = user.firstName, let lastName = user.lastName {
                            let fullName = "\(firstName) \(lastName)"
                            orderPlacementVC.loggedInUserName = fullName
                        }
                orderPlacementVC.loggedInUserEmail = user.emailAddress
                orderPlacementVC.loggedInUserPhoneNumber = user.phoneNumber
                orderPlacementVC.loggedInUserAddress = loggedInUserAddress
                
                navigationController?.pushViewController(orderPlacementVC, animated: true)
            } else {
                print("User not found in Core Data")
            }
        } else {
            print("No Logged-in Username")
        }
    }

    func refreshData() {
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                if let loggedInUserId = user.userId {
                    print("Logged-in User ID: \(loggedInUserId)")
                    
                    cartViewModel.retrieveData(loggedInUserId: loggedInUserId) { items, error in
                        if let error = error {
                            print("Error retrieving data: \(error)")
                            return
                        }
                        guard let items = items else {
                            return
                        }
                        self.menuItems.removeAll()
                        self.savedForLaterItems.removeAll()
                        for item in items {
                            if item.isSaveForLater! {
                                self.savedForLaterItems.append(item)
                            } else {
                                self.menuItems.append(item)
                                self.updateTotalPriceLabel()
                                self.cartTableView.reloadData()
                            }
                        }
                        self.updateTotalPriceLabel()
                        self.cartTableView.reloadData()
                    }
                }
            }
        }
    }

    func updateTotalPriceLabel() {
        let totalPrice = cartViewModel.calculateTotalPrice(for: menuItems)
        if menuItems.isEmpty {
            totalPriceButton.isHidden = true
        } else {
            totalPriceButton.isHidden = false
            totalPriceButton.setTitle("Total Price in Cart : Rs.\(totalPrice)", for: .normal)
        }
        cartTableView.reloadData()
    }
    
    func updateButtonTitle(for cell: CartTableViewCell, at indexPath: IndexPath) {
        let section = indexPath.section
        if section == 0 {
            cell.saveForLaterButton.setTitle("Save for Later", for: .normal)
            cell.saveForLaterButton.backgroundColor = UIColor.systemCyan
        } else if section == 1 {
            cell.saveForLaterButton.setTitle("Move to Cart", for: .normal)
            cell.saveForLaterButton.backgroundColor = UIColor.systemMint
        }
    }
    
    func incrementProductCount(at indexPath: IndexPath) {
          let product = cartViewModel.cartItem[indexPath.row]
          
          if let currentCount = product.count {
              if currentCount >= 10 {
                  let toastView = ToastView(frame: CGRect(x: 110, y: 10, width: 200, height: 50))
                  toastView.translatesAutoresizingMaskIntoConstraints = false
                  view.addSubview(toastView)
                  toastView.show(message: "Limit Exceeded")
              } else {
                  cartViewModel.cartItem[indexPath.row].count = currentCount + 1
                  cartViewModel.incrementProductCount(for: product)
              }
          } else {
              cartViewModel.cartItem[indexPath.row].count = 1
              cartViewModel.incrementProductCount(for: product)
          }
        cartTableView.reloadData()
      }
    
    func decrementProductCount(at indexPath: IndexPath) {
          let product = cartViewModel.cartItem[indexPath.row]
          if let currentCount = product.count, currentCount > 1 {
              cartViewModel.cartItem[indexPath.row].count = currentCount - 1
          } else {
              cartViewModel.cartItem[indexPath.row].count = 1
          }
        cartViewModel.decrementProductCount(for: product)
      }
    
    func saveProductForLater(at indexPath: IndexPath) {
        guard indexPath.row < menuItems.count else {
            print("Invalid index path.")
            return
        }
        var product = menuItems[indexPath.row]
        product.isSaveForLater = true
        cartViewModel.moveItemToSavedForLater(foodItem: product) { [weak self] success in
            if success {
                print("Item moved to 'Saved for Later'")
                self?.menuItems.remove(at: indexPath.row)
                self?.savedForLaterItems.append(product)
                self?.updateTotalPriceLabel()
            } else {
                print("Failed to move item to 'Saved for Later'")
            }
        }
    }
    
    func moveToCart(at indexPath: IndexPath) {
        var product = savedForLaterItems[indexPath.row]
        product.isSaveForLater = false
        menuItems.append(product)
        savedForLaterItems.remove(at: indexPath.row)
        updateTotalPriceLabel()
        cartViewModel.moveItemToCart(foodItem: product) { success in
            if success {
                print("Item moved to cart in Core Data")
            } else {
                print("Failed to move item to cart in Core Data")
            }
        }
    }
    
    func deleteCartItem(at indexPath: IndexPath) {
            let product = menuItems[indexPath.row]
            cartViewModel.deleteCartItem(cartItem: product) { success in
                if success {
                    self.menuItems.remove(at: indexPath.row)
                    self.cartTableView.deleteRows(at: [indexPath], with: .fade)
                    self.updateTotalPriceLabel()
                } else {
                    print("Failed to delete cart item.")
                }
            }
        }

    func deleteSavedItem(at indexPath: IndexPath) {
            let product = savedForLaterItems[indexPath.row]
            cartViewModel.deleteSavedItem(cartItem: product) { success in
                if success {
                    self.savedForLaterItems.remove(at: indexPath.row)
                    self.cartTableView.deleteRows(at: [indexPath], with: .fade)
                } else {
                    print("Failed to delete saved item.")
                }
            }
        }
  }

extension MyCartViewController : UITableViewDataSource, UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return menuItems.count
        } else if section == 1 {
            return savedForLaterItems.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartTableViewCell", for: indexPath) as! CartTableViewCell
        var menuItem: MenuItem
        if indexPath.section == 0 {
            menuItem = menuItems[indexPath.row]
        } else {
            menuItem = savedForLaterItems[indexPath.row]
        }
        cell.menuItem = menuItem
        
        cell.cartItemName.text = menuItem.itemName
        cell.cartItemName.font = UIFont.boldSystemFont(ofSize: 18)
        
        cell.cartItemDescription.text = menuItem.itemDescription
        cell.cartItemDescription.numberOfLines = 0
        
        cell.cartItemRating.text = "Rating : \(menuItem.itemRating ?? "")"
        
        cell.cartItemPrice.text = "Rs.\(menuItem.itemPrice ?? "")"
        
        cell.countLabel.text = indexPath.section == 0 ? "\(menuItem.count ?? 1)" : nil
        
        cell.incrementButton.isHidden = indexPath.section == 0 ? false : true
        cell.decrementButton.isHidden = indexPath.section == 0 ? false : true
        cell.decrementButton.isEnabled = (menuItem.count ?? 1) > 1

        if let imageURL = menuItem.itemImage {
            if let url = URL(string: imageURL) {
                DispatchQueue.global().async {
                    if let data = try? Data(contentsOf: url) {
                        let image = UIImage(data: data)
                        DispatchQueue.main.async {
                            cell.cartImageView.image = image
                        }
                    }
                }
            }
        } else {
            cell.cartImageView.image = nil
        }
        updateButtonTitle(for: cell, at: indexPath)

      cell.incrementAction = { [weak self] in
       self?.cartViewModel.incrementProductCount(for: menuItem)
       self?.refreshData()
     }
     cell.decrementAction = { [weak self] in
         self?.cartViewModel.decrementProductCount(for: menuItem)
         self?.refreshData()
     }
    cell.saveForLaterAction = { [weak self] in
      guard let self = self else { return }
        if indexPath.section == 0 {
         self.saveProductForLater(at: indexPath)
        } else if indexPath.section == 1 {
         self.moveToCart(at: indexPath)
     }
     self.refreshData()
   }
  return cell
}
    
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
     }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 && !menuItems.isEmpty || section == 1 && !savedForLaterItems.isEmpty {
            let title = section == 0 ? "Cart" : "Saved for Later"
            let count = section == 0 ? menuItems.reduce(0) { $0 + ($1.count ?? 0) } : savedForLaterItems.reduce(0) { $0 + ($1.count ?? 0) }
            
            let headerHeight: CGFloat = 30
            let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: headerHeight))
            headerView.backgroundColor = UIColor.systemGray
            
            let titleLabel = UILabel(frame: CGRect(x: 16, y: 0, width: tableView.frame.width - 32, height: headerHeight))
            titleLabel.font = UIFont.boldSystemFont(ofSize: 16)
            titleLabel.textColor = UIColor.white
            titleLabel.text = "\(title) (\(count))"
            headerView.addSubview(titleLabel)
            
            return headerView
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (section == 0 && !menuItems.isEmpty) || (section == 1 && !savedForLaterItems.isEmpty) ? 30 : CGFloat.leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if indexPath.section == 0 {
                deleteCartItem(at: indexPath)
            } else if indexPath.section == 1 {
                deleteSavedItem(at: indexPath)
            }
        }
    }
}
