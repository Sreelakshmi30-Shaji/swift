//
//  CartTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 22/09/23.
//

import UIKit

class CartTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cartView: UIView!
    @IBOutlet weak var cartImageView: UIImageView!
    @IBOutlet weak var cartItemName: UILabel!
    @IBOutlet weak var cartItemDescription: UILabel!
    @IBOutlet weak var cartItemPrice: UILabel!
    @IBOutlet weak var cartItemRating: UILabel!
    @IBOutlet weak var saveForLaterButton: UIButton!
    @IBOutlet weak var incrementButton: UIButton!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var decrementButton: UIButton!
    
    var menuItem : MenuItem?
    
    var incrementAction: (() -> Void)?
    var decrementAction: (() -> Void)?
    var saveForLaterAction: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    @IBAction func saveForLaterButtonAction(_ sender: Any) {
        saveForLaterAction?()
    }
    
    @IBAction func incrementButtonAction(_ sender: Any) {
        incrementAction?()
    }
    
    @IBAction func decrementButtonAction(_ sender: Any) {
        decrementAction?()
    }
}
