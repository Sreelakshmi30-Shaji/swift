//
//  FoodDetailLabelTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import UIKit

class FoodDetailLabelTableViewCell: UITableViewCell {
    
    @IBOutlet weak var foodDetailLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
