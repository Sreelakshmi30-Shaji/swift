//
//  FoodDetailImageTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import UIKit

class FoodDetailImageTableViewCell: UITableViewCell {
    
    @IBOutlet weak var foodDetailImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
