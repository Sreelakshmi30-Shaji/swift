//
//  FoodDetailCartButtonTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import UIKit

class FoodDetailCartButtonTableViewCell: UITableViewCell {
    
    var foodItem: MenuItem?
    var cartItems : [MenuItem] = []
    var cartViewModel = CartViewModel()
    @IBOutlet weak var foodDetailCartButton: UIButton!
    var signUpViewModel = SignUpViewModel()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        foodDetailCartButton.layer.cornerRadius = 20
    }
    
    
    @IBAction func foodDetailCartButtonAction(_ sender: Any) {
        guard let foodItem = foodItem else {
            return
        }
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                if let loggedInUserId = user.userId {
                    print("Logged-in User ID: \(loggedInUserId)")
                    cartViewModel.addItemToCoreData(itemData: foodItem, userId: loggedInUserId) { success in
                        if success {
                            print("Item added to cart")
                        } else {
                            print("Failed to add item to cart")
                        }
                    }
                    
                }
            }
        }
        
    }
}
