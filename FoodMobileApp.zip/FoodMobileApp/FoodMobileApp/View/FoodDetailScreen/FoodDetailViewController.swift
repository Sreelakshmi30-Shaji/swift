//
//  FoodDetailViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 21/09/23.
//

import UIKit

class FoodDetailViewController: UIViewController {
    
    @IBOutlet weak var foodDetailTableView: UITableView!
    @IBOutlet weak var cartNavigationButton: UIButton!
    
    var foodItem: MenuItem?

    
    override func viewDidLoad() {
        super.viewDidLoad()

        foodDetailTableView.dataSource = self
        foodDetailTableView.delegate = self
        foodDetailTableView.register(UINib(nibName: "FoodDetailImageTableViewCell", bundle: nil), forCellReuseIdentifier: "FoodDetailImageTableViewCell")
        foodDetailTableView.register(UINib(nibName: "FoodDetailLabelTableViewCell", bundle: nil), forCellReuseIdentifier: "FoodDetailLabelTableViewCell")
        foodDetailTableView.register(UINib(nibName: "FoodDetailCartButtonTableViewCell", bundle: nil), forCellReuseIdentifier: "FoodDetailCartButtonTableViewCell")
    }
    
    @IBAction func cartNavigationButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let cartTableVC = storyboard.instantiateViewController(withIdentifier: "MyCartViewController") as! MyCartViewController
        navigationController?.pushViewController(cartTableVC, animated: true)
    }
    
}

extension FoodDetailViewController : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            if indexPath.row == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "FoodDetailImageTableViewCell", for: indexPath) as! FoodDetailImageTableViewCell
                if let imageURL = foodItem?.itemImage {
                    if let url = URL(string: imageURL) {
                        DispatchQueue.global().async {
                            if let data = try? Data(contentsOf: url) {
                                let image = UIImage(data: data)
                                DispatchQueue.main.async {
                                    cell.foodDetailImageView.image = image
                                }
                            }
                        }
                    }
                }
                return cell
            } else if indexPath.row == 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "FoodDetailLabelTableViewCell", for: indexPath) as! FoodDetailLabelTableViewCell
                if let foodItem = foodItem {
                    cell.foodDetailLabel.text = foodItem.itemName
                    cell.foodDetailLabel.font = UIFont.boldSystemFont(ofSize: 20)
                }
                return cell
            } else if indexPath.row == 2 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "FoodDetailLabelTableViewCell", for: indexPath) as! FoodDetailLabelTableViewCell
                if let foodItem = foodItem {
                    cell.foodDetailLabel.text = foodItem.itemDescription
                    cell.foodDetailLabel.textAlignment = .natural
                }
                return cell
            } else if indexPath.row == 3 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "FoodDetailLabelTableViewCell", for: indexPath) as! FoodDetailLabelTableViewCell
                if let foodItem = foodItem {
                    cell.foodDetailLabel.text = "Rs. \(foodItem.itemPrice ?? "")"
                }
                return cell
            } else if indexPath.row == 4 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "FoodDetailLabelTableViewCell", for: indexPath) as! FoodDetailLabelTableViewCell
                if let foodItem = foodItem {
                    cell.foodDetailLabel.text = "Rating : \(foodItem.itemRating ?? "")"
                }
                return cell
            } else if indexPath.row == 5 {
                let cell = tableView.dequeueReusableCell(withIdentifier: "FoodDetailCartButtonTableViewCell", for: indexPath) as! FoodDetailCartButtonTableViewCell
                cell.foodItem = foodItem
                return cell
            }
            return UITableViewCell()
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            if indexPath.row == 0 {
                return 300
            } else if indexPath.row == 1 {
                return 80
            } else if indexPath.row == 2 {
                return UITableView.automaticDimension
            } else if indexPath.row == 3 {
                return 60
            } else if indexPath.row == 4 {
                return 60
            }else if indexPath.row == 5 {
                return 60
            }else {
                return UITableView.automaticDimension
            }
        }
    }
