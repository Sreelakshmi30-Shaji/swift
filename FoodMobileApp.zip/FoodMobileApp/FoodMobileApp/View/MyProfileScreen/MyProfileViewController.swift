//
//  MyProfileViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 19/09/23.
//

import UIKit

class MyProfileViewController: UIViewController {

    @IBOutlet weak var myProfileTableView: UITableView!
    @IBOutlet weak var editButton: UIButton!
    
    var profileData: [SignUpEntity] = []
    var loggedInUser: SignUpEntity?
    var signUpViewModel = SignUpViewModel()
    var editingUser: SignUpEntity? 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myProfileTableView.dataSource = self
        myProfileTableView.delegate = self
        myProfileTableView.register(UINib(nibName: "SignUpTableViewCell", bundle: nil), forCellReuseIdentifier: "SignUpCell")
        self.title = "My Profile"
        fetchLoggedInUserProfile()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchLoggedInUserProfile()
        myProfileTableView.reloadData()
    }

    
    func fetchLoggedInUserProfile() {
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
            if let userProfile = signUpViewModel.fetchUser(userName: loggedInUsername) {
                profileData = [userProfile]
                 myProfileTableView.reloadData()
            }
        }
    }
    
    @IBAction func editButtonAction(_ sender: Any) {
        if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername"),
           let userProfile = signUpViewModel.fetchUser(userName: loggedInUsername) {
            editingUser = userProfile
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let editProfileVC = storyboard.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
            editProfileVC.isEditMode = true
            editProfileVC.editingUser = userProfile
            navigationController?.pushViewController(editProfileVC, animated: true)
        } else {
        }
    }

}

extension MyProfileViewController : UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return profileData.count * 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SignUpCell", for: indexPath) as! SignUpTableViewCell
        let userProfile = profileData[indexPath.row / 6]
        let fieldIndex = indexPath.row % 6
        let fieldText = getFieldText(userProfile, atIndex: fieldIndex)
        
        cell.setCellData(
            contentLabel: "",
            placeholder: "",
            tag: indexPath.row,
            text: fieldText
        )
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    private func getFieldText(_ userProfile: SignUpEntity, atIndex index: Int) -> String {
        switch index {
        case 0:
            if let firstName = userProfile.firstName {
                return "First Name: \(firstName)"
            }
        case 1:
            if let lastName = userProfile.lastName {
                return "Last Name: \(lastName)"
            }
        case 2:
            if let phoneNumber = userProfile.phoneNumber {
                return "Phone Number: \(phoneNumber)"
            }
        case 3:
            if let emailAddress = userProfile.emailAddress {
                return "Email Address: \(emailAddress)"
            }
        case 4:
            if let userName = userProfile.userName {
                return "User Name: \(userName)"
            }
        case 5:
            if let password = userProfile.password {
                return "Password: \(password)"
            }
        case 6:
            if let confirmPassword = userProfile.confirmPassword {
                return "Confirm Password: \(confirmPassword)"
            }
        default:
            return ""
        }
        return ""
    }

}
