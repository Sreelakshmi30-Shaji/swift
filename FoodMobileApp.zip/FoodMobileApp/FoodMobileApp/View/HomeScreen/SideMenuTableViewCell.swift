//
//  SideMenuTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 19/09/23.
//

import UIKit

class SideMenuTableViewCell: UITableViewCell {
    
    @IBOutlet weak var menuItemLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
