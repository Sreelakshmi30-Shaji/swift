//
//  HomeScreenViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 18/09/23.
//

import UIKit

class HomeScreenViewController: UIViewController{
    
    @IBOutlet weak var sideMenuTableView: UITableView!
    @IBOutlet weak var menuBarButton: UIBarButtonItem!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var defaultImageView: UIImageView!
    @IBOutlet weak var foodCollectionsLabel: UILabel!
    @IBOutlet weak var foodCollectionView: UICollectionView!
    
    var filteredFoods: [MenuItem] = []
    var foods: [MenuItem] = []
    var cartItems: [MenuItem] = []
    var totalOrderPrice: Double = 0.0
    var menOut = false
    let menuItems = ["My Profile", "View Address", "My Cart","My Orders", "Logout"]
    let foodCategories = [
            FoodCategory(itemCategory: "Breakfast", imageName: "breakfast_image"),
            FoodCategory(itemCategory: "Lunch", imageName: "lunch_image"),
            FoodCategory(itemCategory: "Snacks", imageName: "snacks_image"),
            FoodCategory(itemCategory: "Beverages", imageName: "beverages_image"),
            FoodCategory(itemCategory: "Dinner", imageName: "dinner_image"),
        ]
    var loggedInUserName: String?
    var loggedInUserEmail: String?
    var loggedInUserPhoneNumber: String?
    var loggedInUserAddress: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sideMenuTableView.dataSource = self
        sideMenuTableView.delegate = self
        sideMenuTableView.register(UINib(nibName: "SideMenuTableViewCell", bundle: nil), forCellReuseIdentifier: "SideMenuCell")
            sideMenuTableView.isHidden = true
            sideMenuTableView.layer.cornerRadius = 15
            sideMenuTableView.clipsToBounds = true
            sideMenuTableView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        foodCollectionView.dataSource = self
        foodCollectionView.delegate = self
        foodCollectionView.register(UINib(nibName: "FoodCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "FoodCollectionViewCell")
        let flowLayout = UICollectionViewFlowLayout()
            flowLayout.scrollDirection = .horizontal
            flowLayout.itemSize = CGSize(width: 250, height: 250)
            flowLayout.minimumInteritemSpacing = 10
            flowLayout.minimumLineSpacing = 10 
            foodCollectionView.collectionViewLayout = flowLayout
        
     }
    
    @IBAction func menuBarButtonAction(_ sender: Any) {
        sideMenuTableView.isHidden.toggle()
    }
    
    func showLogoutAlert() {
        let alert = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Logout", style: .destructive) { [weak self] _ in
            self?.performLogout()
        })
        present(alert, animated: true, completion: nil)
    }

    func performLogout() {
        if let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignInViewController") as? SignInViewController {
            let navigationController = UINavigationController(rootViewController: loginVC)
            navigationController.modalPresentationStyle = .fullScreen
            present(navigationController, animated: true, completion: nil)
        }
    }
}

extension HomeScreenViewController : UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath) as! SideMenuTableViewCell
                cell.menuItemLabel.text = menuItems[indexPath.row]
                return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedItem = menuItems[indexPath.row]
            switch selectedItem {
            case "My Profile":
                let myProfileVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MyProfileViewController") as! MyProfileViewController
                navigationController?.pushViewController(myProfileVC, animated: true)
                break
            case "View Address":
                let myAddressVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddressListViewController") as! AddressListViewController
                navigationController?.pushViewController(myAddressVC, animated: true)
                break
            case "My Cart":
                let myCartVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MyCartViewController") as! MyCartViewController
                navigationController?.pushViewController(myCartVC, animated: true)
                break
            case "My Orders":
                let myOrderVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ShippingViewController") as! ShippingViewController
                  myOrderVC.cartItems = cartItems
                  myOrderVC.totalOrderPrice = totalOrderPrice
                  myOrderVC.loggedInUserName = loggedInUserName
                  myOrderVC.loggedInUserEmail = loggedInUserEmail
                  myOrderVC.loggedInUserPhoneNumber = loggedInUserPhoneNumber
                  myOrderVC.loggedInUserAddress = loggedInUserAddress
                navigationController?.pushViewController(myOrderVC, animated: true)
                break
            case "Logout":
                showLogoutAlert()
                break
            default:
                break
            }
        }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
}

extension HomeScreenViewController : UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return foodCategories.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FoodCollectionViewCell", for: indexPath) as! FoodCollectionViewCell
        let category = foodCategories[indexPath.item]
        cell.foodCollectionNameLabel.text = category.itemCategory
        cell.foodCollectionImageView.image = UIImage(named: category.imageName)
        return cell
    }
        
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedCategory = foodCategories[indexPath.item].itemCategory
        // Filter the foods based on the selected category
        let filteredFoods = foods.filter { $0.itemCategory == selectedCategory }
        if let foodListVC = storyboard?.instantiateViewController(withIdentifier: "FoodListViewController") as? FoodListViewController {
            foodListVC.selectedCategory = selectedCategory
            foodListVC.foods = filteredFoods
            navigationController?.pushViewController(foodListVC, animated: true)
        }
    }

}

