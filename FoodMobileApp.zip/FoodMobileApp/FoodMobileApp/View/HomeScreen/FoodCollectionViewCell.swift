//
//  FoodCollectionViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 19/09/23.
//

import UIKit

class FoodCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var foodCollectionImageView: UIImageView!
    @IBOutlet weak var foodCollectionNameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
