//
//  SignUpTableViewCell.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 18/09/23.
//

import UIKit

protocol SignUpCellDelegate: AnyObject {
    func didEndEditing(tag: Int, text: String)
    
}

class SignUpTableViewCell: UITableViewCell, UITextFieldDelegate {
    
    var delegate: SignUpCellDelegate?
    @IBOutlet weak var inputField: InputField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        inputField.contentTextField.delegate = self

    }
    
    static func cell(for tableView: UITableView,
                     at indexPath: IndexPath,
                     withIdentifier identifier: String? = nil) -> SignUpTableViewCell {
        let dequedCell = tableView.dequeueReusableCell(withIdentifier: "SignUpCell", for: indexPath)
        guard let cell = dequedCell as? SignUpTableViewCell else {
            return SignUpTableViewCell()
        }
        return cell
    }

    func setCellData(contentLabel: String, placeholder: String, tag: Int, text: String) {
        self.inputField.setViewData(contentLabel: contentLabel, placeholder: placeholder, tag: tag, text: text)
        self.inputField.contentTextField.delegate = self
//        if let errorMessage = signUpViewModel.validationErrors[tag] {
//            inputField.validationLabel.text = errorMessage
//            inputField.validationLabel.isHidden = false
//              } else {
//                  inputField.validationLabel.isHidden = true
//              }
          }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
            delegate?.didEndEditing(tag: textField.tag, text: textField.text ?? "")
        }
    
}
