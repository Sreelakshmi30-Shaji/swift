//
//  SignUpViewController.swift
//  FoodMobileApp
//
//  Created by Sreelakshmi on 15/09/23.
//

import UIKit

class SignUpViewController: UIViewController, SignUpCellDelegate {

    @IBOutlet weak var signUpTableView: UITableView!
    @IBOutlet weak var signUpButton: UIButton!
    var signUpViewModel = SignUpViewModel()
    var signUp: SignUp?
    var toastView = ToastView()
    var isEditMode = false
    var editingUser: SignUpEntity?
    var addressData: Address?

    override func viewDidLoad() {
        super.viewDidLoad()
        signUpButton.layer.cornerRadius = 20
        signUpTableView.register(UINib(nibName: "SignUpTableViewCell", bundle: nil), forCellReuseIdentifier: "SignUpCell")
        signUpTableView.dataSource = self
        signUpTableView.delegate = self
        updateSignUpButtonState()
        signUp = SignUp()
        signUpViewModel.printPersistentStoreInfo()
           if isEditMode {
                    self.title = "Edit Profile"
                    signUpButton.setTitle("Update", for: .normal)
                    if let loggedInUsername = UserDefaults.standard.string(forKey: "LoggedInUsername") {
                              if let user = signUpViewModel.fetchUser(userName: loggedInUsername) {
                                  editingUser = user
                                  populateTextFieldsWithUserData()
                              }
                          }
                } else {
                    self.title = "Sign Up"
                    signUpButton.setTitle("Sign Up", for: .normal)
            }
       }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        if isEditMode {
            performUpdate()
        } else {
            performSignUp()
        }
    }
    
    func populateTextFieldsWithUserData() {
        if let signUp = editingUser {
            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.firstName
            }

            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.lastName
            }

            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.phoneNumber
            }

            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 3, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.emailAddress
            }

            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 4, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.userName
            }

            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 5, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.password
            }

            if let cell = signUpTableView.cellForRow(at: IndexPath(row: 6, section: 0)) as? SignUpTableViewCell {
                cell.inputField.contentTextField.text = signUp.confirmPassword
            }
        }
    }

    private func performSignUp() {
        var isValid = true
        
        for tag in 0..<7 {
            if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
                let inputText = cell.inputField.contentTextField.text ?? ""
                signUpViewModel.validateAndShowErrors(for: tag, text: inputText)
                
                if !signUpViewModel.isValidationHidden(for: tag) {
                    cell.inputField.validationLabel.text = signUpViewModel.validationErrors[tag]
                    cell.inputField.validationLabel.isHidden = false
                    isValid = false
                } else {
                    cell.inputField.validationLabel.isHidden = true
                }
            }
        }
        
        // Check if passwords match
        if let confirmPasswordCell = signUpTableView.cellForRow(at: IndexPath(row: 6, section: 0)) as? SignUpTableViewCell {
            let confirmPasswordText = confirmPasswordCell.inputField.contentTextField.text ?? ""
            if !signUpViewModel.passwordsMatch(password: confirmPasswordText, confirmPassword: signUp?.password ?? "") {
                confirmPasswordCell.inputField.validationLabel.text = "Passwords do not match"
                confirmPasswordCell.inputField.validationLabel.isHidden = false
                isValid = false
            }
        }
        
        if isValid {
            // Perform the sign-up process
                signUpViewModel.addItemToCoreData(itemData: signUp!) { [weak self] success in
                    if success {
                        let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                        toastView.translatesAutoresizingMaskIntoConstraints = false
                        self?.view.addSubview(toastView)
                        toastView.show(message: "Registration Successful")
                        self?.navigationController?.popViewController(animated: true)
                    } else {
                        let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                        toastView.translatesAutoresizingMaskIntoConstraints = false
                        self?.view.addSubview(toastView)
                        toastView.show(message: "Registration Failed")
                    }
                }
            }
        }
    
    private func performUpdate() {
        var isValid = true

        for tag in 0..<7 {
            if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
                let inputText = cell.inputField.contentTextField.text ?? ""
                signUpViewModel.validateAndShowErrors(for: tag, text: inputText)

                if !signUpViewModel.isValidationHidden(for: tag) {
                    cell.inputField.validationLabel.text = signUpViewModel.validationErrors[tag]
                    cell.inputField.validationLabel.isHidden = false
                    isValid = false
                } else {
                    cell.inputField.validationLabel.isHidden = true
                }
            }
        }

        // Check if passwords match
        if let confirmPasswordCell = signUpTableView.cellForRow(at: IndexPath(row: 6, section: 0)) as? SignUpTableViewCell {
            let confirmPasswordText = confirmPasswordCell.inputField.contentTextField.text ?? ""
            if !signUpViewModel.passwordsMatch(password: confirmPasswordText, confirmPassword: signUp?.password ?? "") {
                confirmPasswordCell.inputField.validationLabel.text = "Passwords do not match"
                confirmPasswordCell.inputField.validationLabel.isHidden = false
                isValid = false
            }
        }

        if isValid {
            // Update the signUp object with the new values
            for tag in 0..<7 {
                if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
                    let inputText = cell.inputField.contentTextField.text ?? ""
                    switch tag {
                    case 0:
                        signUp?.firstName = inputText
                    case 1:
                        signUp?.lastName = inputText
                    case 2:
                        signUp?.phoneNumber = inputText
                    case 3:
                        signUp?.emailAddress = inputText
                    case 4:
                        signUp?.userName = inputText
                    case 5:
                        signUp?.password = inputText
                    case 6:
                        signUp?.confirmPassword = inputText
                    default:
                        break
                    }
                }
            }

            signUpViewModel.updateUser(itemID: editingUser?.userId! ?? "", updatedData: signUp!) { [weak self] success in
                if success {
                    let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    self?.view.addSubview(toastView)
                    toastView.show(message: "Profile Updated Successfully")
                    self?.navigationController?.popViewController(animated: true)
                } else {
                    let toastView = ToastView(frame: CGRect(x: 80, y: 700, width: 250, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    self?.view.addSubview(toastView)
                    toastView.show(message: "Profile Update Failed")
                }
            }
        }
    }


    func updateSignUpButtonState() {
        let areAllFieldsValid = (0..<7).allSatisfy { tag in
            return signUpViewModel.isValidationHidden(for: tag)
        }
        signUpButton.isEnabled = areAllFieldsValid
        signUpButton.alpha = areAllFieldsValid ? 1.0 : 0.5
    }

    func validateAndShowError(for tag: Int, text: String, validationBlock: (String) -> Bool, errorMessage: String) {
        let isValid = validationBlock(text)
        if isValid {
            signUpViewModel.hideErrorValidation(tag: tag)
        } else {
            signUpViewModel.showErrorValidation(tag: tag, message: errorMessage)
            
            if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
                cell.inputField.validationLabel.text = errorMessage
                cell.inputField.validationLabel.isHidden = false
            }
        }
    }
    
    func didEndEditing(tag: Int, text: String) {
        print("Editing ended for tag \(tag) with text: \(text)")
        
        switch tag {
        case 0:
            signUp?.firstName = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isNotEmpty, errorMessage: "Please enter your first name")
        case 1:
            signUp?.lastName = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isNotEmpty, errorMessage: "Please enter your last name")
        case 2:
            signUp?.phoneNumber = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidPhoneNumber, errorMessage: "Invalid phone number")
        case 3:
            signUp?.emailAddress = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidEmail, errorMessage: "Invalid email")
        case 4:
            signUp?.userName = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidUsername, errorMessage: "Please enter a valid username")
        case 5:
            signUp?.password = text
            validateAndShowError(for: tag, text: text, validationBlock: signUpViewModel.isValidPassword, errorMessage: "Please enter a valid password")
        case 6:
            signUp?.confirmPassword = text
            validateAndShowError(for: tag, text: text, validationBlock: { [weak self] confirmPassword in
                guard let password = self?.signUp?.password else { return false }
                return self?.signUpViewModel.passwordsMatch(password: confirmPassword, confirmPassword: password) ?? false
            }, errorMessage: "Passwords do not match")
        default:
            break
        }
       
        if let cell = signUpTableView.cellForRow(at: IndexPath(row: tag, section: 0)) as? SignUpTableViewCell {
            if signUpViewModel.isValidationHidden(for: tag) {
                cell.inputField.validationLabel.isHidden = true
            }
        }
        updateSignUpButtonState()
    }
    
}

extension SignUpViewController : UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SignUpTableViewCell.cell(for: tableView, at: indexPath)
        cell.delegate = self

        if isEditMode {
            // Check if editingUser is not nil
            if let user = editingUser {
                switch indexPath.row {
                case 0:
                    cell.setCellData(contentLabel: "First Name", placeholder: "Enter your first name", tag: 0, text: user.firstName ?? "")
                case 1:
                    cell.setCellData(contentLabel: "Last Name", placeholder: "Enter your last name", tag: 1, text: user.lastName ?? "")
                case 2:
                    cell.setCellData(contentLabel: "Phone Number", placeholder: "Enter your phone number", tag: 2, text: user.phoneNumber ?? "")
                case 3:
                    cell.setCellData(contentLabel: "Email Address", placeholder: "Enter your email id", tag: 3, text: user.emailAddress ?? "")
                case 4:
                    cell.setCellData(contentLabel: "User Name", placeholder: "Enter your user name", tag: 4, text: user.userName ?? "")
                case 5:
                    cell.setCellData(contentLabel: "Password", placeholder: "Enter your password", tag: 5, text: user.password ?? "")
                case 6:
                    cell.setCellData(contentLabel: "Confirm Password", placeholder: "Confirm Your Password", tag: 6, text: user.confirmPassword ?? "")
                default:
                    break
                }
            }
        } else {
            // Display initial registration data
            switch indexPath.row {
            case 0:
                cell.setCellData(contentLabel: "First Name", placeholder: "Enter your first name", tag: 0, text: signUp?.firstName ?? "")
            case 1:
                cell.setCellData(contentLabel: "Last Name", placeholder: "Enter your last name", tag: 1, text: signUp?.lastName ?? "")
            case 2:
                cell.setCellData(contentLabel: "Phone Number", placeholder: "Enter your phone number", tag: 2, text: signUp?.phoneNumber ?? "")
            case 3:
                cell.setCellData(contentLabel: "Email Address", placeholder: "Enter your email id", tag: 3, text: signUp?.emailAddress ?? "")
            case 4:
                cell.setCellData(contentLabel: "User Name", placeholder: "Enter your user name", tag: 4, text: signUp?.userName ?? "")
            case 5:
                cell.setCellData(contentLabel: "Password", placeholder: "Enter your password", tag: 5, text: signUp?.password ?? "")
            case 6:
                cell.setCellData(contentLabel: "Confirm Password", placeholder: "Confirm Your Password", tag: 6, text: signUp?.confirmPassword ?? "")
            default:
                break
            }
        }

        return cell
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    
}
