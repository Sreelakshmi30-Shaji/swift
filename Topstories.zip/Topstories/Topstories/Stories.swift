import Foundation


struct Story: Codable {
    let status_code : String?
    let status_message : String?
    let news_pagination_cap : Int?
    let data : [DataStory]?
    let cube_widget : Cube_widget?
    let cache : Cache?
    let data_source : String?
    
    enum CodingKeys: String, CodingKey {
        
        case status_code = "status_code"
        case status_message = "status_message"
        case news_pagination_cap = "news_pagination_cap"
        case data = "data"
        case cube_widget = "cube_widget"
        case cache = "cache"
        case data_source = "data_source"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status_code = try values.decodeIfPresent(String.self, forKey: .status_code)
        status_message = try values.decodeIfPresent(String.self, forKey: .status_message)
        news_pagination_cap = try values.decodeIfPresent(Int.self, forKey: .news_pagination_cap)
        data = try values.decodeIfPresent([DataStory].self, forKey: .data)
        cube_widget = try values.decodeIfPresent(Cube_widget.self, forKey: .cube_widget)
        cache = try values.decodeIfPresent(Cache.self, forKey: .cache)
        data_source = try values.decodeIfPresent(String.self, forKey: .data_source)
    }
    
}
    
    struct Cache : Codable {
        let redis_ttl : String?
        let akamai_ttl : String?
        
        enum CodingKeys: String, CodingKey {
            
            case redis_ttl = "redis_ttl"
            case akamai_ttl = "akamai_ttl"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            redis_ttl = try values.decodeIfPresent(String.self, forKey: .redis_ttl)
            akamai_ttl = try values.decodeIfPresent(String.self, forKey: .akamai_ttl)
        }
        
    }
    
    struct Cube_widget : Codable {
        let show_widget : String?
        let widget_detail : [Widget_detail]?
        
        enum CodingKeys: String, CodingKey {
            
            case show_widget = "show_widget"
            case widget_detail = "widget_detail"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            show_widget = try values.decodeIfPresent(String.self, forKey: .show_widget)
            widget_detail = try values.decodeIfPresent([Widget_detail].self, forKey: .widget_detail)
        }
        
    }
    
   
       
struct DataStory : Codable {
    let id : String?
    let title : String?
    let label : String?
    let show_label : Int?
    let order : Int?
    let type : String?
    let tag_name : String?
    let cta_text : String?
    let cta_link : String?
    let n_template_id : String?
    let underline_color : String?
    let background_color : String?
    let news : [News]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case title = "title"
        case label = "label"
        case show_label = "show_label"
        case order = "order"
        case type = "type"
        case tag_name = "tag_name"
        case cta_text = "cta_text"
        case cta_link = "cta_link"
        case n_template_id = "n_template_id"
        case underline_color = "underline_color"
        case background_color = "background_color"
        case news = "news"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(String.self, forKey: .id)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        label = try values.decodeIfPresent(String.self, forKey: .label)
        show_label = try values.decodeIfPresent(Int.self, forKey: .show_label)
        order = try values.decodeIfPresent(Int.self, forKey: .order)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        tag_name = try values.decodeIfPresent(String.self, forKey: .tag_name)
        cta_text = try values.decodeIfPresent(String.self, forKey: .cta_text)
        cta_link = try values.decodeIfPresent(String.self, forKey: .cta_link)
        n_template_id = try values.decodeIfPresent(String.self, forKey: .n_template_id)
        underline_color = try values.decodeIfPresent(String.self, forKey: .underline_color)
        background_color = try values.decodeIfPresent(String.self, forKey: .background_color)
        news = try values.decodeIfPresent([News].self, forKey: .news)
    }

}
    
    struct N_blog : Codable {
        let empty : String?
        
        enum CodingKeys: String, CodingKey {
            
            case empty = "empty"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            empty = try values.decodeIfPresent(String.self, forKey: .empty)
        }
        
    }
    
    struct N_carousal_widget : Codable {
        let empty : String?
        
        enum CodingKeys: String, CodingKey {
            
            case empty = "empty"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            empty = try values.decodeIfPresent(String.self, forKey: .empty)
        }
        
    }
    
    struct N_offline_data : Codable {
        let no_desc_withouthtml : String?
        let no_author : No_author?
        
        enum CodingKeys: String, CodingKey {
            
            case no_desc_withouthtml = "no_desc_withouthtml"
            case no_author = "no_author"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            no_desc_withouthtml = try values.decodeIfPresent(String.self, forKey: .no_desc_withouthtml)
            no_author = try values.decodeIfPresent(No_author.self, forKey: .no_author)
        }
        
    }
    
    
    struct News : Codable {
        let n_id : String?
        let n_type : String?
        let n_is_blog : String?
        let n_livetv_enable : String?
        let n_is_developing : String?
        let n_is_sponsored : String?
        let n_share_link : String?
        let n_title : String?
        let n_description : String?
        let n_pcategory_id : String?
        let n_pcategory_name : String?
        let n_comment_count : String?
        let n_small_image : String?
        let n_large_image : String?
        let n_image_credit : String?
        let n_updated_datetime : String?
        let n_highlight : [String]?
       // let n_photo : [String]?
        let n_video : [String]?
        let n_polls : [String]?
        let n_rating : [String]?
        //let n_magazine : [String]?
        let n_widget : [String]?
        let n_blog : N_blog?
        let n_carousal_widget : N_carousal_widget?
        let n_offline_data : N_offline_data?
        let n_emoji_left : [String]?
        let n_emoji_right : [String]?
        
        enum CodingKeys: String, CodingKey {
            
            case n_id = "n_id"
            case n_type = "n_type"
            case n_is_blog = "n_is_blog"
            case n_livetv_enable = "n_livetv_enable"
            case n_is_developing = "n_is_developing"
            case n_is_sponsored = "n_is_sponsored"
            case n_share_link = "n_share_link"
            case n_title = "n_title"
            case n_description = "n_description"
            case n_pcategory_id = "n_pcategory_id"
            case n_pcategory_name = "n_pcategory_name"
            case n_comment_count = "n_comment_count"
            case n_small_image = "n_small_image"
            case n_large_image = "n_large_image"
            case n_image_credit = "n_image_credit"
            case n_updated_datetime = "n_updated_datetime"
            case n_highlight = "n_highlight"
           // case n_photo = "n_photo"
            case n_video = "n_video"
            case n_polls = "n_polls"
            case n_rating = "n_rating"
            //case n_magazine = "n_magazine"
            case n_widget = "n_widget"
            case n_blog = "n_blog"
            case n_carousal_widget = "n_carousal_widget"
            case n_offline_data = "n_offline_data"
            case n_emoji_left = "n_emoji_left"
            case n_emoji_right = "n_emoji_right"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            n_id = try values.decodeIfPresent(String.self, forKey: .n_id)
            n_type = try values.decodeIfPresent(String.self, forKey: .n_type)
            n_is_blog = try values.decodeIfPresent(String.self, forKey: .n_is_blog)
            n_livetv_enable = try values.decodeIfPresent(String.self, forKey: .n_livetv_enable)
            n_is_developing = try values.decodeIfPresent(String.self, forKey: .n_is_developing)
            n_is_sponsored = try values.decodeIfPresent(String.self, forKey: .n_is_sponsored)
            n_share_link = try values.decodeIfPresent(String.self, forKey: .n_share_link)
            n_title = try values.decodeIfPresent(String.self, forKey: .n_title)
            n_description = try values.decodeIfPresent(String.self, forKey: .n_description)
            n_pcategory_id = try values.decodeIfPresent(String.self, forKey: .n_pcategory_id)
            n_pcategory_name = try values.decodeIfPresent(String.self, forKey: .n_pcategory_name)
            n_comment_count = try values.decodeIfPresent(String.self, forKey: .n_comment_count)
            n_small_image = try values.decodeIfPresent(String.self, forKey: .n_small_image)
            n_large_image = try values.decodeIfPresent(String.self, forKey: .n_large_image)
            n_image_credit = try values.decodeIfPresent(String.self, forKey: .n_image_credit)
            n_updated_datetime = try values.decodeIfPresent(String.self, forKey: .n_updated_datetime)
            n_highlight = try values.decodeIfPresent([String].self, forKey: .n_highlight)
          //  n_photo = try values.decodeIfPresent([String].self, forKey: .n_photo)
            n_video = try values.decodeIfPresent([String].self, forKey: .n_video)
            n_polls = try values.decodeIfPresent([String].self, forKey: .n_polls)
            n_rating = try values.decodeIfPresent([String].self, forKey: .n_rating)
           // n_magazine = try values.decodeIfPresent([String].self, forKey: .n_magazine)
            n_widget = try values.decodeIfPresent([String].self, forKey: .n_widget)
            n_blog = try values.decodeIfPresent(N_blog.self, forKey: .n_blog)
            n_carousal_widget = try values.decodeIfPresent(N_carousal_widget.self, forKey: .n_carousal_widget)
            n_offline_data = try values.decodeIfPresent(N_offline_data.self, forKey: .n_offline_data)
            n_emoji_left = try values.decodeIfPresent([String].self, forKey: .n_emoji_left)
            n_emoji_right = try values.decodeIfPresent([String].self, forKey: .n_emoji_right)
        }
        
    }
    
    
    
    struct No_author : Codable {
        let a_title : String?
        
        enum CodingKeys: String, CodingKey {
            
            case a_title = "a_title"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            a_title = try values.decodeIfPresent(String.self, forKey: .a_title)
        }
        
    }
    
    
    struct Widget_detail : Codable {
        let type : String?
        let title : String?
        let type_label : String?
        let height : String?
        let width : String?
        let short_url : String?
        let extended_url : String?
        
        enum CodingKeys: String, CodingKey {
            
            case type = "type"
            case title = "title"
            case type_label = "type_label"
            case height = "height"
            case width = "width"
            case short_url = "short_url"
            case extended_url = "extended_url"
        }
        
        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            type = try values.decodeIfPresent(String.self, forKey: .type)
            title = try values.decodeIfPresent(String.self, forKey: .title)
            type_label = try values.decodeIfPresent(String.self, forKey: .type_label)
            height = try values.decodeIfPresent(String.self, forKey: .height)
            width = try values.decodeIfPresent(String.self, forKey: .width)
            short_url = try values.decodeIfPresent(String.self, forKey: .short_url)
            extended_url = try values.decodeIfPresent(String.self, forKey: .extended_url)
        }
        
    }

