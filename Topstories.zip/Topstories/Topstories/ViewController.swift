

//
//  ViewController.swift
//  Topstories
//
//  Created by Sreelakshmi on 30/11/22.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegateFlowLayout {
    

    @IBOutlet weak var storyCollectionView: UICollectionView!
    
    @IBOutlet weak var storyTabelView: UITableView!
    
    let url = "https://alpha-itappfeeds.intoday.in/app_home.json"
    
    var storymodel : Story?
    var bigstoryModel : DataStory?
    var bigstory : [News]? = []
    var myArray : [News]? = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let storyNib = UINib(nibName: "storyTableViewCell", bundle: nil)
        storyTabelView.register(storyNib, forCellReuseIdentifier: "storyTableViewCell")
        
        let storyTextNib = UINib(nibName: "storyTextTableViewCell", bundle: nil)
        storyTabelView.register(storyTextNib, forCellReuseIdentifier: "storyTextTableViewCell")
        
        let storyButtonNib = UINib(nibName: "storyButtonTableViewCell", bundle: nil)
        storyTabelView.register(storyButtonNib, forCellReuseIdentifier: "storyButtonTableViewCell")
        
        let nib1 = UINib(nibName: "TopstoryTableViewCell", bundle: nil)
        storyTabelView.register(nib1, forCellReuseIdentifier: "topStoryTableViewCell")
        
        storyTabelView.delegate = self
        storyTabelView.dataSource = self
        
        ///API Call for Collection View
        
        let url = URL(string: url)
        guard let myUrl = url else {return}
        let request = URLRequest(url: myUrl)
        let task = URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            if let data = data{
                print(data)
                do{
                    let myData = try JSONDecoder().decode(Story.self, from: data)
                    self?.storymodel = myData
                    if let storymodels = self?.storymodel{
                        for i in storymodels.data!.enumerated(){
                            if i.element.type == "topstoriescrousel"{
                                self!.myArray = i.element.news
                                print(self!.myArray!)
                            }
                            if i.element.type == "bigstory"{
                                self?.bigstoryModel = i.element
                                self!.bigstory = i.element.news
                                print(self!.bigstoryModel!)
                            }
                        }
                        DispatchQueue.main.async {
                            self!.storyTabelView.reloadData()
                        }
                    }
                    else {return}
                }
                catch{
                    print(String(describing: error))
                }
            }
        }
        task.resume()
  }
}

extension ViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = 0
        if let arrayValue = bigstory{
            if arrayValue.count > 0 {
                count = arrayValue.count + 1
            }
        }
        if let arrayValue = myArray{
            if arrayValue.count > 0{
                count = count + 1
            }
        }
        return count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var count = 0
        if let arrayValue = bigstory{
            if arrayValue.count > 0{
                count = arrayValue.count + 1
            }
        }
        if let arrayValue = myArray{
            if arrayValue.count > 0{
                count = count + 1
            }
        }
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "topStoryTableViewCell", for: indexPath) as! TopstoryTableViewCell
            if let array = myArray{
                cell.getValue(getNews: array)
            }
            return cell
        }
        if indexPath.row == 1{
            let cells = tableView.dequeueReusableCell(withIdentifier: "storyTableViewCell", for: indexPath) as! storyTableViewCell
            if let array = bigstory{
                cells.bigstoryLabel.text? = (array[0].n_pcategory_name?.uppercased() ?? "")
                //cells.bigstoryLabel.font = UIFont(name: "rubik-extrabold", size: 32)
                
                cells.bigstoryTextLabel.text? = (array[0].n_title ?? "")
                //cells.bigstoryTextLabel.font = UIFont(name: "rubik-extrabold", size: 32)
                cells.bigstoryTextLabel.numberOfLines = 3;
                
                cells.bigstoryImageView.image = UIImage(named: array[0].n_small_image ?? "")
                if let imageURL = URL(string: array[0].n_small_image ?? "") {
                    DispatchQueue.global().async {
                        guard let imageData = try? Data(contentsOf: imageURL) else { return }
                        let image = UIImage(data: imageData)
                        DispatchQueue.main.async {
                            cells.bigstoryImageView.image = image
                        }
                    }
                }
            }
            return cells
        }
        else if indexPath.row == (count - 1) {
            let cellButton = tableView.dequeueReusableCell(withIdentifier: "storyButtonTableViewCell", for: indexPath) as! storyButtonTableViewCell
            cellButton.delegate = self
            if let link = bigstoryModel?.cta_link{
                cellButton.link = link
            }
            return cellButton
        }
        else{
            let cel = tableView.dequeueReusableCell(withIdentifier: "storyTextTableViewCell", for: indexPath) as! storyTextTableViewCell
            cel.storyTextImageView.isHidden = true
            if let array = bigstory?[indexPath.row - 1]{
                cel.storyTextContentLabel.text? = (array.n_title ?? "")
               // cel.storyTextContentLabel.font = UIFont(name: "Rubik ExtraBold", size: 32)
                cel.storyTextContentLabel.numberOfLines = 3;
                
                if array.n_type == "photogallery"{
                    cel.storyTextImageView.image = UIImage(named : "photoImage")
                    cel.storyTextImageView.isHidden = false
                    
                }else if array.n_type == "videogallery"{
                    cel.storyTextImageView.isHidden = false
                    cel.storyTextImageView.image = UIImage(named : "videoImage")
                        
                }else{
                    cel.storyTextImageView.isHidden = true
                }
                if array.n_type == "story"{
                    cel.backgroundColor = UIColor.systemYellow
                }
                return cel
            }
            return UITableViewCell()
        }
    }
}
extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(bigstory![indexPath.row].n_description)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var count = 0
        if let arrayValue = bigstory{
            if arrayValue.count > 0{
                count = arrayValue.count + 1
            }
        }
        if let arrayValue = myArray{
            if arrayValue.count > 0{
                count = count + 1
            }
        }
        if indexPath.row == 0 {
            return 270
        }
        else if indexPath.row == 1{
            return 300
        }
        else if indexPath.row == count - 1{
            
            /// for hiding button and also change bigstory type checking as topstorycarousel
            //            if let value = bigstoryModel{
            //
            //                if !(value.cta_text?.isEmpty ?? false) {
            //                    return 0
            //
            //                }
            //            }
            return 60
        }
        else
        {
            return UITableView.automaticDimension
//
        }
    }
}
extension ViewController : ItemCellDelegate {
    func storyButton(bigstoryLink: String) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let nextvc = storyBoard.instantiateViewController(withIdentifier: "NextScreenViewController") as! NextScreenViewController
        nextvc.myData = bigstoryLink
        self.navigationController?.pushViewController(nextvc, animated:true)
    }
}


