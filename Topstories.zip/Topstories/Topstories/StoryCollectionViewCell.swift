//
//  StoryCollectionViewCell.swift
//  Topstories
//
//  Created by Sreelakshmi on 30/11/22.
//

import UIKit

class StoryCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var storyImageView: UIImageView!
    
    @IBOutlet weak var storyLabel: UILabel!
    
    
    @IBOutlet weak var storyTextLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
