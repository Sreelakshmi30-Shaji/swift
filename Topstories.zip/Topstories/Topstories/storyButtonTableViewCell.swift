//
//  storyButtonTableViewCell.swift
//  Topstories
//
//  Created by Sreelakshmi on 05/12/22.
//

import UIKit


protocol ItemCellDelegate {
    func storyButton(bigstoryLink : String)
  }
  
class storyButtonTableViewCell: UITableViewCell {
    
    var delegate: ItemCellDelegate?
    var link : String?
    
    @IBOutlet weak var focusButtonOutlet : UIButton?
        
    @IBAction func storyButton(_ sender: Any) {
        print("Hi")
        if let storyData = link {
            delegate?.storyButton(bigstoryLink:storyData)
        }
    }
override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
        
 


    

