//
//  TopstoryTableViewCell.swift
//  Topstories
//
//  Created by Sreelakshmi on 06/12/22.
//

import UIKit

class TopstoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var topstoryLabel: UILabel!
    
    @IBOutlet weak var topStoryCollectionView: UICollectionView!
    
    @IBOutlet weak var topstoryImageView: UIImageView!
    
    var myArray : [News]? = []
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        let nib = UINib(nibName: "StoryCollectionViewCell", bundle: nil)
        topStoryCollectionView.register(nib, forCellWithReuseIdentifier: "storyCollectionViewCell")
        
        topStoryCollectionView.delegate = self
        topStoryCollectionView.dataSource = self
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    func getValue(getNews : [News]){
        myArray = getNews
        topStoryCollectionView.reloadData()
    }
}

extension TopstoryTableViewCell : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "storyCollectionViewCell", for: indexPath) as! StoryCollectionViewCell
        if let array = myArray{
            cell.storyLabel.text? = (array[indexPath.row].n_pcategory_name?.uppercased() ?? "")
            cell.storyLabel.font = UIFont(name: "Rubik Medium", size: 14.0)
            
            cell.storyTextLabel.text? = (array[indexPath.row].n_title ?? "")
            cell.storyTextLabel.font = UIFont(name: "Rubik Medium", size: 14.0)
            cell.storyTextLabel.numberOfLines = 3;
            
            cell.storyImageView.image = UIImage(named: array[indexPath.row].n_small_image ?? "")
            if let imageURL = URL(string: array[indexPath.row].n_small_image ?? "") {
                DispatchQueue.global().async {
                    guard let imageData = try? Data(contentsOf: imageURL) else { return }
                    let image = UIImage(data: imageData)
                    DispatchQueue.main.async {
                        cell.storyImageView.image = image
                    }
                }
            }
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var count = 0
        if let arrayValue = myArray{
            if arrayValue.count > 0{
                count = arrayValue.count
            }
        }
        return count
    }
}

extension TopstoryTableViewCell : UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let arrays = myArray{
            print(arrays[indexPath.row])
            print(indexPath)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 261,height: 241)
    }
}
