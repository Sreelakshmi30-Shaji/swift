//
//  NextScreenViewController.swift
//  Topstories
//
//  Created by Sreelakshmi on 09/12/22.
//

import UIKit
import WebKit

class NextScreenViewController: UIViewController,WKNavigationDelegate {
    
    @IBOutlet weak var nextWebView: WKWebView!
    
    var myData : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadLinks()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func loadLinks(){
        nextWebView.navigationDelegate = self
        if let myUrl = myData{
            let url = URL(string: "https://www.indiatoday.in")
            nextWebView.load(URLRequest(url: url!))
        }
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("Start to Load")
        if let url = webView.url?.absoluteURL{
            print("url=\(url)")
        }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print(error.localizedDescription)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("Finish to load")
        if let url = webView.url?.absoluteURL{
        print("url=\(url)")
        }
    }
}
