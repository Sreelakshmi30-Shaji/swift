//
//  MapView.swift
//  Landmark
//
//  Created by Sreelakshmi on 16/10/23.
//

import SwiftUI
import MapKit

struct MapView: View {
    var coordinate: CLLocationCoordinate2D ///represents the geographic coordinate (latitude and longitude) for the center of the map view.

    var body: some View {
        Map(coordinateRegion: .constant(region)) ///map view is defined.
        ///coordinateRegion parameter is set to a constant with the value region. The .constant modifier is used to ensure that the region remains fixed
    }

    private var region: MKCoordinateRegion {
        MKCoordinateRegion(
            center: coordinate,
            span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
        )
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView(coordinate: CLLocationCoordinate2D(latitude: 34.011_286, longitude: -116.166_868))
    }
}
