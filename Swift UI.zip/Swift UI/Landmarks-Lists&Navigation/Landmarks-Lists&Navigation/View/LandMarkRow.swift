//
//  LandMarkRow.swift
//  Landmarks-Lists&Navigation
//
//  Created by Sreelakshmi on 16/10/23.
//

import SwiftUI

struct LandmarkRow: View {
    var landmark: Landmark

    var body: some View {
        HStack {
            landmark.image
                .resizable()
                .frame(width: 50, height: 50)
            Text(landmark.name)

            Spacer()

            if landmark.isFavorite {
                Image(systemName: "star.fill")
                    .foregroundStyle(.yellow)
            }
        }
    }
}

struct LandMarkRow_Previews: PreviewProvider {
    static var previews: some View {
        let landmarks = ModelData().landmarks  // Declare landmarks here
        return LandmarkRow(landmark: landmarks[0])
    }
}
