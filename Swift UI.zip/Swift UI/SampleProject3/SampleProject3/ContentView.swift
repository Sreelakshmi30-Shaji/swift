//
//  ContentView.swift
//  SampleProject3
//
//  Created by Sreelakshmi on 11/10/23.
//

import SwiftUI

struct ContentView: View {
    
   @StateObject var todoList = ToDoListViewModel()
    @State private var newItem = ""
    
    var body: some View{ ///defines the view's content.
        NavigationView{  ///provides navigation functionality,
            List{        ///to display a list of items.
                Section(header: Text("New Task")){
                    HStack{       ///arrange views horizontally,
                        TextField("Enter a new Task",text: $newItem)
                        Button(action: {
                            if !newItem.isEmpty{
                                todoList.addItem(task: newItem)
                                newItem = ""  ///newItem is cleared by setting it to an empty string, ready for the next task entry.
                            }
                        }){
                            Image(systemName: "plus.circle.fill")
                        }
                    }
                }
                
                Section(header: Text("Tasks")){
                    ForEach(todoList.items) { item in
                        HStack{
                            Text(item.task) ///displays the task description from the ToDoItem model.
                            Spacer()
                            Image(systemName: item.isCompleted ? "checkmark.circle.fill" : "circle")
                                .onTapGesture {
                                    todoList.toggleItemCompletion(item: item)
                                }
                            Image(systemName: "trash.circle.fill")
                                .onTapGesture {
                                    todoList.removeItem(item: item)
                                }
                        }
                        .foregroundColor(item.isCompleted ? .gray : .primary)
                    }
                }
            }
            .listStyle(GroupedListStyle())
            .navigationTitle("To-Do List")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
