//
//  ToDoListViewModel.swift
//  SampleProject3
//
//  Created by Sreelakshmi on 11/10/23.
//

import Foundation

class ToDoListViewModel: ObservableObject {
    @Published var items: [ToDoItem] = []
    
    ///to add a new to-do item to the list
    func addItem(task: String){
        let newItem = ToDoItem(task: task)
        items.append(newItem)
    }
    
    ///to toggle the completion status of a to-do item.
    func toggleItemCompletion(item: ToDoItem){
           ///to find the index of the item within the items array. It checks if there's a matching item in the array based on the unique id property.
        if let index = items.firstIndex(where: {$0.id == item.id}){
            items[index].isCompleted.toggle()
        }
    }
    
    ///to remove a specific to-do item from the list
    func removeItem(item: ToDoItem){
        items.removeAll {$0.id == item.id}
    }
}
