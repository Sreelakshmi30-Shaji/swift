//
//  SampleProject3App.swift
//  SampleProject3
//
//  Created by Sreelakshmi on 11/10/23.
//

import SwiftUI

@main
struct SampleProject3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
