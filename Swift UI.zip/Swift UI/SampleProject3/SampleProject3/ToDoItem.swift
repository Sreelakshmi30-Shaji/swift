//
//  ToDoItem.swift
//  SampleProject3
//
//  Created by Sreelakshmi on 11/10/23.
//

import Foundation

struct ToDoItem : Identifiable {
    var id = UUID()
    var task: String
    var isCompleted = false
}
