//
//  Item.swift
//  SampleProject2
//
//  Created by Sreelakshmi on 11/10/23.
//

import Foundation

struct Item : Identifiable {
    let id = UUID()
    let name: String
}
