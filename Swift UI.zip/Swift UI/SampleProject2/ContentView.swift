//
//  ContentView.swift
//  SampleProject2
//
//  Created by Sreelakshmi on 11/10/23.
//

import SwiftUI

struct ContentView: View {
    
    @State private var items: [Item] = [
        Item(name: "Item 1"),
        Item(name: "Item 2"),
        Item(name: "Item 3"),
        Item(name: "Item 4")
    ]
    
     var nextItemNumber: Int {
            if let lastItem = items.last,
               let itemNumber = Int(lastItem.name.components(separatedBy: " ").last ?? "0") {
                return itemNumber + 1
            } else {
                return 1
            }
    }
    
    var body: some View {
        NavigationView{
            List(items) { item in
                Text(item.name)
            }
            .navigationTitle("Item List")
        }
        Button(action: {
            let newItemName = "Item \(self.nextItemNumber)"
            self.items.append(Item(name: newItemName))
        })  {
            Text("Add Item")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
