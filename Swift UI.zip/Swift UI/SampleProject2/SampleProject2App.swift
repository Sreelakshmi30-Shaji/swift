//
//  SampleProject2App.swift
//  SampleProject2
//
//  Created by Sreelakshmi on 11/10/23.
//

import SwiftUI

@main
struct SampleProject2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
