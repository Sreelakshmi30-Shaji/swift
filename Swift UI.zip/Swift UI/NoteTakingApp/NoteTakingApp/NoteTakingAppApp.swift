//
//  NoteTakingAppApp.swift
//  NoteTakingApp
//
//  Created by Sreelakshmi on 12/10/23.
//

//import SwiftUI
//
//@main
//struct NoteTakingAppApp: App {
//    var body: some Scene {
//        WindowGroup {
//            NoteListView()
//        }
//    }
//}
