//
//  ContentView.swift
//  NoteTakingApp
//
//  Created by Sreelakshmi on 12/10/23.
//

import SwiftUI

// Note Model
struct Note: Identifiable {
    var id = UUID()
    var title: String
    var content: String
}

// NoteDataStore
class NoteDataStore: ObservableObject {
    @Published var notes = [Note]()
    
    func addNote(note: Note) {
        notes.append(note)
    }
    
    func updateNote(note: Note) {
        if let index = notes.firstIndex(where: { $0.id == note.id }) {
            notes[index] = note
        }
    }
    
    func deleteNote(note: Note) {
        if let index = notes.firstIndex(where: { $0.id == note.id }) {
            notes.remove(at: index)
        }
    }
}

// Note List View
struct NoteListView: View {
    @ObservedObject var dataStore: NoteDataStore
    @State private var showingNoteSheet = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(dataStore.notes) { note in
                    NavigationLink(destination: NoteDetailView(note: note, dataStore: dataStore)) {
                        Text(note.title)
                    }
                }
            }
            .navigationTitle("Notes")
            .navigationBarItems(trailing:
                Button(action: {
                    showingNoteSheet.toggle()
                }) {
                    Image(systemName: "plus")
                }
            )
        }
        .sheet(isPresented: $showingNoteSheet) {
            NoteEditView(dataStore: dataStore)
        }
    }
}

// Note Detail View
struct NoteDetailView: View {
    var note: Note
    @ObservedObject var dataStore: NoteDataStore
    
    var body: some View {
        VStack {
            Text(note.title)
                .font(.title)
            Text(note.content)
                .padding()
            Spacer()
            Button("Delete") {
                dataStore.deleteNote(note: note)
            }
        }
    }
}

// Note Edit View
struct NoteEditView: View {
    @ObservedObject var dataStore: NoteDataStore
    @State private var title = ""
    @State private var content = ""
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Note Details")) {
                    TextField("Title", text: $title)
                    TextEditor(text: $content)
                }
            }
            .navigationTitle("New Note")
            .navigationBarItems(trailing: Button("Save") {
                let newNote = Note(title: title, content: content)
                dataStore.addNote(note: newNote)
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}

@main
struct NotesApp: App {
    @StateObject var dataStore = NoteDataStore()
    
    var body: some Scene {
        WindowGroup {
            NoteListView(dataStore: dataStore)
        }
    }
}
