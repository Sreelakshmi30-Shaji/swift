//
//  ContentView.swift
//  ECommerceApp
//
//  Created by Sreelakshmi on 12/10/23.
//

import SwiftUI

struct Product: Identifiable {
    var id = UUID()
    var name: String
    var price: Double
}

let sampleProducts = [
    Product(name: "Product 1", price: 10.99),
    Product(name: "Product 2", price: 19.99),
    Product(name: "Product 3", price: 8.99),
]


struct ProductListView: View {
    var products: [Product]
    
    var body: some View {
        NavigationView {
            List(products) { product in
                NavigationLink(destination: ProductDetailView(product: product)) {
                    ProductRowView(product: product)
                }
            }
            .navigationTitle("Products")
        }
    }
}

struct ProductRowView: View {
    var product: Product
    
    var body: some View {
        HStack {
            Text(product.name)
            Spacer()
            Text("$\(product.price, specifier: "%.2f")")
        }
    }
}

struct ProductDetailView: View {
    var product: Product
    @State private var quantity = 1
    
    var body: some View {
        VStack {
            Text(product.name)
                .font(.title)
            Text("Price: $\(product.price, specifier: "%.2f")")
                .font(.subheadline)
            
            Stepper("Quantity: \(quantity)", value: $quantity, in: 1...10)
                .padding()
            
            Button(action: {
                // Implement add to cart logic here
            }) {
                Text("Add to Cart")
                    .font(.headline)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
    }
}

struct ShoppingCartView: View {
    var body: some View {
        Text("Shopping Cart")
            .font(.title)
    }
}

@main
struct ECommerceApp: App {
    var body: some Scene {
        WindowGroup {
            ProductListView(products: sampleProducts)
        }
    }
}
