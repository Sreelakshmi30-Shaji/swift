//
//  ECommerceAppApp.swift
//  ECommerceApp
//
//  Created by Sreelakshmi on 12/10/23.
//

//import SwiftUI
//
//@main
//struct ECommerceAppApp: App {
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}
