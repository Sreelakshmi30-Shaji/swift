//
//  ContentView.swift
//  Landmark
//
//  Created by Sreelakshmi on 16/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            MapView()
                .frame(height: 300)
            HStack {
                Spacer()
                CircleImage()
                    .frame(width: 500, height: 300)
                Spacer()
            }

            VStack(alignment: .center, spacing: 10) {
                Text("Turtle Rock")
                    .font(.title)
                    .fontWeight(.bold)

                Text("Joshua Tree National Park, California")
                    .font(.subheadline)

                Divider()

                Text("About Turtle Rock")
                    .font(.title2)

                Text("24 m high, whose form reminds of a turtle")
                    .font(.body)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(8)
            .shadow(radius: 5)

            Spacer()
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
