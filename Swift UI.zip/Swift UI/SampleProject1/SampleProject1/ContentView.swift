//
//  ContentView.swift
//  SampleProject1
//
//  Created by Sreelakshmi on 09/10/23.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isAnimating = false
    @State private var showAlert = false
    
    @State private var username = ""
    @State private var password = ""
    @State private var isToggled = false
    
    var body: some View {
        Form{
            Section(header: Text("User Info")){
                TextField("Username", text: $username)
                SecureField("Password", text: $password)
            }
            Section{
                Toggle("Receive Notifications",isOn: $isToggled)
            }
        }
        
        Text("Hello SwiftUI !!!")
            .font(.largeTitle)
            .foregroundColor(.cyan)
        
        Image("mac")
            .resizable()
            .aspectRatio(contentMode: .fit)
        
        Button("Animate Text"){
            withAnimation{
                isAnimating.toggle()
            }
        }
        .padding()
        .background(isAnimating ? Color.red : Color.green)
        .foregroundColor(.white)
        .cornerRadius(8)
        .animation(.default)
        if isAnimating {
            Text("Text is Animated!")
                .font(.largeTitle)
                .transition(.scale)
        }
        
        Button("Show Alert"){
            showAlert.toggle()
        }
        .alert(isPresented: $showAlert){
            Alert(
                title: Text("Alert Title"),
                message: Text("This is an alert message!"),
                dismissButton: .default(Text("OK"))
            )
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
