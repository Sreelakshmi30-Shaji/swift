//
//  SampleProject1App.swift
//  SampleProject1
//
//  Created by Sreelakshmi on 09/10/23.
//

import SwiftUI

@main
struct SampleProject1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
