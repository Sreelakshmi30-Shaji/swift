//
//  CalculatorApp.swift
//  Calculator
//
//  Created by Sreelakshmi on 12/10/23.
//

import SwiftUI

@main
struct CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
