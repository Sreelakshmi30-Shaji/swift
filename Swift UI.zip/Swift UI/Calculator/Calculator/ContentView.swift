//
//  ContentView.swift
//  Calculator
//
//  Created by Sreelakshmi on 12/10/23.
//

import SwiftUI

struct ContentView: View {
    @State private var display = "0"
    @State private var currentInput = ""
    @State private var storedValue: Double?
    @State private var currentOperator: String?

    let buttonSize: CGFloat = 80

    var body: some View {
        VStack(spacing: 12) {
            Text(display)
                .font(.system(size: 48))
                .foregroundColor(Color(.label))
                .padding()

            HStack(spacing: 12) {
                CalculatorButton("7")
                CalculatorButton("8")
                CalculatorButton("9")
                CalculatorButton("/")
            }

            HStack(spacing: 12) {
                CalculatorButton("4")
                CalculatorButton("5")
                CalculatorButton("6")
                CalculatorButton("x")
            }

            HStack(spacing: 12) {
                CalculatorButton("1")
                CalculatorButton("2")
                CalculatorButton("3")
                CalculatorButton("-")
            }

            HStack(spacing: 12) {
                CalculatorButton("0")
                CalculatorButton(".")
                CalculatorButton("=")
                CalculatorButton("+")
            }

            HStack {
                Spacer()
                CalculatorButton("C", backgroundColor: Color(.systemRed)) // Clear button
            }
        }
        .padding(12)
    }

    func CalculatorButton(_ button: String, backgroundColor: Color = Color(.systemGray4)) -> some View {
        Button(action: {
            self.buttonTapped(button)
        }) {
            Text(button)
                .font(.system(size: 32))
                .frame(width: buttonSize, height: buttonSize)
                .background(backgroundColor)
                .cornerRadius(buttonSize / 2)
        }
    }

    func buttonTapped(_ button: String) {
        if button == "C" {
            // Clear the input and reset the calculator
            display = "0"
            currentInput = ""
            storedValue = nil
            currentOperator = nil
        } else {
            // Handle the rest of the buttons (numbers and operators)
            switch button {
            case "+", "-", "x", "/":
                currentOperator = button
                storedValue = Double(currentInput)
                currentInput = ""
            case "=":
                if let operatorType = currentOperator, let storedValue = storedValue, let inputValue = Double(currentInput) {
                    switch operatorType {
                    case "+":
                        currentInput = "\(storedValue + inputValue)"
                    case "-":
                        currentInput = "\(storedValue - inputValue)"
                    case "x":
                        currentInput = "\(storedValue * inputValue)"
                    case "/":
                        currentInput = "\(storedValue / inputValue)"
                    default:
                        break
                    }
                }
                display = currentInput
                currentOperator = nil
            default:
                if currentInput == "0" {
                    currentInput = button
                } else {
                    currentInput += button
                }
            }
            display = currentInput
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
