//
//  BookDetailViewController.swift
//  BookList
//
//  Created by Sreelakshmi on 30/06/23.
//  This class represents a view controller that displays detailed information about a book. 

import UIKit

class BookDetailViewController: UIViewController{
    
    var book : Book?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white

        if let book = book {
            let bookImageView = UIImageView(frame: CGRect(x: 80, y: 100, width: 250, height: 300))
            bookImageView.image = book.image
            bookImageView.contentMode = .scaleAspectFit
            view.addSubview(bookImageView)

            let titleLabel = UILabel(frame: CGRect(x: 10, y: 410, width: view.bounds.width - 20, height: 30))
            titleLabel.text = book.title
            titleLabel.textColor = .red
            titleLabel.font = UIFont.boldSystemFont(ofSize: 22)
            titleLabel.textAlignment = .center
            view.addSubview(titleLabel)

            let authorLabel = UILabel(frame: CGRect(x: 10, y: 440, width: view.bounds.width - 20, height: 30))
            authorLabel.text = book.author
            authorLabel.textColor = .systemBlue
            authorLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
            authorLabel.textAlignment = .center
            view.addSubview(authorLabel)

            let summaryLabel = UILabel(frame: CGRect(x: 10, y: 460, width: view.bounds.width - 20, height: 200))
            summaryLabel.numberOfLines = 0
            summaryLabel.text = book.summary
            summaryLabel.textAlignment = .justified
            view.addSubview(summaryLabel)
        }
   }
}

     
        


