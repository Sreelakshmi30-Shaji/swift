//
//  Book.swift
//  BookList
//
//  Created by Sreelakshmi on 30/06/23.
// Book is a custom data type that represents a book.

import Foundation
import UIKit

struct Book {
    var title : String
    var author : String
    var summary : String
    var image : UIImage?
}
