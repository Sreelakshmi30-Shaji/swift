//
//  ViewController.swift
//  BookList
//
//  Created by Sreelakshmi on 30/06/23.
//  This class is to sets up a table view to display a list of books and handles the selection of a book to navigate to the BookDetailViewController.

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var bookListTableView: UITableView!
    
    let books = [
        Book(title: "The Great Gatsby", author: " F. Scott Fitzgerald", summary: "Set in the roaring 1920s, The Great Gatsby is a classic American novel that explores themes of wealth, love, and the pursuit of the American Dream. It follows the mysterious millionaire Jay Gatsby as he throws lavish parties and pursues his obsession with Daisy Buchanan, a married woman from his past.", image: UIImage(named: "book1")),
        Book(title: "To Kill a Mockingbird", author: "Harper Lee", summary: "To Kill a Mockingbir is a renowned novel set in the Deep South during the 1930s. It tackles important themes of racial inequality, injustice, and the loss of innocence. Through the eyes of Scout Finch, the young protagonist, the story unfolds as her father, Atticus Finch, defends an innocent Black man accused of a crime, challenging the deeply ingrained prejudices of their community.", image: UIImage(named: "book2")),
        Book(title: "The Alchemist", author: "Paulo Coelho", summary: "The first book in the beloved Harry Potter series introduces readers to the magical world of Hogwarts School of Witchcraft and Wizardry, as Harry Potter discovers his true identity and battles against the dark wizard Lord Voldemort.", image: UIImage(named: "book3")),
        Book(title: "The Lord of the Rings", author: "J.R.R. Tolkien", summary: "This epic trilogy follows the journey of Frodo Baggins as he embarks on a perilous mission to destroy the One Ring and save Middle-earth from the dark lord Sauron.", image: UIImage(named: "book4")),
        Book(title: "The Catcher in the Rye", author: "J.D. Salinger", summary: "This coming-of-age novel follows the story of Holden Caulfield, a disillusioned teenager who reflects on his experiences and struggles with identity, authenticity, and the phoniness of the adult world.", image: UIImage(named: "book5")),
        Book(title: "1984", author: "George Orwell", summary: "In a dystopian future, this novel depicts a totalitarian regime ruled by Big Brother, where individualism and independent thought are suppressed, and the protagonist, Winston Smith, rebels against the oppressive system.", image: UIImage(named: "book6")),
        Book(title: "Pride and Prejudice", author: "Jane Austen", summary: "A beloved classic, this novel follows the story of Elizabeth Bennet as she navigates the societal expectations and prejudices of 19th-century England, eventually finding love and self-discovery.", image: UIImage(named: "book7"))
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bookListTableView.dataSource =  self
        bookListTableView.delegate = self
        let nib = UINib(nibName: "BookListTableViewCell", bundle: nil)
        bookListTableView.register(nib, forCellReuseIdentifier: "BookListCellIdentifier")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = bookListTableView.dequeueReusableCell(withIdentifier: "BookListCellIdentifier", for: indexPath) as! BookListTableViewCell
        let book = books[indexPath.row]
        cell.titleLabel.text = book.title
        cell.bookImageView.image = book.image
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let book = books[indexPath.row]
        let bookDetailVC = BookDetailViewController()
        bookDetailVC.book = book
        present(bookDetailVC,animated: true)
        //navigationController?.pushViewController(bookDetailVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row % 2 == 0{
            return 120
        }else{
            return 240
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "My Favourite Books"
    }
}



