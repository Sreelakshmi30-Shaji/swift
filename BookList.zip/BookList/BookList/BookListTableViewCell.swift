//
//  BookListTableViewCell.swift
//  BookList
//
//  Created by Sreelakshmi on 30/06/23.
//  This class represents a custom table view cell for displaying book information.

import UIKit

class BookListTableViewCell: UITableViewCell {

    @IBOutlet weak var bookImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
}
