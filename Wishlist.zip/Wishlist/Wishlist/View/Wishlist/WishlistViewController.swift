//
//  WishlistViewController.swift
//  Wishlist
//
//  Created by Sreelakshmi on 03/05/23.
//

import UIKit
import CoreData
class WishlistViewController: UIViewController {
    
    
    @IBOutlet weak var WishlistTableView: UITableView!
    
    var wishlistData : [Wishlist] = []
    var wishlist = Wishlist()
    var wishlistViewModel = WishlistViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let nib = UINib(nibName: "WishlistTableViewCell", bundle: nil)
        WishlistTableView.register(nib, forCellReuseIdentifier: "wishlistTableViewCell")
        
        WishlistTableView.dataSource = self
        WishlistTableView.delegate = self
   }
    
    override func viewDidAppear(_ animated: Bool) {
        wishlistViewModel.retrieveData{ item, error in
            if error == nil{
                guard let item = item else{
                return
                }
                self.wishlistData = item
                print(item)
                DispatchQueue.main.async {
                    self.WishlistTableView.reloadData()
                }
            }else{
                print("error")
            }
        }
    }
}

extension WishlistViewController: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return wishlistViewModel.wishlistData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = WishlistTableView.dequeueReusableCell(withIdentifier: "wishlistTableViewCell", for: indexPath) as! WishlistTableViewCell
        cell.wishlist = wishlistViewModel.wishlistData[indexPath.row]
        cell.WislistTitleLabel.text? = wishlistData[indexPath.row].title!
        cell.WishlistBrandLabel.text? = wishlistData[indexPath.row].brand!
        cell.WishlistPriceLabel.text? = wishlistData[indexPath.row].price!
        
        let imageUrl = URL(string: wishlistData[indexPath.row].thumbnail!)
        if let myImageUrl = imageUrl {
            do{
                let imageData = try Data(contentsOf: myImageUrl)
                cell.WishlistImageView?.image = UIImage(data: imageData)
            }catch{
                print("error")
            }
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(wishlistData[indexPath.row].title)
        print(wishlistData[indexPath.row].brand)
        print(wishlistData[indexPath.row].price)
        print(wishlistData[indexPath.row].thumbnail)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(135)
    }
}



