//
//  ViewController.swift
//  Wishlist
//
//  Created by Sreelakshmi on 02/05/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var cartTableVIew: UITableView!
    
    @IBOutlet weak var cartSearchBar: UISearchBar!
    
    
    @IBOutlet weak var segmentControlOutlet: UISegmentedControl!
    
    var cartViewModel = CartViewModel()
    var cart = Cart()
    var items : [Cart] = []
    var filteredItems : [Cart] = []
    var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let nib = UINib(nibName: "CartTableViewCell", bundle: nil)
        cartTableVIew.register(nib, forCellReuseIdentifier: "cartTableViewCell")
        cartTableVIew.dataSource = self
        cartTableVIew.delegate = self
        cartSearchBar.delegate = self
        
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.center = view.center
        view.addSubview(activityIndicator)
        activityIndicator.startAnimating()
        
        ///API Call
        cartViewModel.fetchApi { item, error in
            if error == nil{
            guard let item = item else{
                return
             }
                self.items = item
                self.filteredItems = item
                DispatchQueue.main.async {
                    self.cartTableVIew.reloadData()
                    self.activityIndicator.stopAnimating()

                }
            }else{
                print("error")
            }
        }
    }
    

    
    @IBAction func segmentClick(_ sender: Any) {
        let selectedSegmentIndex = segmentControlOutlet.selectedSegmentIndex
        filteredItems = filterItems(for: selectedSegmentIndex)
        cartTableVIew.reloadData()
    }
    
    func filterItems(for segmentIndex: Int) -> [Cart] {
            let type: String?
            switch segmentIndex {
            case 0:
                type = nil
            case 1:
                type = "Dress"
            case 2:
                type = "groceries"
            case 3:
                type = "SmartPhones"
            case 4:
                type = "Laptop"
            case 5:
                type = "Fragrance"
            case 6:
                type = "home_decoration"
            default:
                return []
            }
            return items.filter { item in
                return type == nil || item.type == type
            }
        }
    }
            

extension ViewController : UITableViewDataSource{
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredItems.count
 }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = cartTableVIew.dequeueReusableCell(withIdentifier: "cartTableViewCell", for: indexPath) as! CartTableViewCell
        let item = filteredItems[indexPath.row]
                cell.cart = item
                cell.CartTitleLabel.text? = item.title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = item.brand!
                cell.CartPriceLabel.text? = item.price!
                
                let imageUrl = URL(string: item.thumbnail!)
                if let myImageUrl = imageUrl {
                    DispatchQueue.global().async {
                        if let imageData = try? Data(contentsOf: myImageUrl) {
                            DispatchQueue.main.async {
                                cell.CartIMageView?.image = UIImage(data: imageData)
                            }
                        }
                    }
                }
            return cell
            }
      }

extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = filteredItems[indexPath.row]
                print(selectedItem.title)
                print(selectedItem.brand)
                print(selectedItem.price)
                print(selectedItem.thumbnail)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(120)
    }
}
extension ViewController : UISearchDisplayDelegate,UISearchBarDelegate{
   
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            if searchText.isEmpty {
                    filteredItems = items
                } else {
                    filteredItems = items.filter { item in
                        let title = item.title?.lowercased() ?? ""
                        let brand = item.brand?.lowercased() ?? ""
                        let search = searchText.lowercased()
                        return title.contains(search) || brand.contains(search)
                    }
                }
             cartTableVIew.reloadData()
            }
     }

