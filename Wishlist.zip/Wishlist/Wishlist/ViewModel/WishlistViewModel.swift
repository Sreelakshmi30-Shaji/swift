//
//  WishlistViewModel.swift
//  Wishlist
//
//  Created by Sreelakshmi on 05/05/23.
//

import Foundation
import UIKit
import CoreData

class WishlistViewModel: NSManagedObject {
    
    var wishlistData: [Wishlist] = []
    
    func retrieveData(completion: @escaping ([Wishlist]?, Error?) -> Void) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            completion(nil, nil)
            return
        }
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WishlistItem")
        do {
            let result = try managedObjectContext.fetch(fetchRequest)
            wishlistData = []
            if let dataObjects = result as? [NSManagedObject], !dataObjects.isEmpty {
                for data in dataObjects {
                    let id = data.value(forKey: "id") as? Int ?? 0
                    let title = data.value(forKey: "title") as? String ?? ""
                    let brand = data.value(forKey: "brand") as? String ?? ""
                    let price = data.value(forKey: "price") as? String ?? ""
                    let thumbnail = data.value(forKey: "thumbnail") as? String ?? ""
                    let type = data.value(forKey: "type") as? String ?? ""
                    let wishlistItem = Wishlist(id: id, title: title, brand: brand, price: price, thumbnail: thumbnail, type: type)
                    wishlistData.append(wishlistItem)
                }
                completion(wishlistData, nil)
            } else {
                completion(nil, nil)
            }
        } catch {
            completion(nil, error)
            print("Fetch Failed: \(error)")
        }
    }
}


