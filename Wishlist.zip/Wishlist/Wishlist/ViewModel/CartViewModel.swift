//
//  CartViewModel.swift
//  Wishlist
//
//  Created by Sreelakshmi on 02/05/23.

import Foundation
import CoreData
import UIKit

class CartViewModel: NSManagedObject {
    
    var items: [Cart] = []
    var searchItems: [Cart] = []
    var view = ToastView()
    
    /// API Call
    func fetchApi(completion: @escaping ([Cart]?, Error?) -> Void) {
        guard let url = URL(string: "https://demo6641443.mockable.io/Wishlist") else {
            completion(nil, nil) // Invalid URL
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error) // Handle network error
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(nil, nil) // Invalid response
                return
            }
            let statusCode = httpResponse.statusCode
            if (200...299).contains(statusCode) {
                print("Response is successful")
            } else {
                print("Response is a failure. Status code: \(statusCode)")
            }
            guard let data = data else {
                completion(nil, nil) // No data available
                return
            }
            do {
                let itemsList = try JSONDecoder().decode([Cart].self, from: data)
                self.items = itemsList
                completion(itemsList, nil) // Successful response
            } catch let error {
                completion(nil, error) // JSON decoding error
            }
        }.resume()
    }
    
    /// Add Item To Core Data
    func addItemToCoreData(itemData: Cart, completion: (Bool) -> Void) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        guard let cartEntity = NSEntityDescription.entity(forEntityName: "CartItem", in: managedObjectContext) else {
            completion(false)
            return
        }
        
        let item = NSManagedObject(entity: cartEntity, insertInto: managedObjectContext)
        setValues(for: item, with: itemData)
        
        let toastView = ToastView(frame: CGRect(x: 100, y: 800, width: 200, height: 50))
        toastView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(toastView)
        toastView.show(message: "Item added to Coredata")
        
        do {
            try managedObjectContext.save()
            completion(true)
        } catch {
            print("Error saving item to Core Data: \(error)")
            completion(false)
        }
    }
    
    /// Retrieve Data From Core Data
    func retrieveData() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        do {
            if let result = try managedObjectContext.fetch(fetchRequest) as? [NSManagedObject] {
                for data in result {
                    print(data)
                    print(data.value(forKey: "id") as? Int)
                    print(data.value(forKey: "title") as? String)
                    print(data.value(forKey: "brand") as? String)
                    print(data.value(forKey: "price") as? String)
                    print(data.value(forKey: "thumbnail") as? String)
                    print(data.value(forKey: "type") as? String)
                }
            }
        } catch {
            print("Fetch Failed: \(error)")
        }
    }
    
    /// Remove Item From Core Data
    func removeItemFromCoreData(item: Cart, completion: (Bool) -> Void) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        if let itemID = item.id {
            fetchRequest.predicate = NSPredicate(format: "id == %@", "\(itemID)")
        }
        do {
            let objects = try managedObjectContext.fetch(fetchRequest)
            for object in objects {
                managedObjectContext.delete(object as! NSManagedObject)
                
                let toastView = ToastView(frame: CGRect(x: 100, y: 800, width: 240, height: 50))
                toastView.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(toastView)
                toastView.show(message: "Item removed from Coredata")
            }
            try managedObjectContext.save()
            completion(true)
        } catch {
            print(error)
            completion(false)
        }
    }
    
    /// Add Item To Wishlist and Remove from Wishlist
    func addItemToWishlist(itemData: Cart, completion: (Bool, Bool) -> Void) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        guard let entityDescription = NSEntityDescription.entity(forEntityName: "WishlistItem", in: managedObjectContext) else {
            fatalError("Failed to retrieve entity description")
        }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WishlistItem")
        if let itemID = itemData.id {
            fetchRequest.predicate = NSPredicate(format: "id == %@", "\(itemID)")
        }
        do {
            let arrData = try managedObjectContext.fetch(fetchRequest)
            if arrData.count > 0 {
                print("Record already exists")
                for object in arrData {
                    managedObjectContext.delete(object as! NSManagedObject)
                    
                    let toastView = ToastView(frame: CGRect(x: 100, y: 800, width: 240, height: 50))
                    toastView.translatesAutoresizingMaskIntoConstraints = false
                    view.addSubview(toastView)
                    toastView.show(message: "Item removed from Wishlist")
                    completion(true, true)
                }
                completion(true, false)
            } else {
                let item = NSManagedObject(entity: entityDescription, insertInto: managedObjectContext)
                setValues(for: item, with: itemData)
                
                let toastView = ToastView(frame: CGRect(x: 100, y: 800, width: 200, height: 50))
                toastView.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(toastView)
                toastView.show(message: "Item added to Wishlist")
                completion(true, true)
            }
            try managedObjectContext.save()
        } catch {
            print(error.localizedDescription)
            completion(false, false)
        }
    }
    
    /// Set values for a Core Data object
    private func setValues(for object: NSManagedObject, with itemData: Cart) {
        object.setValue(itemData.id ?? 0, forKeyPath: "id")
        object.setValue(itemData.title ?? "", forKeyPath: "title")
        object.setValue(itemData.brand ?? "", forKeyPath: "brand")
        object.setValue(itemData.price ?? "", forKeyPath: "price")
        object.setValue(itemData.thumbnail ?? "", forKeyPath: "thumbnail")
        object.setValue(itemData.type ?? "", forKeyPath: "type")
    }
}
